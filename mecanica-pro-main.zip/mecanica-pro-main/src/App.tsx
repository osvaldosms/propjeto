import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { Auth } from "./pages/Auth";
import { AuthCallback } from "./pages/AuthCallback";
import { NovaSenha } from "./pages/NovaSenha";
import { PasswordRecoveryRoute } from "./components/auth/PasswordRecoveryRoute";
import { Layout } from "./components/layout/Layout";
import { Dashboard } from "./pages/Dashboard";
import { Customers } from "./pages/Customers";
import { Vehicles } from "./pages/Vehicles";
import { ServiceOrders } from "./pages/ServiceOrders";
import { ServiceOrderForm } from "./pages/ServiceOrderForm";
import Plans from "./pages/Plans";
import Inventory from "./pages/Inventory";
import Schedule from "./pages/Schedule";
import Financial from "./pages/Financial";
import Reports from "./pages/Reports";
import Team from "./pages/Team";
import Communication from "./pages/Communication";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();


// Componente para proteger rotas autenticadas
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />;
  }
  
  return <Layout>{children}</Layout>;
};

// Componente para redirecionar usuários autenticados
const PublicRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }
  
  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }
  
  return <>{children}</>;
};

const AppRoutes = () => {
  return (
    <Routes>
    <Route path="/auth" element={
      <PublicRoute>
        <Auth />
      </PublicRoute>
    } />
    <Route path="/auth/callback" element={<AuthCallback />} />
    <Route path="/nova-senha" element={
      <PasswordRecoveryRoute>
        <NovaSenha />
      </PasswordRecoveryRoute>
    } />
    <Route path="/dashboard" element={
      <ProtectedRoute>
        <Dashboard />
      </ProtectedRoute>
    } />
    <Route path="/customers" element={
      <ProtectedRoute>
        <Customers />
      </ProtectedRoute>
    } />
    <Route path="/vehicles" element={
      <ProtectedRoute>
        <Vehicles />
      </ProtectedRoute>
    } />
    <Route path="/service-orders" element={
      <ProtectedRoute>
        <ServiceOrders />
      </ProtectedRoute>
    } />
    <Route path="/service-order-form" element={
      <ProtectedRoute>
        <ServiceOrderForm />
      </ProtectedRoute>
    } />
    <Route path="/service-order-form/:id" element={
      <ProtectedRoute>
        <ServiceOrderForm />
      </ProtectedRoute>
    } />
    <Route path="/inventory" element={
      <ProtectedRoute>
        <Inventory />
      </ProtectedRoute>
    } />
    <Route path="/schedule" element={
      <ProtectedRoute>
        <Schedule />
      </ProtectedRoute>
    } />
    <Route path="/financial" element={
      <ProtectedRoute>
        <Financial />
      </ProtectedRoute>
    } />
    <Route path="/reports" element={
      <ProtectedRoute>
        <Reports />
      </ProtectedRoute>
    } />
    <Route path="/team" element={
      <ProtectedRoute>
        <Team />
      </ProtectedRoute>
    } />
    <Route path="/communication" element={
      <ProtectedRoute>
        <Communication />
      </ProtectedRoute>
    } />
    <Route path="/settings" element={
      <ProtectedRoute>
        <Settings />
      </ProtectedRoute>
    } />
    <Route path="/plans" element={<Plans />} />
    <Route path="/" element={<Navigate to="/dashboard" replace />} />
    <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AuthProvider>
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;