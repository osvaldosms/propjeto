import React from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Crown, Lock, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { usePlanAccess } from '@/hooks/usePlanAccess';

interface PlanRestrictionBannerProps {
  requiredPlan: 'essencial' | 'profissional' | 'premium';
  feature: string;
  description?: string;
}

export const PlanRestrictionBanner: React.FC<PlanRestrictionBannerProps> = ({
  requiredPlan,
  feature,
  description
}) => {
  const navigate = useNavigate();
  const { planInfo } = usePlanAccess();

  const planNames = {
    essencial: 'Essencial',
    profissional: 'Profissional',
    premium: 'Premium'
  };

  const planColors = {
    essencial: 'text-blue-600',
    profissional: 'text-green-600', 
    premium: 'text-purple-600'
  };

  // DEVELOPMENT MODE: Banner disabled
  return null;
};