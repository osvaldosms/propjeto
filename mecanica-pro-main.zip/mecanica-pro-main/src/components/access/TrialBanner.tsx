import React from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Clock, Crown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { usePlanAccess } from '@/hooks/usePlanAccess';

export const TrialBanner: React.FC = () => {
  const navigate = useNavigate();
  const { planInfo } = usePlanAccess();

  if (!planInfo?.is_trial || planInfo.trial_expired) {
    return null;
  }

  const isExpiringSoon = planInfo.trial_days_left <= 3;

  return (
    <Alert className={`mb-4 ${isExpiringSoon ? 'border-red-200 bg-red-50' : 'border-blue-200 bg-blue-50'}`}>
      <Clock className={`h-4 w-4 ${isExpiringSoon ? 'text-red-600' : 'text-blue-600'}`} />
      <AlertDescription className={isExpiringSoon ? 'text-red-800' : 'text-blue-800'}>
        <div className="flex items-center justify-between">
          <div>
            <strong>
              {isExpiringSoon ? 'Avaliação expirando em breve!' : 'Período de Avaliação'}
            </strong>
            <p className="text-sm mt-1">
              Você tem <strong>{planInfo.trial_days_left} dias restantes</strong> do seu período de avaliação gratuito.
              {isExpiringSoon && ' Assine um plano para continuar usando todas as funcionalidades.'}
            </p>
          </div>
          <Button 
            onClick={() => navigate('/plans')}
            variant={isExpiringSoon ? 'default' : 'outline'}
            className={isExpiringSoon ? 'bg-red-600 hover:bg-red-700' : 'border-blue-300 text-blue-700 hover:bg-blue-100'}
          >
            <Crown className="h-4 w-4 mr-2" />
            Ver Planos
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  );
};