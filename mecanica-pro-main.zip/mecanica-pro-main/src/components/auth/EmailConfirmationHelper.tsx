import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Mail, RefreshCw } from 'lucide-react';
import { resendConfirmationEmail } from '@/utils/authUtils';
import { useToast } from '@/hooks/use-toast';

interface EmailConfirmationHelperProps {
  email: string;
  onBack: () => void;
}

export const EmailConfirmationHelper: React.FC<EmailConfirmationHelperProps> = ({ 
  email, 
  onBack 
}) => {
  const [isResending, setIsResending] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const { toast } = useToast();

  const handleResendEmail = async () => {
    setIsResending(true);
    
    try {
      const result = await resendConfirmationEmail(email);
      
      if (result.success) {
        setEmailSent(true);
        toast({
          title: "Email reenviado!",
          description: "Verifique sua caixa de entrada e spam.",
        });
      } else {
        toast({
          title: "Erro ao reenviar",
          description: result.error || "Tente novamente em alguns instantes.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro no sistema",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setIsResending(false);
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
          <Mail className="h-6 w-6 text-primary" />
        </div>
        <CardTitle className="text-2xl">Confirme seu Email</CardTitle>
        <CardDescription>
          Enviamos um link de confirmação para seu email
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <Alert>
          <Mail className="h-4 w-4" />
          <AlertDescription>
            <strong>Email enviado para:</strong><br />
            {email}
          </AlertDescription>
        </Alert>

        <div className="text-sm text-muted-foreground space-y-2">
          <p>Para continuar:</p>
          <ol className="list-decimal list-inside space-y-1 ml-2">
            <li>Verifique sua caixa de entrada</li>
            <li>Procure também na pasta de spam</li>
            <li>Clique no link de confirmação</li>
            <li>Você será redirecionado automaticamente</li>
          </ol>
        </div>

        {emailSent && (
          <Alert className="border-green-200 bg-green-50">
            <RefreshCw className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-700">
              Um novo email de confirmação foi enviado!
            </AlertDescription>
          </Alert>
        )}
        
        <div className="space-y-2">
          <Button
            variant="outline"
            className="w-full"
            onClick={handleResendEmail}
            disabled={isResending}
          >
            {isResending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Reenviando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Reenviar Email
              </>
            )}
          </Button>
          
          <Button
            variant="ghost"
            className="w-full"
            onClick={onBack}
          >
            Voltar ao Login
          </Button>
        </div>

        <div className="text-xs text-muted-foreground text-center">
          <p>Não recebeu o email? Verifique se o endereço está correto e tente reenviar.</p>
        </div>
      </CardContent>
    </Card>
  );
};