import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Wrench } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { loginFormSchema, sanitizeInput } from '@/lib/validation';
import { z } from 'zod';
import { EmailConfirmationHelper } from './EmailConfirmationHelper';

interface LoginFormProps {
  onToggleMode: () => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ onToggleMode }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [showEmailConfirmation, setShowEmailConfirmation] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { login, signInWithGoogle, resetPassword } = useAuth();
  const { toast } = useToast();

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    try {
      const result = await signInWithGoogle();
      if (result.success) {
        toast({
          title: "Redirecionando...",
          description: "Você será redirecionado para autenticação com Google.",
        });
      } else {
        toast({
          title: "Erro no login com Google",
          description: result.error || "Tente novamente.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro no sistema",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!email.trim()) {
      toast({
        title: "Email necessário",
        description: "Digite seu email para recuperar a senha.",
        variant: "destructive",
      });
      return;
    }

    setIsResetting(true);
    try {
      const result = await resetPassword(email.trim());
      if (result.success) {
        toast({
          title: "Email enviado!",
          description: "Verifique sua caixa de entrada para redefinir sua senha.",
        });
        setShowResetPassword(false);
      } else {
        toast({
          title: "Erro ao enviar email",
          description: result.error || "Tente novamente.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro no sistema",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setIsResetting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    
    try {
      const sanitizedData = {
        email: sanitizeInput(email),
        password: password
      };
      
      loginFormSchema.parse(sanitizedData);
      
      setIsLoading(true);
      
      const result = await login(sanitizedData.email, sanitizedData.password);
      
      if (result.success) {
        toast({
          title: "Login realizado!",
          description: "Bem-vindo ao sistema de gestão da oficina.",
        });
      } else {
        // Handle special error cases
        if (result.error === 'EMAIL_NOT_CONFIRMED') {
          setShowEmailConfirmation(true);
          toast({
            title: "Email não confirmado",
            description: "Verifique sua caixa de entrada para confirmar seu email.",
            variant: "destructive",
          });
          return;
        }
        
        // Show reset password option for credential errors
        if (result.error?.includes('incorretos') || result.error?.includes('Invalid login credentials')) {
          setShowResetPassword(true);
        }
        
        toast({
          title: "Erro no login",
          description: result.error || "Email ou senha incorretos.",
          variant: "destructive",
        });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
        
        toast({
          title: "Erro de validação",
          description: "Por favor, corrija os campos destacados",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Erro no sistema",
          description: "Tente novamente em alguns instantes.",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Show email confirmation helper if needed
  if (showEmailConfirmation) {
    return (
      <EmailConfirmationHelper 
        email={email}
        onBack={() => {
          setShowEmailConfirmation(false);
          setShowResetPassword(false);
        }}
      />
    );
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary">
          <Wrench className="h-6 w-6 text-primary-foreground" />
        </div>
        <CardTitle className="text-2xl">Entrar na Oficina</CardTitle>
        <CardDescription>
          Acesse o sistema de gestão da sua oficina
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isLoading}
              className={errors.email ? 'border-destructive' : ''}
            />
            {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password">Senha</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
              className={errors.password ? 'border-destructive' : ''}
            />
            {errors.password && <p className="text-sm text-destructive mt-1">{errors.password}</p>}
          </div>
          
          <Button
            type="submit"
            className="w-full"
            disabled={isLoading || isResetting}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Entrando...
              </>
            ) : (
              'Entrar'
            )}
          </Button>
          
          {showResetPassword && (
            <div className="mt-2 p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">
                Esqueceu sua senha? Digite seu email acima e clique no botão abaixo para receber um link de recuperação.
              </p>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="w-full"
                onClick={handleResetPassword}
                disabled={isLoading || isResetting || !email.trim()}
              >
                {isResetting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  'Recuperar Senha'
                )}
              </Button>
            </div>
          )}
          
          {!showResetPassword && (
            <button
              type="button"
              onClick={() => setShowResetPassword(true)}
              className="w-full text-sm text-muted-foreground hover:text-primary transition-colors mt-2"
              disabled={isLoading}
            >
              Esqueceu sua senha?
            </button>
          )}
        </form>

        <div className="mt-4">
          <Separator className="my-4" />
          <Button
            variant="outline"
            className="w-full"
            onClick={handleGoogleSignIn}
            disabled={isLoading || isResetting}
          >
            <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
              <path
                fill="currentColor"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="currentColor"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="currentColor"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              />
              <path
                fill="currentColor"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            Entrar com Google
          </Button>
        </div>
        
        <div className="mt-4 text-center text-sm">
          <span className="text-muted-foreground">Ainda não tem conta? </span>
          <button
            type="button"
            onClick={onToggleMode}
            className="text-primary hover:underline"
            disabled={isLoading || isResetting}
          >
            Cadastre sua oficina
          </button>
        </div>
      </CardContent>
    </Card>
  );
};