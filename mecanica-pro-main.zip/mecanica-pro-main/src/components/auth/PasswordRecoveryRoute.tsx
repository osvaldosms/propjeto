import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

interface PasswordRecoveryRouteProps {
  children: React.ReactNode;
}

export const PasswordRecoveryRoute: React.FC<PasswordRecoveryRouteProps> = ({ children }) => {
  const [isValidRecovery, setIsValidRecovery] = useState<boolean | null>(null);

  useEffect(() => {
    const checkRecoverySession = async () => {
      try {
        console.log('🔍 PasswordRecoveryRoute - Checking recovery session validity...');
        
        // CRÍTICO: Verificar se a URL contém type=recovery
        const hash = window.location.hash || '';
        const search = window.location.search || '';
        const isRecoveryUrl = hash.includes('type=recovery') || search.includes('type=recovery');
        
        console.log('🔍 URL Hash:', hash);
        console.log('🔍 URL Search:', search);
        console.log('🔍 Is Recovery URL:', isRecoveryUrl);
        
        if (!isRecoveryUrl) {
          console.warn('⚠️ No recovery type found in URL - Invalid access');
          setIsValidRecovery(false);
          return;
        }
        
        // Verificar se há uma sessão ativa
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('❌ Error checking session:', error);
          setIsValidRecovery(false);
          return;
        }

        if (!session) {
          console.warn('⚠️ No active session found for password recovery');
          setIsValidRecovery(false);
          return;
        }

        // SEGURANÇA: Verificar se é uma sessão de recovery válida
        console.log('✅ Valid recovery session found:', {
          userId: session.user?.id,
          email: session.user?.email,
          hasRecoveryUrl: isRecoveryUrl
        });
        
        setIsValidRecovery(true);
      } catch (error) {
        console.error('❌ Error in recovery session check:', error);
        setIsValidRecovery(false);
      }
    };

    checkRecoverySession();
  }, []);

  // Enquanto verifica, mostrar loading
  if (isValidRecovery === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Verificando sessão de recuperação...</p>
        </div>
      </div>
    );
  }

  // Se não é uma sessão válida de recovery, redirecionar para auth
  if (!isValidRecovery) {
    console.log('🚫 Invalid recovery session, redirecting to /auth');
    return <Navigate to="/auth" replace />;
  }

  // Se é válida, renderizar a página de nova senha
  return <>{children}</>;
};