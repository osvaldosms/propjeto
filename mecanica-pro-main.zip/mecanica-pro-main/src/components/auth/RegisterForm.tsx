import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Wrench } from 'lucide-react';
import { registerFormSchema, unformatPhone, unformatCnpj } from '@/lib/validation';
import { usePhoneMask } from '@/hooks/usePhoneMask';
import { useCnpjMask } from '@/hooks/useCnpjMask';
import type { z } from 'zod';
import { EmailConfirmationHelper } from './EmailConfirmationHelper';

type RegisterFormData = z.infer<typeof registerFormSchema>;

interface RegisterFormProps {
  onToggleMode: () => void;
}

export const RegisterForm: React.FC<RegisterFormProps> = ({ onToggleMode }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [showEmailConfirmation, setShowEmailConfirmation] = useState(false);
  const [registeredEmail, setRegisteredEmail] = useState('');
  const { register } = useAuth();
  const { toast } = useToast();

  const form = useForm<RegisterFormData>({
    resolver: zodResolver(registerFormSchema),
    defaultValues: {
      workshopName: '',
      cnpj: '',
      email: '',
      phone: '',
      address: '',
      password: '',
      confirmPassword: ''
    }
  });

  const { handleSubmit, register: registerField, formState: { errors }, setValue } = form;

  // Phone mask
  const phoneMask = usePhoneMask({
    onChange: (unformattedValue) => setValue('phone', unformattedValue)
  });

  // CNPJ mask
  const cnpjMask = useCnpjMask({
    onChange: (unformattedValue) => setValue('cnpj', unformattedValue)
  });

  const onSubmit = async (data: RegisterFormData) => {
    setIsLoading(true);
    
    try {
        const result = await register(
          data.email,
          data.password,
          {
            workshopName: data.workshopName,
            cnpj: data.cnpj,
            phone: data.phone,
            address: data.address,
          }
        );
      
      if (result.success) {
        // Handle email confirmation requirement
        if (result.error === 'EMAIL_CONFIRMATION_REQUIRED') {
          setRegisteredEmail(data.email);
          setShowEmailConfirmation(true);
          toast({
            title: "Confirme seu email",
            description: "Enviamos um link de confirmação para seu email.",
          });
          return;
        }
        
        toast({
          title: "Oficina cadastrada!",
          description: "Bem-vindo! Sua oficina foi registrada com sucesso.",
        });
      } else {
        toast({
          title: "Erro no cadastro",
          description: result.error || "Não foi possível registrar a oficina. Tente novamente.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro no sistema",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Show email confirmation helper if needed
  if (showEmailConfirmation) {
    return (
      <EmailConfirmationHelper 
        email={registeredEmail}
        onBack={() => {
          setShowEmailConfirmation(false);
          setRegisteredEmail('');
        }}
      />
    );
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary">
          <Wrench className="h-6 w-6 text-primary-foreground" />
        </div>
        <CardTitle className="text-2xl">Cadastrar Oficina</CardTitle>
        <CardDescription>
          Registre sua oficina e comece a usar o sistema
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="workshopName">Nome da Oficina *</Label>
            <Input
              id="workshopName"
              placeholder="Oficina Exemplo Ltda"
              disabled={isLoading}
              {...registerField('workshopName')}
            />
            {errors.workshopName && (
              <p className="text-sm text-destructive">{errors.workshopName.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="cnpj">CNPJ</Label>
            <Input
              id="cnpj"
              placeholder="00.000.000/0000-00"
              disabled={isLoading}
              value={cnpjMask.value}
              onChange={cnpjMask.onChange}
            />
            {errors.cnpj && (
              <p className="text-sm text-destructive">{errors.cnpj.message}</p>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              placeholder="contato@oficina.com"
              disabled={isLoading}
              {...registerField('email')}
            />
            {errors.email && (
              <p className="text-sm text-destructive">{errors.email.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Telefone</Label>
            <Input
              id="phone"
              placeholder="(11) 99999-9999"
              disabled={isLoading}
              value={phoneMask.value}
              onChange={phoneMask.onChange}
            />
            {errors.phone && (
              <p className="text-sm text-destructive">{errors.phone.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Endereço</Label>
            <Input
              id="address"
              placeholder="Rua Exemplo, 123 - São Paulo/SP"
              disabled={isLoading}
              {...registerField('address')}
            />
            {errors.address && (
              <p className="text-sm text-destructive">{errors.address.message}</p>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password">Senha *</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              disabled={isLoading}
              {...registerField('password')}
            />
            {errors.password && (
              <p className="text-sm text-destructive">{errors.password.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirmPassword">Confirmar Senha *</Label>
            <Input
              id="confirmPassword"
              type="password"
              placeholder="••••••••"
              disabled={isLoading}
              {...registerField('confirmPassword')}
            />
            {errors.confirmPassword && (
              <p className="text-sm text-destructive">{errors.confirmPassword.message}</p>
            )}
          </div>
          
          <Button
            type="submit"
            className="w-full"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Cadastrando...
              </>
            ) : (
              'Cadastrar Oficina'
            )}
          </Button>
        </form>
        
        <div className="mt-4 text-center text-sm">
          <span className="text-muted-foreground">Já tem uma conta? </span>
          <button
            type="button"
            onClick={onToggleMode}
            className="text-primary hover:underline"
            disabled={isLoading}
          >
            Fazer login
          </button>
        </div>
      </CardContent>
    </Card>
  );
};