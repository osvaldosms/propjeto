import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { usePhoneMask } from '@/hooks/usePhoneMask';
import { useCpfMask } from '@/hooks/useCpfMask';
import { usePlacaMask } from '@/hooks/usePlacaMask';
import { User, Car } from 'lucide-react';

interface ClienteVeiculoUnificadoProps {
  onSuccess?: (clienteId: string, veiculoId: string) => void;
  onCancel?: () => void;
}

export const ClienteVeiculoUnificado: React.FC<ClienteVeiculoUnificadoProps> = ({
  onSuccess,
  onCancel
}) => {
  const { empresa } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  // Hooks de formatação
  const phoneMask = usePhoneMask({
    onChange: (unformattedValue) => {
      setClienteData(prev => ({ ...prev, telefone: unformattedValue }));
    }
  });

  const cpfMask = useCpfMask({
    onChange: (unformattedValue) => {
      setClienteData(prev => ({ ...prev, cpf: unformattedValue }));
    }
  });

  // Estado do cliente
  const [clienteData, setClienteData] = useState({
    nome: '',
    telefone: '',
    email: '',
    endereco: '',
    cpf: ''
  });

  // Estado do veículo
  const [veiculoData, setVeiculoData] = useState({
    marca: '',
    modelo: '',
    ano: '',
    cor: '',
    placa: '',
    quilometragem: '',
    combustivel: ''
  });

  // Placa mask
  const placaMask = usePlacaMask({
    onChange: (formattedValue) => {
      setVeiculoData(prev => ({ ...prev, placa: formattedValue }));
    }
  });


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!empresa?.id) {
      toast({
        title: "Erro",
        description: "Empresa não encontrada. Tente novamente.",
        variant: "destructive",
      });
      return;
    }

    // Validações básicas
    if (!clienteData.nome.trim()) {
      toast({
        title: "Erro",
        description: "Nome do cliente é obrigatório.",
        variant: "destructive",
      });
      return;
    }

    if (!clienteData.cpf.trim()) {
      toast({
        title: "Erro",
        description: "CPF/CNPJ do cliente é obrigatório.",
        variant: "destructive",
      });
      return;
    }

    if (!clienteData.telefone.trim()) {
      toast({
        title: "Erro",
        description: "Telefone do cliente é obrigatório.",
        variant: "destructive",
      });
      return;
    }

    if (!veiculoData.marca.trim() || !veiculoData.modelo.trim()) {
      toast({
        title: "Erro",
        description: "Marca e modelo do veículo são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    if (!veiculoData.ano.trim()) {
      toast({
        title: "Erro",
        description: "Ano do veículo é obrigatório.",
        variant: "destructive",
      });
      return;
    }

    if (!veiculoData.placa.trim()) {
      toast({
        title: "Erro",
        description: "Placa do veículo é obrigatória.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      // 1. Criar o cliente
      const { data: novoCliente, error: clienteError } = await supabase
        .from('clientes')
        .insert({
          nome: clienteData.nome.trim(),
          telefone: clienteData.telefone.trim(),
          email: clienteData.email.trim() || null,
          endereco: clienteData.endereco.trim() || null,
          cpf: clienteData.cpf.trim(),
          empresa_id: empresa.id
        })
        .select()
        .single();

      if (clienteError) throw clienteError;

      // 2. Criar o veículo
      const { data: novoVeiculo, error: veiculoError } = await supabase
        .from('veiculos')
        .insert({
          marca: veiculoData.marca.trim(),
          modelo: veiculoData.modelo.trim(),
          ano: parseInt(veiculoData.ano),
          cor: veiculoData.cor.trim() || null,
          placa: veiculoData.placa.trim(),
          
          quilometragem: veiculoData.quilometragem ? parseInt(veiculoData.quilometragem) : null,
          combustivel: veiculoData.combustivel.trim() || null,
          cliente_id: novoCliente.id,
          empresa_id: empresa.id
        })
        .select()
        .single();

      if (veiculoError) throw veiculoError;

      toast({
        title: "Sucesso",
        description: `Cliente "${novoCliente.nome}" e veículo "${novoVeiculo.marca} ${novoVeiculo.modelo}" criados com sucesso.`,
      });

      // Chamar callback de sucesso com os IDs
      onSuccess?.(novoCliente.id, novoVeiculo.id);

    } catch (error: any) {
      console.error('Error creating client and vehicle:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao criar cliente e veículo.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Seção Cliente */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Dados do Cliente
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="nome">Nome Completo *</Label>
              <Input
                id="nome"
                value={clienteData.nome}
                onChange={(e) => setClienteData(prev => ({ ...prev, nome: e.target.value }))}
                placeholder="Digite o nome completo"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cpf">CPF/CNPJ *</Label>
              <Input
                id="cpf"
                value={cpfMask.value}
                onChange={cpfMask.onChange}
                placeholder="000.000.000-00 ou 00.000.000/0000-00"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="telefone">Telefone *</Label>
              <Input
                id="telefone"
                value={phoneMask.value}
                onChange={phoneMask.onChange}
                placeholder="(11) 99999-9999"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                value={clienteData.email}
                onChange={(e) => setClienteData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="cliente@email.com"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="endereco">Endereço</Label>
            <Textarea
              id="endereco"
              value={clienteData.endereco}
              onChange={(e) => setClienteData(prev => ({ ...prev, endereco: e.target.value }))}
              placeholder="Endereço completo"
              rows={2}
            />
          </div>
        </CardContent>
      </Card>

      <Separator />

      {/* Seção Veículo */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Car className="h-5 w-5" />
            Dados do Veículo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="marca">Marca *</Label>
              <Input
                id="marca"
                value={veiculoData.marca}
                onChange={(e) => setVeiculoData(prev => ({ ...prev, marca: e.target.value }))}
                placeholder="Ex: Toyota"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="modelo">Modelo *</Label>
              <Input
                id="modelo"
                value={veiculoData.modelo}
                onChange={(e) => setVeiculoData(prev => ({ ...prev, modelo: e.target.value }))}
                placeholder="Ex: Corolla"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ano">Ano *</Label>
              <Input
                id="ano"
                type="number"
                value={veiculoData.ano}
                onChange={(e) => setVeiculoData(prev => ({ ...prev, ano: e.target.value }))}
                placeholder="2020"
                min="1950"
                max={new Date().getFullYear() + 1}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cor">Cor</Label>
              <Input
                id="cor"
                value={veiculoData.cor}
                onChange={(e) => setVeiculoData(prev => ({ ...prev, cor: e.target.value }))}
                placeholder="Ex: Branco"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="placa">Placa *</Label>
              <Input
                id="placa"
                value={placaMask.value}
                onChange={placaMask.onChange}
                placeholder="ABC-1234 ou ABC1D23"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="quilometragem">Quilometragem</Label>
              <Input
                id="quilometragem"
                type="number"
                value={veiculoData.quilometragem}
                onChange={(e) => setVeiculoData(prev => ({ ...prev, quilometragem: e.target.value }))}
                placeholder="50000"
                min="0"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
            <div className="space-y-2">
              <Label htmlFor="combustivel">Combustível</Label>
              <Select value={veiculoData.combustivel} onValueChange={(value) => setVeiculoData(prev => ({ ...prev, combustivel: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o combustível" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Flex">Flex</SelectItem>
                  <SelectItem value="Gasolina">Gasolina</SelectItem>
                  <SelectItem value="Elétrico">Elétrico</SelectItem>
                  <SelectItem value="Híbrido">Híbrido</SelectItem>
                  <SelectItem value="Diesel">Diesel</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Botões de ação */}
      <div className="flex justify-end gap-4">
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>
            Cancelar
          </Button>
        )}
        <Button type="submit" disabled={loading}>
          {loading ? 'Criando...' : 'Criar Cliente e Veículo'}
        </Button>
      </div>
    </form>
  );
};