import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  OrdemServicoCompleta, 
  StatusOSLabels, 
  StatusOSColors 
} from '@/types/ordem-servico';
import { Cliente, Veiculo } from '@/types/workshop';

interface OSVisualizationProps {
  ordem: OrdemServicoCompleta & { servicos?: any[], pecas?: any[] };
  cliente?: Cliente;
  veiculo?: Veiculo;
  empresa?: any;
}

export const OSVisualization: React.FC<OSVisualizationProps> = ({
  ordem,
  cliente,
  veiculo,
  empresa
}) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const formatCNPJ = (cnpj: string): string => {
    const cleaned = cnpj.replace(/\D/g, '');
    if (cleaned.length === 14) {
      return cleaned.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
    }
    return cnpj;
  };

  const formatPhone = (phone: string): string => {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 11) {
      return cleaned.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    } else if (cleaned.length === 10) {
      return cleaned.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
    }
    return phone;
  };

  return (
    <div className="max-w-4xl mx-auto bg-white text-gray-900 font-sans">
      {/* Cabeçalho da OS - igual ao PDF */}
      <div className="flex justify-between items-start p-6 border-b border-gray-300 mb-6">
        <div className="flex-1">
          {empresa?.logo && (
            <img 
              src={empresa.logo} 
              alt="Logo" 
              className="max-h-20 max-w-48 object-contain"
            />
          )}
        </div>
        
        <div className="flex-2 text-center">
          <h1 className="text-lg font-bold text-gray-800 uppercase tracking-wide">
            {empresa?.nome || 'Oficina'}
          </h1>
        </div>
        
        <div className="flex-1 text-right text-xs text-gray-600 leading-relaxed">
          {empresa?.responsavel_tecnico && (
            <p className="mb-1">Responsável: {empresa.responsavel_tecnico}</p>
          )}
          {empresa?.cnpj && (
            <p className="mb-1">CNPJ: {formatCNPJ(empresa.cnpj)}</p>
          )}
          {empresa?.endereco && (
            <p className="mb-1">{empresa.endereco}</p>
          )}
          {empresa?.telefone && (
            <p className="mb-1">Tel/WhatsApp: {formatPhone(empresa.telefone)}</p>
          )}
          <div className="border-t border-gray-300 pt-1 mt-2">
            <p className="text-[10px]">Data: {formatDate(new Date().toISOString())}</p>
          </div>
        </div>
      </div>

      {/* Título */}
      <div className="text-center mb-6">
        <h2 className="text-base font-bold text-gray-800 uppercase tracking-wider">
          ORDEM DE SERVIÇO
        </h2>
        <p className="text-sm text-gray-600 mt-1">Nº {ordem.numero_os}</p>
      </div>

      {/* Informações Básicas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Cliente */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-700">DADOS DO CLIENTE</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1 text-sm">
            <p><strong>Nome:</strong> {cliente?.nome || 'Cliente não encontrado'}</p>
            {cliente?.telefone && <p><strong>Telefone:</strong> {formatPhone(cliente.telefone)}</p>}
            {cliente?.cpf && <p><strong>CPF:</strong> {cliente.cpf}</p>}
            {cliente?.email && <p><strong>E-mail:</strong> {cliente.email}</p>}
            {cliente?.endereco && <p><strong>Endereço:</strong> {cliente.endereco}</p>}
          </CardContent>
        </Card>

        {/* Veículo */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-700">DADOS DO VEÍCULO</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1 text-sm">
            <p><strong>Marca/Modelo:</strong> {veiculo ? `${veiculo.marca} ${veiculo.modelo}` : 'Veículo não encontrado'}</p>
            {veiculo?.placa && <p><strong>Placa:</strong> {veiculo.placa}</p>}
            {veiculo?.ano && <p><strong>Ano:</strong> {veiculo.ano}</p>}
            {veiculo?.cor && <p><strong>Cor:</strong> {veiculo.cor}</p>}
            {veiculo?.combustivel && <p><strong>Combustível:</strong> {veiculo.combustivel}</p>}
            {veiculo?.quilometragem && <p><strong>KM:</strong> {veiculo.quilometragem.toLocaleString()}</p>}
          </CardContent>
        </Card>
      </div>

      {/* Status e Datas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="text-center">
          <p className="text-xs text-gray-600 mb-1">STATUS</p>
          <Badge className={`${StatusOSColors[ordem.status]} text-xs`}>
            {StatusOSLabels[ordem.status]}
          </Badge>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-600 mb-1">DATA ABERTURA</p>
          <p className="text-sm font-medium">{formatDate(ordem.data_pedido)}</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-600 mb-1">PREVISÃO ENTREGA</p>
          <p className="text-sm font-medium">{formatDate(ordem.data_fim)}</p>
        </div>
      </div>

      <Separator className="my-6" />

      {/* Defeitos/Reclamações */}
      {ordem.defeitos_reclamacoes && (
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-2">DEFEITO RELATADO / RECLAMAÇÃO</h3>
          <div className="bg-gray-50 p-3 rounded border">
            <p className="text-sm">{ordem.defeitos_reclamacoes}</p>
          </div>
        </div>
      )}

      {/* Descrição do Serviço */}
      {ordem.descricao && (
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-2">DESCRIÇÃO DO SERVIÇO</h3>
          <div className="bg-gray-50 p-3 rounded border">
            <p className="text-sm">{ordem.descricao}</p>
          </div>
        </div>
      )}

      {/* Serviços */}
      {ordem.servicos && ordem.servicos.length > 0 && (
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">SERVIÇOS EXECUTADOS</h3>
          <div className="border rounded">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-2 border-b">Descrição</th>
                  <th className="text-center p-2 border-b w-20">Qtd</th>
                  <th className="text-right p-2 border-b w-24">Valor Unit.</th>
                  <th className="text-right p-2 border-b w-24">Subtotal</th>
                </tr>
              </thead>
              <tbody>
                {ordem.servicos.map((servico, index) => (
                  <tr key={index} className="border-b last:border-b-0">
                    <td className="p-2">{servico.descricao}</td>
                    <td className="p-2 text-center">{servico.quantidade}</td>
                    <td className="p-2 text-right">{formatCurrency(servico.valor)}</td>
                    <td className="p-2 text-right font-medium">{formatCurrency(servico.subtotal)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="bg-gray-50 p-2 border-t">
              <div className="text-right text-sm font-semibold">
                Total Serviços: {formatCurrency(ordem.total_servicos)}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Peças */}
      {ordem.pecas && ordem.pecas.length > 0 && (
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">PEÇAS UTILIZADAS</h3>
          <div className="border rounded">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-2 border-b">Descrição</th>
                  <th className="text-center p-2 border-b w-20">Qtd</th>
                  <th className="text-right p-2 border-b w-24">Valor Unit.</th>
                  <th className="text-right p-2 border-b w-24">Subtotal</th>
                </tr>
              </thead>
              <tbody>
                {ordem.pecas.map((peca, index) => (
                  <tr key={index} className="border-b last:border-b-0">
                    <td className="p-2">
                      {peca.descricao}
                      {peca.observacao && (
                        <div className="text-xs text-gray-600 mt-1">{peca.observacao}</div>
                      )}
                    </td>
                    <td className="p-2 text-center">{peca.quantidade}</td>
                    <td className="p-2 text-right">{formatCurrency(peca.valor)}</td>
                    <td className="p-2 text-right font-medium">{formatCurrency(peca.subtotal)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="bg-gray-50 p-2 border-t">
              <div className="text-right text-sm font-semibold">
                Total Peças: {formatCurrency(ordem.total_pecas)}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Resumo Financeiro */}
      <div className="mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-700">RESUMO FINANCEIRO</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Subtotal Serviços:</span>
                <span>{formatCurrency(ordem.total_servicos)}</span>
              </div>
              <div className="flex justify-between">
                <span>Subtotal Peças:</span>
                <span>{formatCurrency(ordem.total_pecas)}</span>
              </div>
              {ordem.desconto_valor > 0 && (
                <div className="flex justify-between text-red-600">
                  <span>Desconto:</span>
                  <span>-{formatCurrency(ordem.desconto_valor)}</span>
                </div>
              )}
              {ordem.desconto_percentual > 0 && (
                <div className="flex justify-between text-red-600">
                  <span>Desconto (%):</span>
                  <span>{ordem.desconto_percentual}%</span>
                </div>
              )}
              {ordem.taxa_entrega > 0 && (
                <div className="flex justify-between">
                  <span>Taxa de Entrega:</span>
                  <span>{formatCurrency(ordem.taxa_entrega)}</span>
                </div>
              )}
              {ordem.outras_taxas > 0 && (
                <div className="flex justify-between">
                  <span>Outras Taxas:</span>
                  <span>{formatCurrency(ordem.outras_taxas)}</span>
                </div>
              )}
              <Separator />
              <div className="flex justify-between text-base font-bold">
                <span>TOTAL GERAL:</span>
                <span>{formatCurrency(ordem.total_geral)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Relatório Técnico */}
      {ordem.relatorio_tecnico && (
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-2">RELATÓRIO TÉCNICO</h3>
          <div className="bg-gray-50 p-3 rounded border">
            <p className="text-sm">{ordem.relatorio_tecnico}</p>
          </div>
        </div>
      )}

      {/* Condições e Garantia */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {ordem.condicoes_pagamento && (
          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-2">CONDIÇÕES DE PAGAMENTO</h3>
            <div className="bg-gray-50 p-3 rounded border">
              <p className="text-sm">{ordem.condicoes_pagamento}</p>
            </div>
          </div>
        )}

        {ordem.garantia && (
          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-2">GARANTIA</h3>
            <div className="bg-gray-50 p-3 rounded border">
              <p className="text-sm">{ordem.garantia}</p>
            </div>
          </div>
        )}
      </div>

      {/* Cláusulas Contratuais */}
      {ordem.clausulas_contratuais && (
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-2">CLÁUSULAS CONTRATUAIS</h3>
          <div className="bg-gray-50 p-3 rounded border">
            <p className="text-sm">{ordem.clausulas_contratuais}</p>
          </div>
        </div>
      )}
    </div>
  );
};