import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { 
  Plus, Save, FileText, Printer, MessageCircle, Mail,
  DollarSign, Trash2, ChevronDown, Paperclip, Calculator
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { NovoClienteVeiculoModal } from '@/components/modals/NovoClienteVeiculoModal';
import { 
  OrdemServicoCompleta, 
  ServicoOS, 
  PecaOS, 
  StatusOS, 
  StatusOSLabels
} from '@/types/ordem-servico';
import { Cliente, Veiculo } from '@/types/workshop';

interface OrdemServicoFormCompletaProps {
  ordemExistente?: (OrdemServicoCompleta & { servicos?: any[], pecas?: any[] }) | null;
  onSubmit: (data: any) => void;
  onCancel: () => void;
}

export const OrdemServicoFormCompleta: React.FC<OrdemServicoFormCompletaProps> = ({
  ordemExistente,
  onSubmit,
  onCancel
}) => {
  const { empresa } = useAuth();
  const { toast } = useToast();
  
  // Estados básicos
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [selectedCliente, setSelectedCliente] = useState<Cliente | null>(null);
  const [selectedVeiculo, setSelectedVeiculo] = useState<Veiculo | null>(null);
  const [loading, setLoading] = useState(false);
  const [showClienteVeiculoModal, setShowClienteVeiculoModal] = useState(false);
  
  // Estados para serviços e peças
  const [servicos, setServicos] = useState<any[]>([]);
  const [pecas, setPecas] = useState<any[]>([]);

  const { register, handleSubmit, formState: { errors }, setValue, watch } = useForm<any>({
    defaultValues: {
      status: 'orcamento' as StatusOS,
      data_pedido: new Date().toISOString().split('T')[0],
      data_inicio: new Date().toISOString().split('T')[0],
      cliente_id: '',
      veiculo_id: '',
      previsao_entrega: '',
      defeitos_reclamacoes: '',
      mecanico_responsavel: '',
      numero_indicacao: '',
      desconto_valor: 0,
      taxa_entrega: 0,
      outras_taxas: 0,
      condicoes_pagamento: 'PIX, Cartão (até 3x sem juros), Débito, Dinheiro',
      garantia: 'Garantia de 90 dias para serviços executados.',
      clausulas_contratuais: 'O cliente autoriza a execução dos serviços descritos e se responsabiliza pelo pagamento.',
    }
  });

  // Carregamento inicial
  useEffect(() => {
    loadClientes();
    if (ordemExistente) {
      preencherFormularioExistente();
    }
  }, [ordemExistente]);

  const loadClientes = async () => {
    if (!empresa?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .eq('empresa_id', empresa.id)
        .order('nome');
      
      if (error) throw error;
      setClientes(data || []);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao carregar clientes",
        variant: "destructive",
      });
    }
  };

  const loadVeiculos = async (clienteId: string) => {
    if (!clienteId) {
      setVeiculos([]);
      return;
    }
    
    try {
      const { data, error } = await supabase
        .from('veiculos')
        .select('*')
        .eq('cliente_id', clienteId)
        .order('marca, modelo');
      
      if (error) throw error;
      setVeiculos(data || []);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao carregar veículos",
        variant: "destructive",
      });
    }
  };

  const preencherFormularioExistente = async () => {
    if (!ordemExistente) return;

    try {
      // Preencher dados básicos
      setValue('status', ordemExistente.status);
      setValue('data_pedido', ordemExistente.data_pedido?.split('T')[0] || '');
      setValue('data_inicio', ordemExistente.data_inicio?.split('T')[0] || '');
      setValue('previsao_entrega', ordemExistente.data_fim?.split('T')[0] || '');
      setValue('cliente_id', ordemExistente.cliente_id);
      setValue('veiculo_id', ordemExistente.veiculo_id);
      setValue('defeitos_reclamacoes', ordemExistente.defeitos_reclamacoes || '');
      setValue('descricao', ordemExistente.descricao || '');
      setValue('relatorio_tecnico', ordemExistente.relatorio_tecnico || '');
      setValue('desconto_valor', ordemExistente.desconto_valor || 0);
      setValue('taxa_entrega', ordemExistente.taxa_entrega || 0);
      setValue('outras_taxas', ordemExistente.outras_taxas || 0);
      setValue('condicoes_pagamento', ordemExistente.condicoes_pagamento || '');
      setValue('garantia', ordemExistente.garantia || '');
      setValue('clausulas_contratuais', ordemExistente.clausulas_contratuais || '');
      setValue('informacoes_adicionais', ordemExistente.informacoes_adicionais || '');

      // Encontrar e selecionar cliente
      const cliente = clientes.find(c => c.id === ordemExistente.cliente_id);
      if (cliente) {
        setSelectedCliente(cliente);
        // Carregar veículos do cliente
        await loadVeiculos(cliente.id);
      }

      // Preencher serviços
      if ((ordemExistente as any).servicos && (ordemExistente as any).servicos.length > 0) {
        setServicos((ordemExistente as any).servicos.map((s: any) => ({
          descricao: s.descricao || '',
          valor: s.valor || 0,
          quantidade: s.quantidade || 1,
          observacoes: ''
        })));
      }

      // Preencher peças
      if ((ordemExistente as any).pecas && (ordemExistente as any).pecas.length > 0) {
        setPecas((ordemExistente as any).pecas.map((p: any) => ({
          descricao: p.descricao || '',
          valor: p.valor || 0,
          quantidade: p.quantidade || 1,
          observacoes: p.observacao || ''
        })));
      }

      // Carregar cliente e veículo usando queries diretas
      const { data: clienteData } = await supabase
        .from('clientes')
        .select('*')
        .eq('id', ordemExistente.cliente_id)
        .single();

      if (clienteData) {
        setSelectedCliente(clienteData);
        setValue('cliente_id', clienteData.id);
      }

      const { data: veiculoData } = await supabase
        .from('veiculos')
        .select('*')
        .eq('id', ordemExistente.veiculo_id)
        .single();

      if (veiculoData) {
        setSelectedVeiculo(veiculoData);
        setValue('veiculo_id', veiculoData.id);
        // Carregar veículos do cliente para popular o select
        await loadVeiculos(veiculoData.cliente_id);
      }

    } catch (error) {
      console.error('Erro ao preencher formulário:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar dados da ordem de serviço",
        variant: "destructive",
      });
    }
  };

  const adicionarServico = () => {
    setServicos([...servicos, {
      descricao: '',
      valor: 0,
      quantidade: 1,
      observacoes: ''
    }]);
  };

  const removerServico = (index: number) => {
    setServicos(servicos.filter((_, i) => i !== index));
  };

  const atualizarServico = (index: number, campo: string, valor: any) => {
    const novosServicos = [...servicos];
    novosServicos[index] = { ...novosServicos[index], [campo]: valor };
    setServicos(novosServicos);
  };

  const adicionarPeca = () => {
    setPecas([...pecas, {
      descricao: '',
      valor: 0,
      quantidade: 1,
      observacoes: ''
    }]);
  };

  const removerPeca = (index: number) => {
    setPecas(pecas.filter((_, i) => i !== index));
  };

  const atualizarPeca = (index: number, campo: string, valor: any) => {
    const novasPecas = [...pecas];
    novasPecas[index] = { ...novasPecas[index], [campo]: valor };
    setPecas(novasPecas);
  };

  const calcularTotalServicos = () => {
    return servicos.reduce((total, servico) => total + (servico.valor * servico.quantidade), 0);
  };

  const calcularTotalPecas = () => {
    return pecas.reduce((total, peca) => total + (peca.valor * peca.quantidade), 0);
  };

  const calcularTotalGeral = () => {
    const desconto = watch('desconto_valor') || 0;
    const taxaEntrega = watch('taxa_entrega') || 0;
    const outrasTaxas = watch('outras_taxas') || 0;
    
    return calcularTotalServicos() + calcularTotalPecas() - desconto + taxaEntrega + outrasTaxas;
  };

  const handleExportPDF = async () => {
    toast({
      title: "Em desenvolvimento",
      description: "Funcionalidade de PDF será implementada em breve",
    });
  };

  const handleFormSubmit = async (data: any, isDraft = false) => {
    if (!selectedCliente || !selectedVeiculo) {
      toast({
        title: "Campos obrigatórios",
        description: "Selecione um cliente e um veículo.",
        variant: "destructive",
      });
      return;
    }

    // Para rascunho, não exigir serviços/peças
    if (!isDraft && servicos.length === 0 && pecas.length === 0) {
      toast({
        title: "Itens obrigatórios",
        description: "Adicione pelo menos um serviço ou peça.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const dadosCompletos = {
        ...data,
        status: isDraft ? 'rascunho' : data.status,
        cliente_id: selectedCliente.id,
        veiculo_id: selectedVeiculo.id,
        servicos,
        pecas,
        total_servicos: calcularTotalServicos(),
        total_pecas: calcularTotalPecas(),
        total_geral: calcularTotalGeral(),
      };

      await onSubmit(dadosCompletos);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveAsDraft = () => {
    handleSubmit((data) => handleFormSubmit(data, true))();
  };

  const handleClienteVeiculoCreated = async (clienteId: string, veiculoId: string) => {
    try {
      // Recarregar lista de clientes
      const { data: clientesUpdated, error: clientesError } = await supabase
        .from('clientes')
        .select('*')
        .eq('empresa_id', empresa?.id)
        .order('nome');
      
      if (!clientesError && clientesUpdated) {
        setClientes(clientesUpdated);
        
        // Encontrar e selecionar o novo cliente
        const novoCliente = clientesUpdated.find(c => c.id === clienteId);
        if (novoCliente) {
          setSelectedCliente(novoCliente);
          setValue('cliente_id', clienteId);
          
          // Carregar veículos do cliente e selecionar o novo
          const { data: veiculosUpdated, error: veiculosError } = await supabase
            .from('veiculos')
            .select('*')
            .eq('cliente_id', clienteId)
            .order('marca, modelo');
          
          if (!veiculosError && veiculosUpdated) {
            setVeiculos(veiculosUpdated);
            
            const novoVeiculo = veiculosUpdated.find(v => v.id === veiculoId);
            if (novoVeiculo) {
              setSelectedVeiculo(novoVeiculo);
              setValue('veiculo_id', veiculoId);
            }
          }
        }
      }
      
      setShowClienteVeiculoModal(false);
      
      toast({
        title: "Sucesso",
        description: "Cliente e veículo criados e selecionados automaticamente.",
      });
    } catch (error) {
      console.error('Erro ao processar cliente/veículo criados:', error);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      {/* Top Bar */}
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-border">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold">Nova Ordem de Serviço</h1>
          {ordemExistente && (
            <span className="text-sm text-muted-foreground">#{ordemExistente.numero_os}</span>
          )}
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={handleExportPDF}>
            <Printer className="h-4 w-4 mr-2" />
            Imprimir
          </Button>
          <Button variant="outline" size="sm">
            <MessageCircle className="h-4 w-4 mr-2" />
            WhatsApp
          </Button>
          <Button variant="outline" size="sm">
            <Mail className="h-4 w-4 mr-2" />
            E-mail
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit((data) => handleFormSubmit(data, false))} className="space-y-6">
        {/* Card: Dados Gerais */}
        <Card className="shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm uppercase tracking-wide text-muted-foreground flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Dados Gerais
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Coluna 1: Cliente e Veículo */}
              <div className="space-y-4">
              {/* Cliente */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Label className="text-sm text-muted-foreground">Cliente <span className="text-destructive">*</span></Label>
                  <Button 
                    type="button" 
                    variant="default"
                    size="sm"
                    onClick={() => setShowClienteVeiculoModal(true)}
                    className="flex items-center gap-2 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-md hover:shadow-lg transition-all duration-200 hover:scale-[1.02] border-0 text-primary-foreground font-medium"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Novo Cliente</span>
                  </Button>
                </div>
                <Select 
                  value={selectedCliente?.id || ''} 
                  onValueChange={(value) => {
                    const cliente = clientes.find(c => c.id === value);
                    setSelectedCliente(cliente || null);
                    setValue('cliente_id', value);
                    if (cliente) {
                      loadVeiculos(cliente.id);
                      setSelectedVeiculo(null);
                      setValue('veiculo_id', '');
                    }
                  }}
                >
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder="Selecione um cliente" />
                  </SelectTrigger>
                  <SelectContent className="max-h-60">
                    {clientes.map(cliente => (
                      <SelectItem key={cliente.id} value={cliente.id}>
                        <div className="flex flex-col">
                          <span className="font-medium">{cliente.nome}</span>
                          <span className="text-xs text-muted-foreground">{cliente.telefone || cliente.email}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.cliente_id && (
                  <p className="text-xs text-destructive">{String(errors.cliente_id.message)}</p>
                )}
              </div>

              {/* Veículo */}
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Veículo <span className="text-destructive">*</span></Label>
                <Select 
                  value={selectedVeiculo?.id || ''} 
                  onValueChange={(value) => {
                    const veiculo = veiculos.find(v => v.id === value);
                    setSelectedVeiculo(veiculo || null);
                    setValue('veiculo_id', value);
                  }}
                  disabled={!selectedCliente}
                >
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder={selectedCliente ? "Selecione um veículo" : "Selecione primeiro um cliente"} />
                  </SelectTrigger>
                  <SelectContent>
                    {veiculos.map(veiculo => (
                      <SelectItem key={veiculo.id} value={veiculo.id}>
                        <div className="flex flex-col">
                          <span className="font-medium">{veiculo.marca} {veiculo.modelo}</span>
                          <span className="text-xs text-muted-foreground">{veiculo.placa} • {veiculo.ano}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.veiculo_id && (
                  <p className="text-xs text-destructive">{String(errors.veiculo_id.message)}</p>
                )}
              </div>
              </div>

              {/* Coluna 2: Status e Datas */}
              <div className="space-y-4">
              {/* Status */}
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Status</Label>
                <Select defaultValue="orcamento" onValueChange={(value) => setValue('status', value as StatusOS)}>
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(StatusOSLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Data do Pedido */}
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Data do Pedido <span className="text-destructive">*</span></Label>
                <Input
                  type="date"
                  className="bg-background"
                  {...register('data_pedido', { required: 'Data do pedido é obrigatória' })}
                />
                {errors.data_pedido && (
                  <p className="text-xs text-destructive">{String(errors.data_pedido.message)}</p>
                )}
              </div>

              {/* Data de Início */}
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Data de Início <span className="text-destructive">*</span></Label>
                <Input
                  type="date"
                  className="bg-background"
                  {...register('data_inicio', { required: 'Data de início é obrigatória' })}
                />
                {errors.data_inicio && (
                  <p className="text-xs text-destructive">{String(errors.data_inicio.message)}</p>
                )}
              </div>

              {/* Previsão de Entrega */}
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Previsão de Entrega</Label>
                <Input
                  type="date"
                  className="bg-background"
                  {...register('previsao_entrega')}
                />
              </div>

              {/* Mecânico Responsável */}
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Mecânico Responsável</Label>
                <Input
                  className="bg-background"
                  placeholder="Nome do mecânico"
                  {...register('mecanico_responsavel')}
                />
              </div>

              {/* Nº Indicação */}
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Nº Indicação</Label>
                <Input
                  className="bg-background"
                  placeholder="Opcional"
                  {...register('numero_indicacao')}
                />
              </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Card: Diagnóstico e Reclamações */}
        <Card className="shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm uppercase tracking-wide text-muted-foreground">
              Diagnóstico e Reclamações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              className="bg-background"
              rows={4}
              placeholder="Descreva detalhadamente o defeito relatado pelo cliente..."
              {...register('defeitos_reclamacoes')}
            />
          </CardContent>
        </Card>

        {/* Card: Serviços e Peças */}
        <Card className="shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm uppercase tracking-wide text-muted-foreground">
              Serviços e Peças
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Serviços */}
            <div className="border border-dashed border-border rounded-lg p-4">
              <div className="mb-4">
                <h3 className="font-medium">Serviços</h3>
              </div>
              
              <div className="space-y-3">
                {/* Cabeçalho da tabela */}
                <div className="grid grid-cols-12 gap-2 text-sm text-muted-foreground border-b pb-2">
                  <div className="col-span-4">Serviço</div>
                  <div className="col-span-2">Valor Unitário</div>
                  <div className="col-span-1">Qtd</div>
                  <div className="col-span-3">Obs.</div>
                  <div className="col-span-2 text-right">Subtotal</div>
                </div>
                
                {/* Linhas de serviços */}
                {servicos.map((servico, index) => (
                  <div key={index} className="grid grid-cols-12 gap-2 items-center">
                    <div className="col-span-4">
                      <Input
                        className="bg-background"
                        placeholder="Ex: Troca de óleo"
                        value={servico.descricao}
                        onChange={(e) => atualizarServico(index, 'descricao', e.target.value)}
                      />
                    </div>
                    <div className="col-span-2">
                      <Input
                        className="bg-background text-right"
                        type="number"
                        step="0.01"
                        min="0"
                        value={servico.valor}
                        onChange={(e) => atualizarServico(index, 'valor', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div className="col-span-1">
                      <Input
                        className="bg-background"
                        type="number"
                        min="1"
                        value={servico.quantidade}
                        onChange={(e) => atualizarServico(index, 'quantidade', parseInt(e.target.value) || 1)}
                      />
                    </div>
                    <div className="col-span-3">
                      <Input
                        className="bg-background"
                        placeholder="Opcional"
                        value={servico.observacoes}
                        onChange={(e) => atualizarServico(index, 'observacoes', e.target.value)}
                      />
                    </div>
                    <div className="col-span-1 text-right font-mono">
                      R$ {(servico.valor * servico.quantidade).toFixed(2)}
                    </div>
                    <div className="col-span-1 text-right">
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removerServico(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                 ))}
               </div>
               
               <Button type="button" variant="outline" size="sm" onClick={adicionarServico}>
                 <Plus className="h-4 w-4 mr-2" />
                 Adicionar Serviço
               </Button>
            </div>

            {/* Peças */}
            <div className="border border-dashed border-border rounded-lg p-4">
              <div className="mb-4">
                <h3 className="font-medium">Peças</h3>
              </div>
              
              <div className="space-y-3">
                {/* Cabeçalho da tabela */}
                <div className="grid grid-cols-12 gap-2 text-sm text-muted-foreground border-b pb-2">
                  <div className="col-span-4">Peça</div>
                  <div className="col-span-2">Valor Unitário</div>
                  <div className="col-span-1">Qtd</div>
                  <div className="col-span-3">Obs.</div>
                  <div className="col-span-2 text-right">Subtotal</div>
                </div>
                
                {/* Linhas de peças */}
                {pecas.map((peca, index) => (
                  <div key={index} className="grid grid-cols-12 gap-2 items-center">
                    <div className="col-span-4">
                      <Input
                        className="bg-background"
                        placeholder="Ex: Filtro de óleo"
                        value={peca.descricao}
                        onChange={(e) => atualizarPeca(index, 'descricao', e.target.value)}
                      />
                    </div>
                    <div className="col-span-2">
                      <Input
                        className="bg-background text-right"
                        type="number"
                        step="0.01"
                        min="0"
                        value={peca.valor}
                        onChange={(e) => atualizarPeca(index, 'valor', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div className="col-span-1">
                      <Input
                        className="bg-background"
                        type="number"
                        min="1"
                        value={peca.quantidade}
                        onChange={(e) => atualizarPeca(index, 'quantidade', parseInt(e.target.value) || 1)}
                      />
                    </div>
                    <div className="col-span-3">
                      <Input
                        className="bg-background"
                        placeholder="Opcional"
                        value={peca.observacoes}
                        onChange={(e) => atualizarPeca(index, 'observacoes', e.target.value)}
                      />
                    </div>
                    <div className="col-span-1 text-right font-mono">
                      R$ {(peca.valor * peca.quantidade).toFixed(2)}
                    </div>
                    <div className="col-span-1 text-right">
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removerPeca(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                 ))}
               </div>
               
               <Button type="button" variant="outline" size="sm" onClick={adicionarPeca}>
                 <Plus className="h-4 w-4 mr-2" />
                 Adicionar Peça
               </Button>
            </div>
          </CardContent>
        </Card>

        {/* Card: Resumo Financeiro */}
        <Card className="shadow-sm border-green-500/20 bg-green-50/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm uppercase tracking-wide text-muted-foreground flex items-center gap-2">
              <Calculator className="h-4 w-4" />
              Resumo Financeiro
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Desconto (R$)</Label>
                <Input
                  className="bg-background text-right"
                  type="number"
                  step="0.01"
                  min="0"
                  {...register('desconto_valor')}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Taxa de Entrega (R$)</Label>
                <Input
                  className="bg-background text-right"
                  type="number"
                  step="0.01"
                  min="0"
                  {...register('taxa_entrega')}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Outras Taxas (R$)</Label>
                <Input
                  className="bg-background text-right"
                  type="number"
                  step="0.01"
                  min="0"
                  {...register('outras_taxas')}
                />
              </div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-green-100/10 border border-green-500/30 rounded-lg">
              <div className="text-lg font-medium">VALOR TOTAL</div>
              <div className="text-2xl font-bold text-green-500 font-mono">
                R$ {calcularTotalGeral().toFixed(2)}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Cards Colapsáveis */}
        <Collapsible>
          <Card className="shadow-sm">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm uppercase tracking-wide text-muted-foreground flex items-center justify-between">
                  <span>Condições de Pagamento e Garantia</span>
                  <ChevronDown className="h-4 w-4" />
                </CardTitle>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-sm text-muted-foreground">Condições de Pagamento</Label>
                    <Textarea
                      className="bg-background"
                      rows={3}
                      placeholder="Ex.: 3x no cartão sem juros / Pix / Débito / Espécie"
                      {...register('condicoes_pagamento')}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm text-muted-foreground">Garantia</Label>
                    <Textarea
                      className="bg-background"
                      rows={3}
                      placeholder="Ex.: 90 dias para serviços executados."
                      {...register('garantia')}
                    />
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        <Collapsible>
          <Card className="shadow-sm">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm uppercase tracking-wide text-muted-foreground flex items-center justify-between">
                  <span>Cláusulas Contratuais</span>
                  <ChevronDown className="h-4 w-4" />
                </CardTitle>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent>
                <Textarea
                  className="bg-background"
                  rows={6}
                  placeholder="Texto padrão das cláusulas contratuais..."
                  {...register('clausulas_contratuais')}
                />
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        <Collapsible>
          <Card className="shadow-sm">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm uppercase tracking-wide text-muted-foreground flex items-center justify-between">
                  <span>Anexos e Documentos</span>
                  <ChevronDown className="h-4 w-4" />
                </CardTitle>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent>
                <div className="text-center py-8 border-2 border-dashed border-border rounded-lg">
                  <Button type="button" variant="outline">
                    <Paperclip className="h-4 w-4 mr-2" />
                    Anexar Fotos ou Documentos
                  </Button>
                  <p className="text-sm text-muted-foreground mt-2">
                    Formatos aceitos: JPG, PNG, PDF — até 10MB cada.
                  </p>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Botões de ação - Sticky Footer */}
        <div className="sticky bottom-0 bg-background border-t border-border p-4 flex justify-end gap-4 mt-6">
          <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>
            Cancelar
          </Button>
          <Button type="button" variant="outline" onClick={handleSaveAsDraft} disabled={loading} className="min-w-[140px]">
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2"></div>
                Salvando...
              </>
            ) : (
              <>
                <FileText className="h-4 w-4 mr-2" />
                Salvar como Rascunho
              </>
            )}
          </Button>
          <Button type="submit" disabled={loading} className="min-w-[140px]">
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Salvando...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                Salvar OS
              </>
            )}
          </Button>
        </div>

        {/* Modal Cliente + Veículo Unificado */}
        <NovoClienteVeiculoModal
          isOpen={showClienteVeiculoModal}
          onClose={() => setShowClienteVeiculoModal(false)}
          onSuccess={handleClienteVeiculoCreated}
        />
      </form>
    </div>
  );
};
