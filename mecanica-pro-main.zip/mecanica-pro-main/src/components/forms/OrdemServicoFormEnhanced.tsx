import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, User, Car, Save } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { NovoClienteVeiculoModal } from '@/components/modals/NovoClienteVeiculoModal';
import { VeiculoForm } from './VeiculoForm';
import { Cliente as ClienteWorkshop } from '@/types/workshop';
import { cn } from '@/lib/utils';

interface Cliente {
  id: string;
  nome: string;
  email?: string;
  telefone?: string;
  endereco?: string;
  empresa_id: string;
  created_at?: string;
}

interface Veiculo {
  id: string;
  cliente_id: string;
  marca?: string;
  modelo?: string;
  ano?: number;
  placa?: string;
  cor?: string;
  quilometragem?: number;
  chassi?: string;
  empresa_id: string;
}

interface OrdemServicoFormData {
  cliente_id: string;
  veiculo_id: string;
  descricao?: string;
  defeito_relatado?: string;
  status?: string;
  data_abertura: string;
  data_entrega?: string;
}

interface OrdemServicoFormEnhancedProps {
  onSubmit: (data: OrdemServicoFormData) => void;
  onCancel: () => void;
}

export const OrdemServicoFormEnhanced: React.FC<OrdemServicoFormEnhancedProps> = ({
  onSubmit,
  onCancel
}) => {
  const { empresa } = useAuth();
  const { toast } = useToast();
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [selectedCliente, setSelectedCliente] = useState<Cliente | null>(null);
  const [selectedVeiculo, setSelectedVeiculo] = useState<Veiculo | null>(null);
  const [clienteVeiculoModalOpen, setClienteVeiculoModalOpen] = useState(false);
  const [veiculoModalOpen, setVeiculoModalOpen] = useState(false);
  const [clienteSearch, setClienteSearch] = useState('');
  const [veiculoSearch, setVeiculoSearch] = useState('');
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors }, setValue, watch } = useForm<OrdemServicoFormData>({
    defaultValues: {
      status: 'aguardando_aprovacao',
      data_abertura: new Date().toISOString().split('T')[0]
    }
  });

  // Load data on component mount
  useEffect(() => {
    loadClientes();
  }, [empresa]);

  // Load vehicles when cliente changes
  useEffect(() => {
    if (selectedCliente) {
      loadVeiculos(selectedCliente.id);
    } else {
      setVeiculos([]);
      setSelectedVeiculo(null);
    }
  }, [selectedCliente]);

  const loadClientes = async () => {
    if (!empresa?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .eq('empresa_id', empresa.id)
        .order('nome');

      if (error) throw error;
      setClientes(data || []);
    } catch (error) {
      console.error('Error loading clients:', error);
      toast({
        title: "Erro ao carregar clientes",
        description: "Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const loadVeiculos = async (clienteId: string) => {
    if (!empresa?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('veiculos')
        .select('*')
        .eq('cliente_id', clienteId)
        .eq('empresa_id', empresa.id)
        .order('modelo');

      if (error) throw error;
      setVeiculos(data || []);
    } catch (error) {
      console.error('Error loading vehicles:', error);
      toast({
        title: "Erro ao carregar veículos",
        description: "Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleClienteVeiculoSuccess = async (clienteId: string, veiculoId: string) => {
    // Recarregar dados
    await loadClientes();
    
    // Buscar o cliente criado no banco
    try {
      const { data: clienteData, error: clienteError } = await supabase
        .from('clientes')
        .select('*')
        .eq('id', clienteId)
        .single();
      
      if (clienteError) throw clienteError;
      
      // Buscar o veículo criado no banco
      const { data: veiculoData, error: veiculoError } = await supabase
        .from('veiculos')
        .select('*')
        .eq('id', veiculoId)
        .single();
      
      if (veiculoError) throw veiculoError;
      
      // Selecionar cliente e veículo
      setSelectedCliente(clienteData);
      setValue('cliente_id', clienteId);
      
      setVeiculos([veiculoData]);
      setSelectedVeiculo(veiculoData);
      setValue('veiculo_id', veiculoId);
      
    } catch (error) {
      console.error('Error loading created data:', error);
    }
    
    setClienteVeiculoModalOpen(false);
    toast({
      title: "Cliente e veículo criados!",
      description: "Cliente e veículo foram cadastrados com sucesso.",
    });
  };

  const handleVeiculoSubmit = async (veiculoData: Omit<Veiculo, 'id' | 'empresa_id'>) => {
    if (!empresa?.id || !selectedCliente) return;
    
    try {
      const newVeiculo = {
        ...veiculoData,
        cliente_id: selectedCliente.id,
        empresa_id: empresa.id,
        marca: veiculoData.marca || '',
        modelo: veiculoData.modelo || '',
        placa: veiculoData.placa || ''
      };

      const { data, error } = await supabase
        .from('veiculos')
        .insert([newVeiculo])
        .select()
        .single();

      if (error) throw error;

      // Update local state
      setVeiculos(prev => [...prev, data]);
      setSelectedVeiculo(data);
      setValue('veiculo_id', data.id);
      
      setVeiculoModalOpen(false);
      toast({
        title: "Veículo cadastrado!",
        description: `${data.marca} ${data.modelo} foi adicionado com sucesso.`,
      });
    } catch (error) {
      console.error('Error creating vehicle:', error);
      toast({
        title: "Erro ao cadastrar veículo",
        description: "Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleFormSubmit = (data: OrdemServicoFormData) => {
    if (!selectedCliente || !selectedVeiculo) {
      toast({
        title: "Campos obrigatórios",
        description: "Selecione um cliente e um veículo.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      onSubmit({
        ...data,
        cliente_id: selectedCliente.id,
        veiculo_id: selectedVeiculo.id,
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredClientes = clientes.filter(cliente =>
    cliente.nome.toLowerCase().includes(clienteSearch.toLowerCase()) ||
    (cliente.email?.includes(clienteSearch)) ||
    (cliente.telefone?.includes(clienteSearch))
  );

  const filteredVeiculos = veiculos.filter(veiculo =>
    (veiculo.modelo?.toLowerCase().includes(veiculoSearch.toLowerCase())) ||
    (veiculo.marca?.toLowerCase().includes(veiculoSearch.toLowerCase())) ||
    (veiculo.placa?.toLowerCase().includes(veiculoSearch.toLowerCase()))
  );

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
      {/* Cliente Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Cliente
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <div className="flex-1">
              <Input
                placeholder="Buscar cliente por nome, email ou telefone..."
                value={clienteSearch}
                onChange={(e) => setClienteSearch(e.target.value)}
                className="w-full"
              />
            </div>
            <Button 
              type="button" 
              variant="default"
              size="sm"
              className="flex items-center gap-2 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-md hover:shadow-lg transition-all duration-200 hover:scale-[1.02] border-0 text-primary-foreground font-medium"
              onClick={() => setClienteVeiculoModalOpen(true)}
            >
              <Plus className="h-4 w-4" />
              <span>Novo Cliente</span>
            </Button>
          </div>

          {selectedCliente && (
            <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">{selectedCliente.nome}</h4>
                  <p className="text-sm text-muted-foreground">
                    {selectedCliente.telefone} • {selectedCliente.email}
                  </p>
                </div>
                <Badge variant="secondary">Selecionado</Badge>
              </div>
            </div>
          )}

          <div className="grid gap-2 max-h-40 overflow-y-auto">
            {filteredClientes.map((cliente) => (
              <div
                key={cliente.id}
                className={cn(
                  "p-3 border rounded-lg cursor-pointer transition-colors hover:bg-muted/50",
                  selectedCliente?.id === cliente.id && "border-primary bg-primary/5"
                )}
                onClick={() => {
                  setSelectedCliente(cliente);
                  setValue('cliente_id', cliente.id);
                  setClienteSearch('');
                }}
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-medium">{cliente.nome}</h4>
                    <p className="text-sm text-muted-foreground">
                      {cliente.telefone} • {cliente.email}
                    </p>
                  </div>
                  {selectedCliente?.id === cliente.id && (
                    <Badge variant="secondary">✓</Badge>
                  )}
                </div>
              </div>
            ))}
          </div>

          {filteredClientes.length === 0 && clienteSearch && (
            <p className="text-center text-muted-foreground py-4">
              Nenhum cliente encontrado.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Veiculo Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Car className="h-5 w-5" />
            Veículo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <div className="flex-1">
              <Input
                placeholder="Buscar veículo por modelo, marca ou placa..."
                value={veiculoSearch}
                onChange={(e) => setVeiculoSearch(e.target.value)}
                disabled={!selectedCliente}
                className="w-full"
              />
            </div>
            <Dialog open={veiculoModalOpen} onOpenChange={setVeiculoModalOpen}>
              <DialogTrigger asChild>
                <Button 
                  type="button" 
                  variant="outline" 
                  disabled={!selectedCliente}
                  className="flex items-center gap-2"
                >
                  <Plus className="h-4 w-4" />
                  Novo Veículo
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Cadastrar Novo Veículo</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <p className="text-muted-foreground">Novo veículo para: <strong>{selectedCliente?.nome}</strong></p>
                  <VeiculoForm
                    clientes={[{...selectedCliente!, created_at: selectedCliente!.created_at || new Date().toISOString()}] as ClienteWorkshop[]}
                    onSubmit={(data) => handleVeiculoSubmit({...data, cliente_id: selectedCliente!.id})}
                    onCancel={() => setVeiculoModalOpen(false)}
                  />
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {!selectedCliente && (
            <p className="text-center text-muted-foreground py-4">
              Selecione um cliente primeiro para escolher um veículo.
            </p>
          )}

          {selectedVeiculo && (
            <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">{selectedVeiculo.marca} {selectedVeiculo.modelo}</h4>
                  <p className="text-sm text-muted-foreground">
                    {selectedVeiculo.placa} • {selectedVeiculo.ano} • {selectedVeiculo.cor}
                  </p>
                </div>
                <Badge variant="secondary">Selecionado</Badge>
              </div>
            </div>
          )}

          {selectedCliente && (
            <div className="grid gap-2 max-h-40 overflow-y-auto">
              {filteredVeiculos.map((veiculo) => (
                <div
                  key={veiculo.id}
                  className={cn(
                    "p-3 border rounded-lg cursor-pointer transition-colors hover:bg-muted/50",
                    selectedVeiculo?.id === veiculo.id && "border-primary bg-primary/5"
                  )}
                  onClick={() => {
                    setSelectedVeiculo(veiculo);
                    setValue('veiculo_id', veiculo.id);
                    setVeiculoSearch('');
                  }}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium">{veiculo.marca} {veiculo.modelo}</h4>
                      <p className="text-sm text-muted-foreground">
                        {veiculo.placa} • {veiculo.ano} • {veiculo.cor}
                      </p>
                    </div>
                    {selectedVeiculo?.id === veiculo.id && (
                      <Badge variant="secondary">✓</Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {selectedCliente && filteredVeiculos.length === 0 && veiculoSearch && (
            <p className="text-center text-muted-foreground py-4">
              Nenhum veículo encontrado.
            </p>
          )}

          {selectedCliente && filteredVeiculos.length === 0 && !veiculoSearch && (
            <p className="text-center text-muted-foreground py-4">
              Este cliente ainda não possui veículos cadastrados.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Service Order Details */}
      <Card>
        <CardHeader>
          <CardTitle>Detalhes da Ordem de Serviço</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="data_abertura">Data de Abertura *</Label>
              <Input
                id="data_abertura"
                type="date"
                {...register('data_abertura', { required: 'Data de abertura é obrigatória' })}
              />
              {errors.data_abertura && (
                <p className="text-sm text-destructive">{errors.data_abertura.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="data_entrega">Data de Entrega Prevista</Label>
              <Input
                id="data_entrega"
                type="date"
                {...register('data_entrega')}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <Select defaultValue="aguardando_aprovacao" onValueChange={(value) => setValue('status', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="aguardando_aprovacao">Aguardando Aprovação</SelectItem>
                <SelectItem value="aprovado">Aprovado</SelectItem>
                <SelectItem value="aguardando_peca">Aguardando Peça</SelectItem>
                <SelectItem value="em_execucao">Em Execução</SelectItem>
                <SelectItem value="pronto_retirada">Pronto para Retirada</SelectItem>
                <SelectItem value="finalizado">Finalizado</SelectItem>
                <SelectItem value="cancelado">Cancelado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="defeito_relatado">Problema/Defeito Relatado</Label>
            <Textarea
              id="defeito_relatado"
              placeholder="Descreva o problema relatado pelo cliente..."
              rows={3}
              {...register('defeito_relatado')}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="descricao">Descrição do Serviço</Label>
            <Textarea
              id="descricao"
              placeholder="Descreva o serviço a ser realizado..."
              rows={4}
              {...register('descricao')}
            />
            {errors.descricao && (
              <p className="text-sm text-destructive">{errors.descricao.message}</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Form Actions */}
      <div className="flex justify-end gap-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={loading}
        >
          Cancelar
        </Button>
        <Button
          type="submit"
          disabled={loading || !selectedCliente || !selectedVeiculo}
          className="flex items-center gap-2"
        >
          <Save className="h-4 w-4" />
          {loading ? 'Salvando...' : 'Criar Ordem de Serviço'}
        </Button>
      </div>

      {/* Modal Cliente + Veículo */}
      <NovoClienteVeiculoModal
        isOpen={clienteVeiculoModalOpen}
        onClose={() => setClienteVeiculoModalOpen(false)}
        onSuccess={handleClienteVeiculoSuccess}
      />
    </form>
  );
};