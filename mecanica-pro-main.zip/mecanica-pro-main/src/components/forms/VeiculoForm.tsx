import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { VeiculoFormData, Cliente } from '@/types/workshop';
import { veiculoFormSchema } from '@/lib/validation';
import { usePlacaMask } from '@/hooks/usePlacaMask';
import { supabase } from '@/integrations/supabase/client';
import { AlertTriangle, Loader, Save } from 'lucide-react';

interface VeiculoFormProps {
  veiculo?: (VeiculoFormData & { id?: string }) | null;
  clientes: Cliente[];
  onSubmit: (data: VeiculoFormData) => void;
  onCancel: () => void;
  onDataChange?: (hasChanges: boolean) => void;
}

// 🔒 evita remontagem desnecessária do componente
export const VeiculoForm = React.memo(function VeiculoFormComponent({
  veiculo,
  clientes,
  onSubmit,
  onCancel,
  onDataChange
}: VeiculoFormProps) {
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [isValidating, setIsValidating] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [autoSaveStatus, setAutoSaveStatus] = useState<'saved' | 'saving' | 'idle'>('idle');
  const autoSaveTimeoutRef = useRef<NodeJS.Timeout>();
  const initialDataRef = useRef<VeiculoFormData | null>(null);

  // 🔑 restaura rascunho ANTES de inicializar o RHF (evita “piscar”)
  const draftKey = veiculo?.id ? `veiculo-edit-${veiculo.id}` : 'veiculo-form-draft';
  let initialValues: VeiculoFormData = veiculo || {
    cliente_id: '',
    marca: '',
    modelo: '',
    ano: new Date().getFullYear(),
    placa: '',
    cor: '',
    quilometragem: 0,
    combustivel: '',
  };
  try {
    const draft = sessionStorage.getItem(draftKey);
    if (draft && !veiculo) {
      const parsed = JSON.parse(draft);
      if (!parsed.timestamp || (Date.now() - parsed.timestamp) < 24 * 60 * 60 * 1000) {
        delete parsed.timestamp;
        initialValues = { ...initialValues, ...parsed };
      } else {
        sessionStorage.removeItem(draftKey);
      }
    }
  } catch (e) {
    // ignora erros de parse sem quebrar a UI
  }

  const { register, handleSubmit, formState: { errors }, setValue, watch, reset } =
    useForm<VeiculoFormData>({
      resolver: zodResolver(veiculoFormSchema),
      shouldUnregister: false, // ✅ mantém estado mesmo quando o input desmonta
      defaultValues: initialValues
    });

  // guarda referência do estado inicial para comparar mudanças
  useEffect(() => {
    initialDataRef.current = initialValues;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // apenas 1x

  // 🕒 autosave com debounce -> sessionStorage (escopo da aba, menos side-effects)
  const debouncedAutoSave = useCallback((formData: VeiculoFormData) => {
    if (autoSaveTimeoutRef.current) clearTimeout(autoSaveTimeoutRef.current);
    setAutoSaveStatus('saving');
    autoSaveTimeoutRef.current = setTimeout(() => {
      if (formData.marca || formData.modelo || formData.placa || formData.cliente_id) {
        sessionStorage.setItem(
          draftKey,
          JSON.stringify({ ...formData, timestamp: Date.now() })
        );
        setAutoSaveStatus('saved');
        setTimeout(() => setAutoSaveStatus('idle'), 1500);
      } else {
        setAutoSaveStatus('idle');
      }
    }, 800);
  }, [draftKey]);

  // detecta mudanças no form e aciona autosave
  useEffect(() => {
    const subscription = watch((value) => {
      const formData = value as VeiculoFormData;
      const initial = initialDataRef.current;
      const changed = !!initial && Object.keys(formData).some((k) => {
        const key = k as keyof VeiculoFormData;
        return formData[key] !== initial[key];
      });
      setHasUnsavedChanges(changed);
      onDataChange?.(changed);
      if (changed) debouncedAutoSave(formData);
    });
    return () => subscription.unsubscribe();
  }, [watch, debouncedAutoSave, onDataChange]);

  // ✋ só reseta o formulário se o ID do veículo mudar (evita refresh visual)
  const lastVeiculoIdRef = useRef<string | undefined>(veiculo?.id);
  useEffect(() => {
    if (veiculo?.id && veiculo.id !== lastVeiculoIdRef.current) {
      reset((current) => ({ ...current, ...veiculo }));
      setHasUnsavedChanges(false);
      lastVeiculoIdRef.current = veiculo.id;
      initialDataRef.current = veiculo;
    }
  }, [veiculo, reset]);

  // cleanup do debounce
  useEffect(() => {
    return () => {
      if (autoSaveTimeoutRef.current) clearTimeout(autoSaveTimeoutRef.current);
    };
  }, []);

  // máscara da placa
  const placaMask = usePlacaMask({
    initialValue: initialValues.placa || '',
    onChange: (formattedValue) => setValue('placa', formattedValue)
  });

  // validações extras (placa única por empresa, formato, etc.)
  const validateFormData = async (data: VeiculoFormData): Promise<string[]> => {
    const errs: string[] = [];

    if (!data.cliente_id) errs.push('Selecione um cliente');
    const clienteExists = clientes.some(c => c.id === data.cliente_id);
    if (!clienteExists) errs.push('Cliente selecionado não existe');

    if (data.placa) {
      const clean = data.placa.replace(/[^A-Z0-9]/g, '').toUpperCase();
      const placaRegex = /^[A-Z]{3}[0-9]{4}$|^[A-Z]{3}[0-9][A-Z][0-9]{2}$/;
      if (!placaRegex.test(clean)) {
        errs.push('Placa inválida (ex: ABC1234 ou ABC1D23)');
      } else {
        const isNew = !veiculo;
        const changed = veiculo && veiculo.placa !== data.placa;
        if (isNew || changed) {
          try {
            const { data: found } = await supabase
              .from('veiculos')
              .select('id, placa')
              .ilike('placa', data.placa);
            if (found && found.length > 0) errs.push('Já existe um veículo com esta placa');
          } catch (e) {
            // loga e segue
            console.error('Erro verificando placa:', e);
          }
        }
      }
    }
    return errs;
  };

  const onFormSubmit = async (data: VeiculoFormData) => {
    setValidationErrors([]);
    setIsValidating(true);
    try {
      const errs = await validateFormData(data);
      if (errs.length > 0) {
        setValidationErrors(errs);
        return;
      }
      const processed: VeiculoFormData = {
        ...data,
        ano: data.ano ? Number(data.ano) : undefined,
        quilometragem: data.quilometragem ? Number(data.quilometragem) : undefined,
      };
      onSubmit(processed);
      sessionStorage.removeItem(draftKey);
      setHasUnsavedChanges(false);
    } catch (e) {
      console.error('Erro no submit:', e);
      setValidationErrors(['Erro inesperado. Tente novamente.']);
    } finally {
      setIsValidating(false);
    }
  };

  const handleCancel = () => {
    if (hasUnsavedChanges) {
      const confirmed = window.confirm('Você tem alterações não salvas. Deseja realmente cancelar?');
      if (!confirmed) return;
    }
    sessionStorage.removeItem(draftKey);
    onCancel();
  };

  return (
    <div className="space-y-4">
      {/* status do autosave */}
      {autoSaveStatus !== 'idle' && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          {autoSaveStatus === 'saving' && (
            <>
              <Loader className="h-3 w-3 animate-spin" />
              <span>Salvando rascunho...</span>
            </>
          )}
          {autoSaveStatus === 'saved' && (
            <>
              <Save className="h-3 w-3" />
              <span>Rascunho salvo automaticamente</span>
            </>
          )}
        </div>
      )}

      {/* erros de validação */}
      {validationErrors.length > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <ul className="list-disc list-inside space-y-1">
              {validationErrors.map((err, i) => <li key={i}>{err}</li>)}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-4">
        <div>
          <Label htmlFor="cliente_id">Cliente *</Label>
          <Select value={watch('cliente_id')} onValueChange={(v) => setValue('cliente_id', v)}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione um cliente" />
            </SelectTrigger>
            <SelectContent>
              {clientes.map((c) => (
                <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.cliente_id && <p className="text-sm text-destructive">{errors.cliente_id.message}</p>}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="marca">Marca *</Label>
            <Input id="marca" {...register('marca', { required: 'Marca é obrigatória' })} placeholder="Ex: Toyota" />
            {errors.marca && <p className="text-sm text-destructive">{errors.marca.message}</p>}
          </div>
          <div>
            <Label htmlFor="modelo">Modelo *</Label>
            <Input id="modelo" {...register('modelo', { required: 'Modelo é obrigatório' })} placeholder="Ex: Corolla" />
            {errors.modelo && <p className="text-sm text-destructive">{errors.modelo.message}</p>}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div>
            <Label htmlFor="ano">Ano</Label>
            <Input id="ano" type="number" {...register('ano')} placeholder="2020" />
          </div>
          <div>
            <Label htmlFor="placa">Placa *</Label>
            <Input id="placa" value={placaMask.value} onChange={placaMask.onChange} placeholder="ABC-1234 / ABC1D23" />
          </div>
          <div>
            <Label htmlFor="cor">Cor</Label>
            <Input id="cor" {...register('cor')} placeholder="Branco, Preto" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="quilometragem">Quilometragem</Label>
            <Input id="quilometragem" type="number" {...register('quilometragem', { min: 0 })} placeholder="0" />
          </div>
          <div>
            <Label htmlFor="combustivel">Combustível</Label>
            <Select value={watch('combustivel')} onValueChange={(v) => setValue('combustivel', v)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o combustível" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Flex">Flex</SelectItem>
                <SelectItem value="Gasolina">Gasolina</SelectItem>
                <SelectItem value="Elétrico">Elétrico</SelectItem>
                <SelectItem value="Híbrido">Híbrido</SelectItem>
                <SelectItem value="Diesel">Diesel</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button type="button" variant="outline" onClick={handleCancel}>Cancelar</Button>
          <Button type="submit" disabled={isValidating}>
            {isValidating ? (
              <>
                <Loader className="h-4 w-4 animate-spin mr-2" />
                Validando...
              </>
            ) : (
              `${veiculo ? 'Atualizar' : 'Cadastrar'} Veículo`
            )}
          </Button>
        </div>
      </form>
    </div>
  );
});
