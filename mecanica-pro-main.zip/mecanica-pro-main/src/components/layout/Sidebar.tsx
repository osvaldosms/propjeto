import React from 'react';
import { NavLink } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { usePlanAccess } from '@/hooks/usePlanAccess';
import { Lock } from 'lucide-react';
import {
  LayoutDashboard,
  Users,
  Car,
  ClipboardList,
  Package,
  Calendar,
  DollarSign,
  BarChart3,
  UserCog,
  MessageCircle,
  Crown,
  Settings,
} from 'lucide-react';

const navigation = [
  {
    name: 'Dashboard',
    href: '/dashboard',
    icon: LayoutDashboard,
    requiredPlan: 'trial',
  },
  {
    name: 'Clientes',
    href: '/customers',
    icon: Users,
    requiredPlan: 'trial',
  },
  {
    name: 'Veículos',
    href: '/vehicles',
    icon: Car,
    requiredPlan: 'trial',
  },
  {
    name: 'Ordens de Serviço',
    href: '/service-orders',
    icon: ClipboardList,
    requiredPlan: 'trial',
  },
  {
    name: 'Agenda',
    href: '/schedule',
    icon: Calendar,
    requiredPlan: 'trial',
  },
  {
    name: 'Estoque',
    href: '/inventory',
    icon: Package,
    requiredPlan: 'profissional',
  },
  {
    name: 'Financeiro',
    href: '/financial',
    icon: DollarSign,
    requiredPlan: 'profissional',
  },
  {
    name: 'Relatórios',
    href: '/reports',
    icon: BarChart3,
    requiredPlan: 'profissional',
  },
  {
    name: 'Equipe',
    href: '/team',
    icon: UserCog,
    requiredPlan: 'essencial',
  },
  {
    name: 'Comunicação',
    href: '/communication',
    icon: MessageCircle,
    requiredPlan: 'premium',
  },
  {
    name: 'Configurações',
    href: '/settings',
    icon: Settings,
    requiredPlan: 'trial',
  },
  {
    name: 'Planos',
    href: '/plans',
    icon: Crown,
    requiredPlan: 'trial',
  },
];

export const Sidebar: React.FC = () => {
  const { checkAccess } = usePlanAccess();

  return (
    <div className="flex h-full w-64 flex-col bg-card border-r">
      <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
        <nav className="mt-5 flex-1 px-2 space-y-1">
          {navigation.map((item) => {
            const hasAccess = checkAccess(item.requiredPlan);
            
            return (
              <NavLink
                key={item.name}
                to={item.href}
                className={({ isActive }) =>
                  cn(
                    'group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors',
                    !hasAccess ? 'opacity-50 cursor-not-allowed' : '',
                    isActive && hasAccess
                      ? 'bg-primary text-primary-foreground'
                      : 'text-foreground hover:bg-muted hover:text-foreground'
                  )
                }
                onClick={(e) => {
                  if (!hasAccess) {
                    e.preventDefault();
                  }
                }}
              >
                <item.icon
                  className="mr-3 flex-shrink-0 h-5 w-5"
                  aria-hidden="true"
                />
                {item.name}
                {!hasAccess && (
                  <Lock className="ml-auto h-4 w-4 text-muted-foreground" />
                )}
              </NavLink>
            );
          })}
        </nav>
      </div>
    </div>
  );
};