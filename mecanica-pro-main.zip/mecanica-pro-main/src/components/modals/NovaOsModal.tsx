import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { OrdemServicoFormCompleta } from '@/components/forms/OrdemServicoFormCompleta';
import { useOrdemServicoCreation } from '@/hooks/useOrdemServicoCreation';

interface NovaOsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NovaOsModal: React.FC<NovaOsModalProps> = ({ isOpen, onClose }) => {
  const { createOrdemServico } = useOrdemServicoCreation();

  const handleSubmit = async (data: any) => {
    try {
      await createOrdemServico(data);
      onClose();
    } catch (error) {
      // Erro já tratado no hook
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nova Ordem de Serviço</DialogTitle>
        </DialogHeader>
        <OrdemServicoFormCompleta onSubmit={handleSubmit} onCancel={onClose} />
      </DialogContent>
    </Dialog>
  );
};