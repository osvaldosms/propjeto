import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { DollarSign, TrendingUp, TrendingDown, Plus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { NovaTransacaoData, CategoriaFinanceira } from '@/types/financial';

interface NovaTransacaoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const NovaTransacaoModal: React.FC<NovaTransacaoModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [categorias, setCategorias] = useState<CategoriaFinanceira[]>([]);
  const [clientes, setClientes] = useState<Array<{ nome: string }>>([]);
  
  const { register, handleSubmit, formState: { errors }, setValue, watch, reset } = useForm<NovaTransacaoData>({
    defaultValues: {
      tipo: 'receita',
      data: new Date().toISOString().split('T')[0]
    }
  });

  const tipoSelecionado = watch('tipo');

  // Buscar categorias do banco
  useEffect(() => {
    const fetchCategorias = async () => {
      const { data } = await supabase
        .from('categorias_financeiras')
        .select('*')
        .order('nome');
      
      if (data) {
        setCategorias(data as CategoriaFinanceira[]);
      }
    };

    // Buscar clientes
    const fetchClientes = async () => {
      const { data } = await supabase
        .from('clientes')
        .select('nome')
        .order('nome');
      
      if (data) {
        setClientes(data);
      }
    };

    if (isOpen) {
      fetchCategorias();
      fetchClientes();
    }
  }, [isOpen]);

  // Categorias padrão como fallback
  const categoriasReceita = [
    'Serviços de Manutenção',
    'Peças e Acessórios',
    'Diagnóstico',
    'Emergência',
    'Outros'
  ];

  const categoriasDespesa = [
    'Compra de Peças',
    'Ferramentas',
    'Energia Elétrica',
    'Aluguel',
    'Salários',
    'Combustível',
    'Marketing',
    'Outros'
  ];

  const metodosPagamento = [
    'Dinheiro',
    'PIX',
    'Cartão de Débito',
    'Cartão de Crédito',
    'Transferência',
    'Boleto'
  ];

  const onSubmit = async (data: NovaTransacaoData) => {
    try {
      setLoading(true);
      
      // Buscar empresa_id do usuário
      const { data: userData } = await supabase
        .from('profiles')
        .select('empresa_id')
        .eq('id', (await supabase.auth.getUser()).data.user?.id)
        .single();

      if (!userData?.empresa_id) {
        throw new Error('Empresa não encontrada');
      }

      // Inserir transação no banco
      const { error } = await supabase
        .from('transacoes_financeiras')
        .insert({
          empresa_id: userData.empresa_id,
          tipo: data.tipo,
          descricao: data.descricao,
          valor: parseFloat(data.valor),
          categoria: data.categoria,
          metodo_pagamento: data.metodo_pagamento,
          data: data.data,
          cliente: data.cliente,
          observacoes: data.observacoes,
          status: 'confirmada'
        });

      if (error) throw error;
      
      const valorFormatado = new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      }).format(parseFloat(data.valor));

      toast({
        title: "Transação criada!",
        description: `${data.tipo === 'receita' ? 'Receita' : 'Despesa'} de ${valorFormatado} registrada com sucesso.`,
      });
      
      reset();
      onSuccess?.();
      onClose();
    } catch (error) {
      console.error('Erro ao criar transação:', error);
      toast({
        title: "Erro ao criar transação",
        description: "Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Nova Transação
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Tipo da Transação */}
          <div className="space-y-2">
            <Label>Tipo da Transação *</Label>
            <div className="flex gap-4">
              <Button
                type="button"
                variant={tipoSelecionado === 'receita' ? 'default' : 'outline'}
                className="flex-1 flex items-center gap-2"
                onClick={() => setValue('tipo', 'receita')}
              >
                <TrendingUp className="h-4 w-4" />
                Receita
              </Button>
              <Button
                type="button"
                variant={tipoSelecionado === 'despesa' ? 'default' : 'outline'}
                className="flex-1 flex items-center gap-2"
                onClick={() => setValue('tipo', 'despesa')}
              >
                <TrendingDown className="h-4 w-4" />
                Despesa
              </Button>
            </div>
          </div>

          {/* Informações Básicas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="descricao">Descrição *</Label>
              <Input
                id="descricao"
                placeholder="Descrição da transação"
                {...register('descricao', { required: 'Descrição é obrigatória' })}
              />
              {errors.descricao && (
                <p className="text-sm text-destructive">{errors.descricao.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="valor">Valor *</Label>
              <Input
                id="valor"
                type="number"
                step="0.01"
                min="0"
                placeholder="0,00"
                {...register('valor', { 
                  required: 'Valor é obrigatório',
                  min: { value: 0.01, message: 'Valor deve ser maior que 0' }
                })}
              />
              {errors.valor && (
                <p className="text-sm text-destructive">{errors.valor.message}</p>
              )}
            </div>
          </div>

          {/* Categoria e Data */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="categoria">Categoria *</Label>
              <Select onValueChange={(value) => setValue('categoria', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a categoria" />
                </SelectTrigger>
                <SelectContent>
                  {categorias
                    .filter(cat => cat.tipo === tipoSelecionado)
                    .map((categoria) => (
                      <SelectItem key={categoria.id} value={categoria.nome}>
                        {categoria.nome}
                      </SelectItem>
                    ))}
                  {categorias.filter(cat => cat.tipo === tipoSelecionado).length === 0 && 
                    (tipoSelecionado === 'receita' ? categoriasReceita : categoriasDespesa).map((categoria) => (
                      <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
              {errors.categoria && (
                <p className="text-sm text-destructive">{errors.categoria.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="data">Data *</Label>
              <Input
                id="data"
                type="date"
                {...register('data', { required: 'Data é obrigatória' })}
              />
              {errors.data && (
                <p className="text-sm text-destructive">{errors.data.message}</p>
              )}
            </div>
          </div>

          {/* Método de Pagamento */}
          <div className="space-y-2">
            <Label htmlFor="metodo_pagamento">Método de Pagamento *</Label>
            <Select onValueChange={(value) => setValue('metodo_pagamento', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o método" />
              </SelectTrigger>
              <SelectContent>
                {metodosPagamento.map((metodo) => (
                  <SelectItem key={metodo} value={metodo.toLowerCase()}>{metodo}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.metodo_pagamento && (
              <p className="text-sm text-destructive">{errors.metodo_pagamento.message}</p>
            )}
          </div>

          {/* Cliente (apenas para receitas) */}
          {tipoSelecionado === 'receita' && (
            <div className="space-y-2">
              <Label htmlFor="cliente">Cliente</Label>
              <div className="flex gap-2">
                <Select onValueChange={(value) => setValue('cliente', value)}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Selecione um cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    {clientes.map((cliente) => (
                      <SelectItem key={cliente.nome} value={cliente.nome}>
                        {cliente.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button type="button" variant="outline" size="icon">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          {/* Observações */}
          <div className="space-y-2">
            <Label htmlFor="observacoes">Observações</Label>
            <Textarea
              id="observacoes"
              placeholder="Observações adicionais..."
              rows={3}
              {...register('observacoes')}
            />
          </div>

          {/* Botões */}
          <div className="flex gap-3 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Criando...' : 'Criar Transação'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};