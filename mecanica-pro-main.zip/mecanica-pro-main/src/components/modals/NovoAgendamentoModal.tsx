import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { usePhoneMask } from '@/hooks/usePhoneMask';
import { Calendar, Clock, User, Car, Settings, Plus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { NovoAgendamentoData, Servico, Tecnico } from '@/types/scheduling';

interface NovoAgendamentoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const NovoAgendamentoModal: React.FC<NovoAgendamentoModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [servicos, setServicos] = useState<Servico[]>([]);
  const [tecnicos, setTecnicos] = useState<Tecnico[]>([]);
  const [clientes, setClientes] = useState<Array<{ id: string; nome: string; telefone?: string }>>([]);
  
  const { register, handleSubmit, formState: { errors }, setValue, reset, watch } = useForm<NovoAgendamentoData>();
  
  const phoneMask = usePhoneMask({
    onChange: (unformattedValue) => {
      setValue('telefone', unformattedValue);
    }
  });

  // Buscar dados do banco
  useEffect(() => {
    const fetchData = async () => {
      // Get user's company ID first
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: userData } = await supabase
        .from('profiles')
        .select('empresa_id')
        .eq('id', user.id)
        .single();

      if (!userData?.empresa_id) return;

      const [servicosData, tecnicosData, clientesData] = await Promise.all([
        supabase.from('servicos').select('*').eq('empresa_id', userData.empresa_id).order('nome'),
        supabase.from('tecnicos').select('*').eq('empresa_id', userData.empresa_id).order('nome'),
        supabase.from('clientes').select('id, nome, telefone').eq('empresa_id', userData.empresa_id).order('nome')
      ]);

      if (servicosData.data) setServicos(servicosData.data.map(s => ({ ...s, ativo: true, created_at: new Date().toISOString() })));
      if (tecnicosData.data) setTecnicos(tecnicosData.data.map(t => ({ ...t, ativo: true, created_at: new Date().toISOString() })));
      if (clientesData.data) setClientes(clientesData.data);
    };

    if (isOpen) {
      fetchData();
    }
  }, [isOpen]);

  const horarios = [
    '08:00', '08:30', '09:00', '09:30', '10:00', '10:30',
    '11:00', '11:30', '13:00', '13:30', '14:00', '14:30',
    '15:00', '15:30', '16:00', '16:30', '17:00', '17:30'
  ];

  const onSubmit = async (data: NovoAgendamentoData) => {
    try {
      setLoading(true);
      
      // Buscar empresa_id do usuário
      const { data: userData } = await supabase
        .from('profiles')
        .select('empresa_id')
        .eq('id', (await supabase.auth.getUser()).data.user?.id)
        .single();

      if (!userData?.empresa_id) {
        throw new Error('Empresa não encontrada');
      }

      // Buscar informações do serviço e técnico selecionados
      const servico = servicos.find(s => s.nome === data.servico);
      const tecnico = tecnicos.find(t => t.nome === data.tecnico);

      // Inserir agendamento no banco
      const { error } = await supabase
        .from('agendamentos')
        .insert({
          empresa_id: userData.empresa_id,
          cliente_nome: data.cliente,
          cliente_telefone: data.telefone,
          veiculo_descricao: data.veiculo,
          servico_id: servico?.id,
          servico_nome: data.servico,
          tecnico_id: tecnico?.id,
          tecnico_nome: data.tecnico,
          data_agendamento: data.data,
          hora_inicio: data.hora,
          duracao_estimada: servico?.duracao_estimada,
          valor_estimado: servico?.preco_base,
          observacoes: data.observacoes,
          status: 'agendado'
        });

      if (error) throw error;
      
      toast({
        title: "Agendamento criado!",
        description: `Agendamento para ${data.cliente} criado com sucesso.`,
      });
      
      reset();
      onSuccess?.();
      onClose();
    } catch (error) {
      console.error('Erro ao criar agendamento:', error);
      toast({
        title: "Erro ao criar agendamento",
        description: "Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Novo Agendamento
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Informações do Cliente */}
          <div className="space-y-4">
            <h3 className="flex items-center gap-2 font-medium">
              <User className="h-4 w-4" />
              Dados do Cliente
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="cliente">Nome do Cliente *</Label>
                <div className="flex gap-2">
                  <Select onValueChange={(value) => {
                    const cliente = clientes.find(c => c.nome === value);
                    setValue('cliente', value);
                    if (cliente?.telefone) {
                      setValue('telefone', cliente.telefone);
                    }
                  }}>
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Selecione um cliente" />
                    </SelectTrigger>
                    <SelectContent>
                      {clientes.map((cliente) => (
                        <SelectItem key={cliente.id} value={cliente.nome}>
                          {cliente.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button type="button" variant="outline" size="icon" title="Novo Cliente">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                {errors.cliente && (
                  <p className="text-sm text-destructive">{errors.cliente.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="telefone">Telefone *</Label>
                <Input
                  id="telefone"
                  placeholder="(11) 99999-9999"
                  value={phoneMask.value}
                  onChange={phoneMask.onChange}
                />
                {errors.telefone && (
                  <p className="text-sm text-destructive">{errors.telefone.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Informações do Veículo */}
          <div className="space-y-4">
            <h3 className="flex items-center gap-2 font-medium">
              <Car className="h-4 w-4" />
              Veículo
            </h3>
            <div className="space-y-2">
              <Label htmlFor="veiculo">Veículo *</Label>
              <Input
                id="veiculo"
                placeholder="Ex: Honda Civic 2020 - ABC-1234"
                {...register('veiculo', { required: 'Veículo é obrigatório' })}
              />
              {errors.veiculo && (
                <p className="text-sm text-destructive">{errors.veiculo.message}</p>
              )}
            </div>
          </div>

          {/* Serviço e Agendamento */}
          <div className="space-y-4">
            <h3 className="flex items-center gap-2 font-medium">
              <Settings className="h-4 w-4" />
              Serviço e Horário
            </h3>
            
            <div className="space-y-2">
              <Label htmlFor="servico">Serviço *</Label>
              <div className="flex gap-2">
                <Select onValueChange={(value) => setValue('servico', value)}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Selecione o serviço" />
                  </SelectTrigger>
                  <SelectContent>
                    {servicos.map((servico) => (
                      <SelectItem key={servico.id} value={servico.nome}>
                        {servico.nome} {servico.preco_base && `- R$ ${servico.preco_base.toFixed(2)}`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button type="button" variant="outline" size="icon" title="Novo Serviço">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              {errors.servico && (
                <p className="text-sm text-destructive">{errors.servico.message}</p>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="data">Data *</Label>
                <Input
                  id="data"
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                  {...register('data', { required: 'Data é obrigatória' })}
                />
                {errors.data && (
                  <p className="text-sm text-destructive">{errors.data.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="hora">Horário *</Label>
                <Select onValueChange={(value) => setValue('hora', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Horário" />
                  </SelectTrigger>
                  <SelectContent>
                    {horarios.map((hora) => (
                      <SelectItem key={hora} value={hora}>{hora}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.hora && (
                  <p className="text-sm text-destructive">{errors.hora.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="tecnico">Técnico *</Label>
                <Select onValueChange={(value) => setValue('tecnico', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Técnico" />
                  </SelectTrigger>
                  <SelectContent>
                    {tecnicos.map((tecnico) => (
                      <SelectItem key={tecnico.id} value={tecnico.nome}>
                        {tecnico.nome} {tecnico.especialidades && `(${tecnico.especialidades.slice(0, 2).join(', ')})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.tecnico && (
                  <p className="text-sm text-destructive">{errors.tecnico.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Observações */}
          <div className="space-y-2">
            <Label htmlFor="observacoes">Observações</Label>
            <Textarea
              id="observacoes"
              placeholder="Observações adicionais sobre o agendamento..."
              rows={3}
              {...register('observacoes')}
            />
          </div>

          {/* Botões */}
          <div className="flex gap-3 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Criando...' : 'Criar Agendamento'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};