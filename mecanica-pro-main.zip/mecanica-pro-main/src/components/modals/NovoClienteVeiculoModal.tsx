import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ClienteVeiculoUnificado } from '@/components/forms/ClienteVeiculoUnificado';

interface NovoClienteVeiculoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (clienteId: string, veiculoId: string) => void;
}

export const NovoClienteVeiculoModal: React.FC<NovoClienteVeiculoModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  const handleSuccess = (clienteId: string, veiculoId: string) => {
    onSuccess?.(clienteId, veiculoId);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Cadastrar Cliente e Veículo</DialogTitle>
        </DialogHeader>
        <ClienteVeiculoUnificado 
          onSuccess={handleSuccess}
          onCancel={onClose}
        />
      </DialogContent>
    </Dialog>
  );
};