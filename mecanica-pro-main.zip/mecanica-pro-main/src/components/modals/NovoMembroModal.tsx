import React from 'react';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { usePhoneMask } from '@/hooks/usePhoneMask';
import { User, Mail, Phone, MapPin, Star, X } from 'lucide-react';

interface NovoMembroData {
  nome: string;
  email: string;
  telefone: string;
  cargo: string;
  endereco?: string;
  salario?: string;
  especialidades: string[];
  observacoes?: string;
}

interface NovoMembroModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NovoMembroModal: React.FC<NovoMembroModalProps> = ({ isOpen, onClose }) => {
  const { toast } = useToast();
  const { register, handleSubmit, formState: { errors }, setValue, watch, reset } = useForm<NovoMembroData>({
    defaultValues: {
      especialidades: []
    }
  });

  const phoneMask = usePhoneMask({
    onChange: (unformattedValue) => {
      setValue('telefone', unformattedValue);
    }
  });

  const [especialidadeInput, setEspecialidadeInput] = React.useState('');
  const especialidades = watch('especialidades') || [];

  const cargos = [
    'Mecânico Sênior',
    'Mecânico',
    'Eletricista Automotivo',
    'Funileiro',
    'Pintor',
    'Atendente',
    'Gerente',
    'Supervisor'
  ];

  const especialidadesDisponiveis = [
    'Motor',
    'Transmissão',
    'Freios',
    'Suspensão',
    'Elétrica',
    'Eletrônica',
    'Ar Condicionado',
    'Injeção Eletrônica',
    'Diesel',
    'Pintura',
    'Funilaria',
    'Atendimento',
    'Vendas'
  ];

  const adicionarEspecialidade = (especialidade: string) => {
    if (especialidade && !especialidades.includes(especialidade)) {
      const novasEspecialidades = [...especialidades, especialidade];
      setValue('especialidades', novasEspecialidades);
      setEspecialidadeInput('');
    }
  };

  const removerEspecialidade = (especialidade: string) => {
    const novasEspecialidades = especialidades.filter(e => e !== especialidade);
    setValue('especialidades', novasEspecialidades);
  };

  const onSubmit = async (data: NovoMembroData) => {
    try {
      // Simular criação do membro
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Membro adicionado!",
        description: `${data.nome} foi adicionado à equipe com sucesso.`,
      });
      
      reset();
      onClose();
    } catch (error) {
      toast({
        title: "Erro ao adicionar membro",
        description: "Tente novamente.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Adicionar Novo Membro
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Informações Pessoais */}
          <div className="space-y-4">
            <h3 className="flex items-center gap-2 font-medium">
              <User className="h-4 w-4" />
              Informações Pessoais
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nome">Nome Completo *</Label>
                <Input
                  id="nome"
                  placeholder="Nome completo"
                  {...register('nome', { required: 'Nome é obrigatório' })}
                />
                {errors.nome && (
                  <p className="text-sm text-destructive">{errors.nome.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="cargo">Cargo *</Label>
                <Select onValueChange={(value) => setValue('cargo', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o cargo" />
                  </SelectTrigger>
                  <SelectContent>
                    {cargos.map((cargo) => (
                      <SelectItem key={cargo} value={cargo}>{cargo}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.cargo && (
                  <p className="text-sm text-destructive">{errors.cargo.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Contato */}
          <div className="space-y-4">
            <h3 className="flex items-center gap-2 font-medium">
              <Phone className="h-4 w-4" />
              Contato
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">E-mail *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="email@exemplo.com"
                  {...register('email', { 
                    required: 'E-mail é obrigatório',
                    pattern: {
                      value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                      message: 'E-mail inválido'
                    }
                  })}
                />
                {errors.email && (
                  <p className="text-sm text-destructive">{errors.email.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="telefone">Telefone *</Label>
                <Input
                  id="telefone"
                  placeholder="(11) 99999-9999"
                  value={phoneMask.value}
                  onChange={phoneMask.onChange}
                />
                {errors.telefone && (
                  <p className="text-sm text-destructive">{errors.telefone.message}</p>
                )}
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="endereco">Endereço</Label>
              <Input
                id="endereco"
                placeholder="Endereço completo (opcional)"
                {...register('endereco')}
              />
            </div>
          </div>

          {/* Especialidades */}
          <div className="space-y-4">
            <h3 className="flex items-center gap-2 font-medium">
              <Star className="h-4 w-4" />
              Especialidades
            </h3>
            
            <div className="space-y-2">
              <Label>Adicionar Especialidades</Label>
              <div className="flex gap-2">
                <Select value={especialidadeInput} onValueChange={setEspecialidadeInput}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Selecione uma especialidade" />
                  </SelectTrigger>
                  <SelectContent>
                    {especialidadesDisponiveis
                      .filter(esp => !especialidades.includes(esp))
                      .map((especialidade) => (
                        <SelectItem key={especialidade} value={especialidade}>
                          {especialidade}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                <Button 
                  type="button" 
                  onClick={() => adicionarEspecialidade(especialidadeInput)}
                  disabled={!especialidadeInput || especialidades.includes(especialidadeInput)}
                >
                  Adicionar
                </Button>
              </div>
            </div>
            
            {especialidades.length > 0 && (
              <div className="space-y-2">
                <Label>Especialidades Selecionadas:</Label>
                <div className="flex flex-wrap gap-2">
                  {especialidades.map((especialidade) => (
                    <Badge key={especialidade} variant="secondary" className="flex items-center gap-1">
                      {especialidade}
                      <X 
                        className="h-3 w-3 cursor-pointer" 
                        onClick={() => removerEspecialidade(especialidade)}
                      />
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Informações Adicionais */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="salario">Salário (opcional)</Label>
              <Input
                id="salario"
                type="number"
                step="0.01"
                min="0"
                placeholder="0,00"
                {...register('salario')}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="observacoes">Observações</Label>
              <Textarea
                id="observacoes"
                placeholder="Observações adicionais sobre o membro..."
                rows={3}
                {...register('observacoes')}
              />
            </div>
          </div>

          {/* Botões */}
          <div className="flex gap-3 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit">
              Adicionar Membro
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};