import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Building, Mail, Phone, Upload, Trash2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { usePhoneMask } from '@/hooks/usePhoneMask';
import { useCpfMask } from '@/hooks/useCpfMask';

interface CompanyFormData {
  nome_oficina: string;
  cnpj_cpf: string;
  endereco_completo: string;
  telefone: string;
  email: string;
  whatsapp: string;
  instagram: string;
  facebook: string;
  responsavel_tecnico: string;
  logo: string;
}

export const CompanySettings: React.FC = () => {
  const { toast } = useToast();
  const { empresa, user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [logoUrl, setLogoUrl] = useState<string>('');
  const [formData, setFormData] = useState<CompanyFormData>({
    nome_oficina: '',
    cnpj_cpf: '',
    endereco_completo: '',
    telefone: '',
    email: '',
    whatsapp: '',
    instagram: '',
    facebook: '',
    responsavel_tecnico: '',
    logo: '',
  });

  const { register, handleSubmit, reset, formState: { errors }, setValue } = useForm<CompanyFormData>({
    defaultValues: formData
  });

  // Máscaras para campos
  const phoneMask = usePhoneMask({
    initialValue: formData.telefone,
    onChange: (unformattedValue) => setValue('telefone', unformattedValue)
  });

  const whatsappMask = usePhoneMask({
    initialValue: formData.whatsapp,
    onChange: (unformattedValue) => setValue('whatsapp', unformattedValue)
  });

  const cpfMask = useCpfMask({
    initialValue: formData.cnpj_cpf,
    onChange: (unformattedValue) => setValue('cnpj_cpf', unformattedValue)
  });

  useEffect(() => {
    const fetchData = async () => {
      if (!empresa?.id) return;

      try {
        // Buscar dados completos da empresa
        const { data: empresaData, error } = await supabase
          .from('empresas')
          .select('*')
          .eq('id', empresa.id)
          .single() as { data: any, error: any };

        if (error) throw error;

        const formValues = {
          nome_oficina: empresaData.nome || '',
          cnpj_cpf: empresaData.cnpj || '',
          endereco_completo: empresaData.endereco_completo || '',
          telefone: empresaData.telefone || '',
          email: empresaData.email || '',
          whatsapp: empresaData.whatsapp || '',
          instagram: empresaData.instagram || '',
          facebook: empresaData.facebook || '',
          responsavel_tecnico: empresaData.responsavel_tecnico || '',
          logo: empresaData.logo || '',
        };

        setFormData(formValues);
        setLogoUrl(empresaData.logo || '');
        reset(formValues);
        
        // Atualizar máscaras
        phoneMask.setValue(formValues.telefone);
        whatsappMask.setValue(formValues.whatsapp);
        cpfMask.setValue(formValues.cnpj_cpf);
      } catch (error) {
        console.error('Erro ao carregar dados da empresa:', error);
        toast({
          title: "Erro ao carregar dados",
          description: "Não foi possível carregar os dados da empresa.",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    setLoading(true);
    fetchData();
  }, [empresa, reset, toast]);

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user?.id) return;

    setUploadingLogo(true);
    try {
      // Validar tipo de arquivo
      if (!file.type.startsWith('image/')) {
        throw new Error('Por favor, selecione apenas arquivos de imagem');
      }

      // Validar tamanho (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        throw new Error('A imagem deve ter no máximo 5MB');
      }

      // Upload para Storage
      const fileName = `${user.id}/logo-${Date.now()}.${file.name.split('.').pop()}`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('company-logos')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Obter URL pública
      const { data: urlData } = supabase.storage
        .from('company-logos')
        .getPublicUrl(fileName);

      const logoUrl = urlData.publicUrl;

      // Atualizar empresa no banco
      const { error: updateError } = await supabase
        .from('empresas')
        .update({ logo: logoUrl })
        .eq('id', empresa?.id);

      if (updateError) throw updateError;

      setLogoUrl(logoUrl);
      setValue('logo', logoUrl);

      toast({
        title: "Logo atualizada!",
        description: "A logo da empresa foi atualizada com sucesso.",
      });
    } catch (error: any) {
      console.error('Error uploading logo:', error);
      toast({
        title: "Erro ao fazer upload",
        description: error.message || "Não foi possível fazer o upload da logo.",
        variant: "destructive",
      });
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleRemoveLogo = async () => {
    if (!empresa?.id) return;

    try {
      const { error } = await supabase
        .from('empresas')
        .update({ logo: null })
        .eq('id', empresa.id);

      if (error) throw error;

      setLogoUrl('');
      setValue('logo', '');

      toast({
        title: "Logo removida",
        description: "A logo da empresa foi removida com sucesso.",
      });
    } catch (error) {
      console.error('Error removing logo:', error);
      toast({
        title: "Erro ao remover logo",
        description: "Não foi possível remover a logo.",
        variant: "destructive",
      });
    }
  };

  const onSubmit = async (data: CompanyFormData) => {
    try {
      setLoading(true);

      if (!empresa?.id) {
        throw new Error('Empresa não encontrada');
      }

      // Update company basic info
      const { error: empresaError } = await supabase
        .from('empresas')
        .update({
          nome: data.nome_oficina,
          cnpj: data.cnpj_cpf,
          endereco_completo: data.endereco_completo,
          telefone: data.telefone,
          email: data.email,
          whatsapp: data.whatsapp,
          instagram: data.instagram,
          facebook: data.facebook,
          responsavel_tecnico: data.responsavel_tecnico,
        })
        .eq('id', empresa.id);

      if (empresaError) throw empresaError;

      toast({
        title: "Configurações salvas",
        description: "As configurações da empresa foram atualizadas com sucesso.",
      });

    } catch (error) {
      console.error('Erro ao salvar configurações:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar as configurações.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            Configurações da Empresa
          </CardTitle>
          <CardDescription>
            Gerencie as informações básicas da sua oficina
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {/* Logo da Empresa */}
            <div className="space-y-4">
              <Label htmlFor="logo">Logo da Empresa</Label>
              <div className="flex items-center gap-4">
                {logoUrl ? (
                  <div className="relative">
                    <img
                      src={logoUrl}
                      alt="Logo da empresa"
                      className="w-24 h-24 object-contain border rounded-lg"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute -top-2 -right-2"
                      onClick={handleRemoveLogo}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="w-24 h-24 border-2 border-dashed border-muted-foreground/25 rounded-lg flex items-center justify-center">
                    <Upload className="h-8 w-8 text-muted-foreground" />
                  </div>
                )}
                <div>
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    disabled={uploadingLogo}
                    className="mb-2"
                  />
                  <p className="text-sm text-muted-foreground">
                    Formatos aceitos: JPG, PNG, GIF. Tamanho máximo: 5MB
                  </p>
                  {uploadingLogo && (
                    <p className="text-sm text-primary">Enviando...</p>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nome_oficina">Nome da Oficina *</Label>
                <Input
                  id="nome_oficina"
                  {...register('nome_oficina', { required: 'Nome da oficina é obrigatório' })}
                  placeholder="Nome da sua oficina"
                />
                {errors.nome_oficina && (
                  <p className="text-sm text-destructive">{errors.nome_oficina.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="cnpj_cpf">CNPJ/CPF</Label>
                <Input
                  id="cnpj_cpf"
                  value={cpfMask.value}
                  onChange={cpfMask.onChange}
                  placeholder="00.000.000/0000-00 ou 000.000.000-00"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="endereco_completo">Endereço Completo</Label>
              <Textarea
                id="endereco_completo"
                {...register('endereco_completo')}
                placeholder="Rua, número, bairro, cidade, CEP"
                rows={2}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="telefone" className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  Telefone
                </Label>
                <Input
                  id="telefone"
                  value={phoneMask.value}
                  onChange={phoneMask.onChange}
                  placeholder="(11) 99999-9999"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  E-mail
                </Label>
                <Input
                  id="email"
                  type="email"
                  {...register('email')}
                  placeholder="contato@oficina.com"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="whatsapp">WhatsApp</Label>
                <Input
                  id="whatsapp"
                  value={whatsappMask.value}
                  onChange={whatsappMask.onChange}
                  placeholder="(11) 99999-9999"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="instagram">Instagram</Label>
                <Input
                  id="instagram"
                  {...register('instagram')}
                  placeholder="@oficina"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="facebook">Facebook</Label>
                <Input
                  id="facebook"
                  {...register('facebook')}
                  placeholder="Oficina"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="responsavel_tecnico">Responsável Técnico</Label>
              <Input
                id="responsavel_tecnico"
                {...register('responsavel_tecnico')}
                placeholder="Nome do responsável técnico"
              />
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={loading}>
                {loading ? 'Salvando...' : 'Salvar Configurações'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};