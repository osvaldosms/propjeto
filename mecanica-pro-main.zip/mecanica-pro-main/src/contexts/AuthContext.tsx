import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { cleanupAuthState, handleAuthError, debugAuthState } from '@/utils/authUtils';

interface UserProfile {
  id: string;
  nome: string;
  empresa_id: string;
  perfil: string;
  created_at: string;
  updated_at: string;
}

interface Empresa {
  id: string;
  nome: string;
  cnpj?: string;
  created_at: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: UserProfile | null;
  empresa: Empresa | null;
  workshop: Empresa | null; // Compatibility alias
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (email: string, password: string, workshopData: any) => Promise<{ success: boolean; error?: string }>;
  signInWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [empresa, setEmpresa] = useState<Empresa | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load user profile and empresa data - simplified without retries
  const loadUserData = async (userId: string) => {
    try {
      // Get user profile
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (profileError) {
        console.error('Profile load error:', profileError);
        return;
      }

      // Se não encontrar profile, tentar criar um
      if (!profileData) {
        console.warn('No profile found for user:', userId, '- attempting to create one');
        try {
          // Buscar dados do usuário no auth.users
          const { data: { user }, error: userError } = await supabase.auth.getUser();
          if (userError || !user) throw new Error('Cannot get user data');
          
          // Criar empresa padrão se necessário
          const { data: newEmpresa, error: empresaError } = await supabase
            .from('empresas')
            .insert({
              nome: user.user_metadata?.workshop_name || user.user_metadata?.full_name || 'Minha Oficina',
              cnpj: user.user_metadata?.cnpj || '',
              email: user.email || '',
              telefone: user.user_metadata?.phone || '',
              endereco: user.user_metadata?.address || ''
            })
            .select()
            .single();
          
          if (empresaError) throw empresaError;
          
          // Criar profile
          const { data: newProfile, error: newProfileError } = await supabase
            .from('profiles')
            .insert({
              id: userId,
              nome: user.user_metadata?.full_name || user.email || 'Usuário',
              email: user.email,
              empresa_id: newEmpresa.id,
              perfil: 'admin'
            })
            .select()
            .single();
          
          if (newProfileError) throw newProfileError;
          
          setProfile(newProfile);
          setEmpresa(newEmpresa);
          
          console.log('✅ Profile and empresa created successfully');
          return;
        } catch (createError) {
          console.error('Failed to create profile:', createError);
          toast.error('Erro ao criar perfil. Tente fazer logout e login novamente.');
          return;
        }
      }

      setProfile(profileData);

      // Get empresa data if profile exists
      if (profileData?.empresa_id) {
        const { data: empresaData, error: empresaError } = await supabase
          .from('empresas')
          .select('*')
          .eq('id', profileData.empresa_id)
          .maybeSingle();

        if (empresaError) {
          console.error('Empresa load error:', empresaError);
          return;
        }

        if (empresaData) {
          setEmpresa(empresaData);
        }
      }
    } catch (error) {
      console.error('Error in loadUserData:', error);
    }
  };

  useEffect(() => {
    console.log('🔧 AuthProvider initializing...');
    
    // Set up auth state listener - SIMPLIFIED WITHOUT AUTO REDIRECTS
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('🔐 Auth state changed:', event, session?.user?.id);
        setSession(session);
        setUser(session?.user ?? null);
        
        if (event === 'SIGNED_IN' && session?.user) {
          loadUserData(session.user.id);
        } else if (event === 'SIGNED_OUT') {
          setProfile(null);
          setEmpresa(null);
        }
        
        setIsLoading(false);
      }
    );

    // Get initial session - SIMPLIFIED WITHOUT AUTO REDIRECTS
    console.log('🔍 Checking for existing session...');
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('📋 Initial session result:', session ? 'Found' : 'None');
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        console.log('👤 Loading user data for:', session.user.email);
        loadUserData(session.user.id);
      }
      setIsLoading(false);
      console.log('✅ AuthProvider initialization complete');
    }).catch((error) => {
      console.error('❌ Error getting initial session:', error);
      setIsLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      console.log('🔐 Starting login process for:', email.replace(/(.{2}).*(@.*)/, '$1***$2'));
      
      // Clean up existing state
      cleanupAuthState();
      
      // Force sign out
      try {
        await supabase.auth.signOut({ scope: 'global' });
      } catch (err) {
        console.log('Force signout completed');
      }

      // Small delay to ensure cleanup
      await new Promise(resolve => setTimeout(resolve, 200));

      console.log('🔑 Attempting authentication...');
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password,
      });

      if (error) {
        console.warn('🚨 Authentication failure:', error.message);
        const userMessage = handleAuthError(error);
        return { success: false, error: userMessage };
      }

      if (data.user) {
        console.log('✅ Successful authentication:', {
          userId: data.user.id,
          email: email.replace(/(.{2}).*(@.*)/, '$1***$2'),
          emailConfirmed: data.user.email_confirmed_at ? 'yes' : 'no',
        });
        
        return { success: true };
      }

      return { success: false, error: 'Falha na autenticação. Tente novamente.' };
    } catch (error) {
      console.error('Login system error:', error);
      return { success: false, error: handleAuthError(error) };
    }
  };

  const register = async (
    email: string,
    password: string,
    workshopData: any
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      console.log('📝 Starting registration process for:', email.replace(/(.{2}).*(@.*)/, '$1***$2'));
      
      cleanupAuthState();

      const { data, error } = await supabase.auth.signUp({
        email: email.trim().toLowerCase(),
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/dashboard`,
          data: {
            full_name: workshopData.workshopName,
            workshop_name: workshopData.workshopName,
            cnpj: workshopData.cnpj || '',
            phone: workshopData.phone || '',
            address: workshopData.address || ''
          }
        }
      });

      if (error) {
        console.warn('Registration error:', error.message);
        return { success: false, error: handleAuthError(error) };
      }

      if (data.user) {
        console.log('✅ Registration successful:', {
          userId: data.user.id,
          email: email.replace(/(.{2}).*(@.*)/, '$1***$2'),
          emailConfirmed: data.user.email_confirmed_at ? 'yes' : 'no'
        });
        
        toast.success('Conta criada com sucesso!');
        return { success: true };
      }

      return { success: false, error: 'Falha no cadastro' };
    } catch (error) {
      console.error('Register error:', error);
      return { success: false, error: handleAuthError(error) };
    }
  };

  const signInWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      cleanupAuthState();

      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/dashboard`
        }
      });

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      console.error('Google sign in error:', error);
      return { success: false, error: 'Erro ao entrar com Google' };
    }
  };

  const resetPassword = async (email: string): Promise<{ success: boolean; error?: string }> => {
    try {
      console.log('🔄 Initiating password reset for:', email.replace(/(.{2}).*(@.*)/, '$1***$2'));
      
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/nova-senha`,
      });

      if (error) {
        console.warn('Password reset error:', error.message);
        return { success: false, error: error.message };
      }

      console.log('✅ Password reset email sent');
      return { success: true };
    } catch (error) {
      console.error('Password reset system error:', error);
      return { success: false, error: 'Erro ao enviar email de recuperação' };
    }
  };

  const logout = async () => {
    try {
      console.log('🚪 Starting logout process...');
      cleanupAuthState();
      
      try {
        await supabase.auth.signOut({ scope: 'global' });
      } catch (err) {
        console.log('Logout completed');
      }
      
      // Use window.location for clean redirect
      console.log('🔄 Redirecting to auth page...');
      window.location.href = '/auth';
    } catch (error) {
      console.error('Logout error:', error);
      // Force redirect even if logout fails
      window.location.href = '/auth';
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      session,
      profile,
      empresa,
      workshop: empresa, // Compatibility alias
      isAuthenticated: !!user,
      isLoading,
      login,
      register,
      signInWithGoogle,
      resetPassword,
      logout,
    }}>
      {children}
    </AuthContext.Provider>
  );
};