import { useState, useCallback } from 'react';
import { formatCnpj, unformatCnpj } from '@/lib/validation';

interface UseCnpjMaskOptions {
  initialValue?: string;
  onChange?: (unformattedValue: string) => void;
}

export const useCnpjMask = ({ initialValue = '', onChange }: UseCnpjMaskOptions = {}) => {
  const [displayValue, setDisplayValue] = useState(() => formatCnpj(initialValue));

  const handleChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = event.target.value;
    const unformatted = unformatCnpj(inputValue);
    
    // Limit to 14 digits
    if (unformatted.length <= 14) {
      const formatted = formatCnpj(unformatted);
      setDisplayValue(formatted);
      onChange?.(unformatted);
    }
  }, [onChange]);

  const setValue = useCallback((value: string) => {
    const unformatted = unformatCnpj(value);
    const formatted = formatCnpj(unformatted);
    setDisplayValue(formatted);
  }, []);

  return {
    value: displayValue,
    onChange: handleChange,
    setValue,
    unformattedValue: unformatCnpj(displayValue)
  };
};