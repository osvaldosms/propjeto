import { useState, useCallback } from 'react';
import { formatCnpj, unformatCnpj } from '@/lib/validation';

interface UseCpfMaskOptions {
  initialValue?: string;
  onChange?: (unformattedValue: string) => void;
}

export const useCpfMask = ({ initialValue = '', onChange }: UseCpfMaskOptions = {}) => {
  // Para CPF, usamos o formatCnpj que já existe na validation
  const [displayValue, setDisplayValue] = useState(() => {
    if (initialValue.length === 11) {
      return formatCpf(initialValue);
    }
    return formatCnpj(initialValue);
  });

  const handleChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = event.target.value;
    const unformatted = unformatCnpj(inputValue);
    
    // Limit to 14 digits for CNPJ or 11 for CPF
    if (unformatted.length <= 14) {
      let formatted = '';
      
      if (unformatted.length <= 11) {
        // CPF format
        formatted = formatCpf(unformatted);
      } else {
        // CNPJ format
        formatted = formatCnpj(unformatted);
      }
      
      setDisplayValue(formatted);
      onChange?.(unformatted);
    }
  }, [onChange]);

  const setValue = useCallback((value: string) => {
    const unformatted = unformatCnpj(value);
    const formatted = unformatted.length <= 11 ? formatCpf(unformatted) : formatCnpj(unformatted);
    setDisplayValue(formatted);
  }, []);

  return {
    value: displayValue,
    onChange: handleChange,
    setValue,
    unformattedValue: unformatCnpj(displayValue)
  };
};

// Função para formatar CPF
const formatCpf = (cpf: string): string => {
  if (!cpf) return '';
  
  // Remove all non-digits
  const digits = cpf.replace(/\D/g, '');
  
  // Format: XXX.XXX.XXX-XX
  if (digits.length === 11) {
    return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9)}`;
  } else if (digits.length > 0) {
    // Partial formatting
    if (digits.length <= 3) {
      return digits;
    } else if (digits.length <= 6) {
      return `${digits.slice(0, 3)}.${digits.slice(3)}`;
    } else if (digits.length <= 9) {
      return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
    } else {
      return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9)}`;
    }
  }
  
  return cpf;
};