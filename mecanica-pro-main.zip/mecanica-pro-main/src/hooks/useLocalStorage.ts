import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';

// Phase 3: Secure client-side data storage with encryption
export function useLocalStorage<T>(key: string, initialValue: T) {
  const { workshop } = useAuth();
  
  // Criar chave específica da oficina para isolamento multi-tenant
  const workshopKey = workshop ? `${workshop.id}_${key}` : key;
  
  // Simple encryption for sensitive data (for demonstration - use proper encryption in production)
  const encryptData = (data: string): string => {
    try {
      // Base64 encoding with simple obfuscation (replace with proper encryption)
      return btoa(encodeURIComponent(data));
    } catch {
      return data;
    }
  };
  
  const decryptData = (data: string): string => {
    try {
      // Reverse the simple obfuscation
      return decodeURIComponent(atob(data));
    } catch {
      return data;
    }
  };
  
  // Check if key contains sensitive data
  const isSensitiveKey = (keyName: string): boolean => {
    const sensitivePatterns = ['password', 'token', 'auth', 'secret', 'api'];
    return sensitivePatterns.some(pattern => keyName.toLowerCase().includes(pattern));
  };
  
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(workshopKey);
      if (!item) return initialValue;
      
      // Decrypt sensitive data
      const parsedData = isSensitiveKey(key) ? decryptData(item) : item;
      return JSON.parse(parsedData);
    } catch (error) {
      console.error(`Error reading localStorage key "${workshopKey}":`, error);
      return initialValue;
    }
  });

  const setValue = (value: T | ((val: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      
      const jsonData = JSON.stringify(valueToStore);
      // Encrypt sensitive data
      const dataToStore = isSensitiveKey(key) ? encryptData(jsonData) : jsonData;
      
      window.localStorage.setItem(workshopKey, dataToStore);
      
      // Data retention policy - clear after 30 days
      const expiryKey = `${workshopKey}_expiry`;
      const expiryTime = Date.now() + (30 * 24 * 60 * 60 * 1000); // 30 days
      window.localStorage.setItem(expiryKey, expiryTime.toString());
    } catch (error) {
      console.error(`Error setting localStorage key "${workshopKey}":`, error);
    }
  };

  // Data integrity and expiry check
  const checkDataIntegrity = (key: string) => {
    const expiryKey = `${key}_expiry`;
    const expiryTime = window.localStorage.getItem(expiryKey);
    
    if (expiryTime && Date.now() > parseInt(expiryTime)) {
      // Data expired, remove it
      window.localStorage.removeItem(key);
      window.localStorage.removeItem(expiryKey);
      return false;
    }
    
    return true;
  };

  // Prevent infinite loops by tracking initialization
  const isInitialized = useRef(false);
  const initialValueRef = useRef(initialValue);

  // Atualizar quando workshop mudar
  useEffect(() => {
    if (workshop && (!isInitialized.current || workshopKey !== `${workshop.id}_${key}`)) {
      const newWorkshopKey = `${workshop.id}_${key}`;
      
      // Check data integrity and expiry
      if (!checkDataIntegrity(newWorkshopKey)) {
        setStoredValue(initialValueRef.current);
        isInitialized.current = true;
        return;
      }
      
      try {
        const item = window.localStorage.getItem(newWorkshopKey);
        if (!item) {
          setStoredValue(initialValueRef.current);
          isInitialized.current = true;
          return;
        }
        
        const parsedData = isSensitiveKey(key) ? decryptData(item) : item;
        setStoredValue(JSON.parse(parsedData));
        isInitialized.current = true;
      } catch (error) {
        console.error(`Error reading localStorage key "${newWorkshopKey}":`, error);
        setStoredValue(initialValueRef.current);
        isInitialized.current = true;
      }
    }
  }, [workshop?.id, key]);

  return [storedValue, setValue] as const;
}