import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface OrdemServicoData {
  cliente_id: string;
  veiculo_id: string;
  tecnico_id?: string;
  status?: string;
  defeitos_reclamacoes: string;
  descricao?: string;
  data_entrega?: string;
  garantia?: string;
  clausulas_contratuais?: string;
  relatorio_tecnico?: string;
  condicoes_pagamento?: string;
  informacoes_adicionais?: string;
  notificacao_automatica?: boolean;
  compromisso_retorno?: string;
  desconto_valor?: number;
  desconto_percentual?: number;
  taxa_entrega?: number;
  outras_taxas?: number;
  servicos?: Array<{
    servico_id?: string;
    descricao: string;
    valor: number;
    quantidade: number;
  }>;
  pecas?: Array<{
    item_estoque_id?: string;
    descricao: string;
    valor: number;
    quantidade: number;
    observacao?: string;
  }>;
}

export const useOrdemServicoCreation = () => {
  const { empresa } = useAuth();
  const { toast } = useToast();
  const [isCreating, setIsCreating] = useState(false);

  const createOrdemServico = async (data: OrdemServicoData) => {
    if (!empresa) {
      throw new Error('Empresa não encontrada');
    }

    setIsCreating(true);

    try {
      // Validações básicas
      if (!data.cliente_id) {
        throw new Error('Cliente deve ser selecionado');
      }
      if (!data.veiculo_id) {
        throw new Error('Veículo deve ser selecionado');
      }

      // VALIDAÇÃO CRÍTICA DE SEGURANÇA: Verificar se o veículo pertence ao cliente selecionado
      const { data: veiculoValidacao, error: validacaoError } = await supabase
        .from('veiculos')
        .select('cliente_id')
        .eq('id', data.veiculo_id)
        .eq('empresa_id', empresa.id)
        .single();

      if (validacaoError || !veiculoValidacao) {
        throw new Error('Veículo não encontrado ou inválido');
      }

      if (veiculoValidacao.cliente_id !== data.cliente_id) {
        throw new Error('O veículo selecionado não pertence ao cliente escolhido');
      }

      // Calcular totais com segurança a partir dos itens
      const totalServicosCalc = Array.isArray(data.servicos) 
        ? data.servicos.reduce((acc, s) => acc + (s.valor || 0) * (s.quantidade || 1), 0) 
        : 0;
      
      const totalPecasCalc = Array.isArray(data.pecas) 
        ? data.pecas.reduce((acc, p) => acc + (p.valor || 0) * (p.quantidade || 1), 0) 
        : 0;
      
      const descontoPercentual = data.desconto_percentual || 0;
      const descontoValor = data.desconto_valor || 0;
      const subtotalCalc = totalServicosCalc + totalPecasCalc;
      const descontoCalc = descontoPercentual > 0 ? subtotalCalc * (descontoPercentual / 100) : descontoValor;
      const taxaEntrega = data.taxa_entrega || 0;
      const outrasTaxas = data.outras_taxas || 0;
      const totalGeralCalc = subtotalCalc - descontoCalc + taxaEntrega + outrasTaxas;

      // Criar ordem de serviço principal - PADRONIZANDO defeitos_reclamacoes
      const novaOrdem = {
        cliente_id: data.cliente_id,
        veiculo_id: data.veiculo_id,
        tecnico_id: data.tecnico_id || null,
        empresa_id: empresa.id,
        status: data.status || 'aguardando_aprovacao',
        defeitos_reclamacoes: data.defeitos_reclamacoes || '', // Campo unificado
        defeito_relatado: data.defeitos_reclamacoes || '', // Manter por compatibilidade
        descricao: data.descricao || '',
        data_entrega: data.data_entrega || null,
        garantia: data.garantia || '',
        clausulas_contratuais: data.clausulas_contratuais || '',
        relatorio_tecnico: data.relatorio_tecnico || '',
        condicoes_pagamento: data.condicoes_pagamento || '',
        informacoes_adicionais: data.informacoes_adicionais || '',
        notificacao_automatica: !!data.notificacao_automatica,
        compromisso_retorno: data.compromisso_retorno || null,
        total_servicos: totalServicosCalc,
        total_pecas: totalPecasCalc,
        total_geral: totalGeralCalc,
        desconto_valor: descontoValor,
        desconto_percentual: descontoPercentual,
        taxa_entrega: taxaEntrega,
        outras_taxas: outrasTaxas,
      };

      const { data: ordemResult, error: ordemError } = await supabase
        .from('ordens_servico')
        .insert([novaOrdem])
        .select()
        .single();

      if (ordemError) {
        throw ordemError;
      }

      // Inserir serviços se existirem
      if (data.servicos && data.servicos.length > 0) {
        const servicosData = data.servicos.map((servico) => ({
          ordem_servico_id: ordemResult.id,
          servico_id: servico.servico_id || null,
          descricao: servico.descricao,
          valor: servico.valor || 0,
          quantidade: servico.quantidade || 1,
        }));

        const { error: servicosError } = await supabase
          .from('servicos_os')
          .insert(servicosData);

        if (servicosError) {
          throw servicosError;
        }
      }

      // Inserir peças se existirem
      if (data.pecas && data.pecas.length > 0) {
        const pecasData = data.pecas.map((peca) => ({
          ordem_servico_id: ordemResult.id,
          item_estoque_id: peca.item_estoque_id || null,
          descricao: peca.descricao,
          valor: peca.valor || 0,
          quantidade: peca.quantidade || 1,
          observacao: peca.observacao || '',
        }));

        const { error: pecasError } = await supabase
          .from('pecas_os')
          .insert(pecasData);

        if (pecasError) {
          throw pecasError;
        }
      }

      toast({
        title: "Ordem de Serviço criada",
        description: `O.S. #${ordemResult.numero_os || ordemResult.id?.substring(0, 8)} foi criada com sucesso.`,
      });

      return ordemResult;

    } catch (error: any) {
      console.error('Erro ao criar ordem de serviço:', error);
      toast({
        title: "Erro ao criar ordem",
        description: error.message || "Tente novamente.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsCreating(false);
    }
  };

  return {
    createOrdemServico,
    isCreating
  };
};