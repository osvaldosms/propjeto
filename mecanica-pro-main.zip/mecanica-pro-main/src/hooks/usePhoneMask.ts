import { useState, useCallback } from 'react';
import { formatPhone, unformatPhone } from '@/lib/validation';

interface UsePhoneMaskOptions {
  initialValue?: string;
  onChange?: (unformattedValue: string) => void;
}

export const usePhoneMask = ({ initialValue = '', onChange }: UsePhoneMaskOptions = {}) => {
  const [displayValue, setDisplayValue] = useState(() => formatPhone(initialValue));

  const handleChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = event.target.value;
    const unformatted = unformatPhone(inputValue);
    
    // Limit to 11 digits
    if (unformatted.length <= 11) {
      const formatted = formatPhone(unformatted);
      setDisplayValue(formatted);
      onChange?.(unformatted);
    }
  }, [onChange]);

  const setValue = useCallback((value: string) => {
    const unformatted = unformatPhone(value);
    const formatted = formatPhone(unformatted);
    setDisplayValue(formatted);
  }, []);

  return {
    value: displayValue,
    onChange: handleChange,
    setValue,
    unformattedValue: unformatPhone(displayValue)
  };
};