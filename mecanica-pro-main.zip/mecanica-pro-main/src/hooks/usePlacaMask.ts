import { useState, useCallback } from 'react';
import { formatPlaca } from '@/lib/validation';

interface UsePlacaMaskOptions {
  initialValue?: string;
  onChange?: (formattedValue: string) => void;
}

export const usePlacaMask = ({ initialValue = '', onChange }: UsePlacaMaskOptions = {}) => {
  const [displayValue, setDisplayValue] = useState(() => formatPlaca(initialValue));

  const handleChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = event.target.value;
    const formatted = formatPlaca(inputValue);
    
    setDisplayValue(formatted);
    onChange?.(formatted);
  }, [onChange]);

  const setValue = useCallback((value: string) => {
    const formatted = formatPlaca(value);
    setDisplayValue(formatted);
  }, []);

  return {
    value: displayValue,
    onChange: handleChange,
    setValue
  };
};