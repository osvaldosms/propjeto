import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface PlanInfo {
  plan: 'trial' | 'essencial' | 'profissional' | 'premium' | 'expired';
  is_trial: boolean;
  trial_expired: boolean;
  trial_days_left: number;
  subscribed: boolean;
  subscription_end?: string;
}

export interface PlanLimits {
  maxServiceOrders: number;
  hasFinancialModule: boolean;
  hasInventoryModule: boolean;
  hasReportsModule: boolean;
  hasExportFunction: boolean;
  hasIntegrations: boolean;
  hasAutomations: boolean;
  hasPrioritySupport: boolean;
}

export const usePlanAccess = () => {
  const { user } = useAuth();
  const [planInfo, setPlanInfo] = useState<PlanInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchPlanInfo = async () => {
    if (!user) {
      setIsLoading(false);
      return;
    }

    try {
      // Por enquanto, definir como trial por padrão
      setPlanInfo({
        plan: 'trial',
        is_trial: true,
        trial_expired: false,
        trial_days_left: 14,
        subscribed: false
      });
    } catch (error) {
      console.error('Error fetching plan info:', error);
      // Fallback para trial se houver erro
      setPlanInfo({
        plan: 'trial',
        is_trial: true,
        trial_expired: false,
        trial_days_left: 14,
        subscribed: false
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPlanInfo();
  }, [user]);

  const checkAccess = (requiredPlan: string): boolean => {
    // DEVELOPMENT MODE: All features unlocked
    return true;
  };

  const getPlanLimits = (): PlanLimits => {
    // DEVELOPMENT MODE: All features unlocked
    return {
      maxServiceOrders: -1, // unlimited
      hasFinancialModule: true,
      hasInventoryModule: true,
      hasReportsModule: true,
      hasExportFunction: true,
      hasIntegrations: true,
      hasAutomations: true,
      hasPrioritySupport: true,
    };
  };

  const refreshPlanInfo = () => {
    fetchPlanInfo();
  };

  return {
    planInfo,
    isLoading,
    checkAccess,
    getPlanLimits,
    refreshPlanInfo,
  };
};