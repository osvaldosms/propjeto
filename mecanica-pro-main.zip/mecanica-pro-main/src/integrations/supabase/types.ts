export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      agendamentos: {
        Row: {
          cliente_id: string | null
          data_agendada: string | null
          empresa_id: string
          id: string
          observacoes: string | null
          status: string | null
          veiculo_id: string | null
        }
        Insert: {
          cliente_id?: string | null
          data_agendada?: string | null
          empresa_id: string
          id?: string
          observacoes?: string | null
          status?: string | null
          veiculo_id?: string | null
        }
        Update: {
          cliente_id?: string | null
          data_agendada?: string | null
          empresa_id?: string
          id?: string
          observacoes?: string | null
          status?: string | null
          veiculo_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agendamentos_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "agendamentos_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "agendamentos_veiculo_id_fkey"
            columns: ["veiculo_id"]
            isOneToOne: false
            referencedRelation: "veiculos"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string | null
          empresa_id: string | null
          id: string
          new_values: Json | null
          old_values: Json | null
          record_id: string | null
          table_name: string
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string | null
          empresa_id?: string | null
          id?: string
          new_values?: Json | null
          old_values?: Json | null
          record_id?: string | null
          table_name: string
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string | null
          empresa_id?: string | null
          id?: string
          new_values?: Json | null
          old_values?: Json | null
          record_id?: string | null
          table_name?: string
          user_id?: string | null
        }
        Relationships: []
      }
      categorias_financeiras: {
        Row: {
          empresa_id: string
          id: string
          nome: string
        }
        Insert: {
          empresa_id: string
          id?: string
          nome: string
        }
        Update: {
          empresa_id?: string
          id?: string
          nome?: string
        }
        Relationships: [
          {
            foreignKeyName: "categorias_financeiras_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      clientes: {
        Row: {
          cpf: string | null
          created_at: string
          email: string | null
          empresa_id: string
          endereco: string | null
          id: string
          nome: string
          telefone: string | null
        }
        Insert: {
          cpf?: string | null
          created_at?: string
          email?: string | null
          empresa_id: string
          endereco?: string | null
          id?: string
          nome: string
          telefone?: string | null
        }
        Update: {
          cpf?: string | null
          created_at?: string
          email?: string | null
          empresa_id?: string
          endereco?: string | null
          id?: string
          nome?: string
          telefone?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "clientes_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_cliente_empresa"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      empresas: {
        Row: {
          cnpj: string | null
          created_at: string
          email: string | null
          endereco: string | null
          endereco_completo: string | null
          facebook: string | null
          id: string
          instagram: string | null
          logo: string | null
          nome: string
          responsavel_tecnico: string | null
          telefone: string | null
          updated_at: string
          whatsapp: string | null
        }
        Insert: {
          cnpj?: string | null
          created_at?: string
          email?: string | null
          endereco?: string | null
          endereco_completo?: string | null
          facebook?: string | null
          id?: string
          instagram?: string | null
          logo?: string | null
          nome: string
          responsavel_tecnico?: string | null
          telefone?: string | null
          updated_at?: string
          whatsapp?: string | null
        }
        Update: {
          cnpj?: string | null
          created_at?: string
          email?: string | null
          endereco?: string | null
          endereco_completo?: string | null
          facebook?: string | null
          id?: string
          instagram?: string | null
          logo?: string | null
          nome?: string
          responsavel_tecnico?: string | null
          telefone?: string | null
          updated_at?: string
          whatsapp?: string | null
        }
        Relationships: []
      }
      itens_estoque: {
        Row: {
          categoria: string | null
          created_at: string
          empresa_id: string
          estoque_minimo: number
          fornecedor: string | null
          id: string
          nome: string
          preco_unitario: number
          quantidade: number
          updated_at: string
        }
        Insert: {
          categoria?: string | null
          created_at?: string
          empresa_id: string
          estoque_minimo?: number
          fornecedor?: string | null
          id?: string
          nome: string
          preco_unitario?: number
          quantidade?: number
          updated_at?: string
        }
        Update: {
          categoria?: string | null
          created_at?: string
          empresa_id?: string
          estoque_minimo?: number
          fornecedor?: string | null
          id?: string
          nome?: string
          preco_unitario?: number
          quantidade?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "itens_estoque_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      ordens_servico: {
        Row: {
          clausulas_contratuais: string | null
          cliente_id: string
          compromisso_retorno: string | null
          condicoes_pagamento: string | null
          data_abertura: string
          data_entrega: string | null
          defeito_relatado: string | null
          defeitos_reclamacoes: string | null
          desconto_percentual: number | null
          desconto_valor: number | null
          descricao: string | null
          empresa_id: string
          garantia: string | null
          id: string
          informacoes_adicionais: string | null
          notificacao_automatica: boolean | null
          numero_os: number | null
          outras_taxas: number | null
          relatorio_tecnico: string | null
          status: string | null
          taxa_entrega: number | null
          tecnico_id: string | null
          total_geral: number | null
          total_pecas: number | null
          total_servicos: number | null
          updated_at: string | null
          veiculo_id: string
        }
        Insert: {
          clausulas_contratuais?: string | null
          cliente_id: string
          compromisso_retorno?: string | null
          condicoes_pagamento?: string | null
          data_abertura?: string
          data_entrega?: string | null
          defeito_relatado?: string | null
          defeitos_reclamacoes?: string | null
          desconto_percentual?: number | null
          desconto_valor?: number | null
          descricao?: string | null
          empresa_id: string
          garantia?: string | null
          id?: string
          informacoes_adicionais?: string | null
          notificacao_automatica?: boolean | null
          numero_os?: number | null
          outras_taxas?: number | null
          relatorio_tecnico?: string | null
          status?: string | null
          taxa_entrega?: number | null
          tecnico_id?: string | null
          total_geral?: number | null
          total_pecas?: number | null
          total_servicos?: number | null
          updated_at?: string | null
          veiculo_id: string
        }
        Update: {
          clausulas_contratuais?: string | null
          cliente_id?: string
          compromisso_retorno?: string | null
          condicoes_pagamento?: string | null
          data_abertura?: string
          data_entrega?: string | null
          defeito_relatado?: string | null
          defeitos_reclamacoes?: string | null
          desconto_percentual?: number | null
          desconto_valor?: number | null
          descricao?: string | null
          empresa_id?: string
          garantia?: string | null
          id?: string
          informacoes_adicionais?: string | null
          notificacao_automatica?: boolean | null
          numero_os?: number | null
          outras_taxas?: number | null
          relatorio_tecnico?: string | null
          status?: string | null
          taxa_entrega?: number | null
          tecnico_id?: string | null
          total_geral?: number | null
          total_pecas?: number | null
          total_servicos?: number | null
          updated_at?: string | null
          veiculo_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_os_cliente"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_os_empresa"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_os_veiculo"
            columns: ["veiculo_id"]
            isOneToOne: false
            referencedRelation: "veiculos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ordens_servico_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ordens_servico_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ordens_servico_tecnico_id_fkey"
            columns: ["tecnico_id"]
            isOneToOne: false
            referencedRelation: "tecnicos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ordens_servico_veiculo_id_fkey"
            columns: ["veiculo_id"]
            isOneToOne: false
            referencedRelation: "veiculos"
            referencedColumns: ["id"]
          },
        ]
      }
      pecas_os: {
        Row: {
          descricao: string | null
          id: string
          item_estoque_id: string | null
          observacao: string | null
          ordem_servico_id: string
          quantidade: number
          subtotal: number | null
          updated_at: string | null
          valor: number | null
        }
        Insert: {
          descricao?: string | null
          id?: string
          item_estoque_id?: string | null
          observacao?: string | null
          ordem_servico_id: string
          quantidade?: number
          subtotal?: number | null
          updated_at?: string | null
          valor?: number | null
        }
        Update: {
          descricao?: string | null
          id?: string
          item_estoque_id?: string | null
          observacao?: string | null
          ordem_servico_id?: string
          quantidade?: number
          subtotal?: number | null
          updated_at?: string | null
          valor?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "pecas_os_item_estoque_id_fkey"
            columns: ["item_estoque_id"]
            isOneToOne: false
            referencedRelation: "itens_estoque"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pecas_os_ordem_servico_id_fkey"
            columns: ["ordem_servico_id"]
            isOneToOne: false
            referencedRelation: "ordens_servico"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          empresa_id: string
          id: string
          nome: string
          perfil: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          empresa_id: string
          id: string
          nome: string
          perfil?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          empresa_id?: string
          id?: string
          nome?: string
          perfil?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_profile_empresa"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      servicos: {
        Row: {
          descricao: string | null
          empresa_id: string
          id: string
          nome: string
          preco: number | null
        }
        Insert: {
          descricao?: string | null
          empresa_id: string
          id?: string
          nome: string
          preco?: number | null
        }
        Update: {
          descricao?: string | null
          empresa_id?: string
          id?: string
          nome?: string
          preco?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "servicos_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      servicos_os: {
        Row: {
          descricao: string | null
          id: string
          ordem_servico_id: string
          quantidade: number
          servico_id: string | null
          subtotal: number | null
          updated_at: string | null
          valor: number | null
        }
        Insert: {
          descricao?: string | null
          id?: string
          ordem_servico_id: string
          quantidade?: number
          servico_id?: string | null
          subtotal?: number | null
          updated_at?: string | null
          valor?: number | null
        }
        Update: {
          descricao?: string | null
          id?: string
          ordem_servico_id?: string
          quantidade?: number
          servico_id?: string | null
          subtotal?: number | null
          updated_at?: string | null
          valor?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "servicos_os_ordem_servico_id_fkey"
            columns: ["ordem_servico_id"]
            isOneToOne: false
            referencedRelation: "ordens_servico"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "servicos_os_servico_id_fkey"
            columns: ["servico_id"]
            isOneToOne: false
            referencedRelation: "servicos"
            referencedColumns: ["id"]
          },
        ]
      }
      subscribers: {
        Row: {
          created_at: string
          customer_id: string | null
          email: string
          id: string
          is_trial: boolean | null
          subscribed: boolean
          subscription_end: string | null
          subscription_id: string | null
          subscription_tier: string | null
          trial_end: string | null
          trial_start: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          customer_id?: string | null
          email: string
          id?: string
          is_trial?: boolean | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_id?: string | null
          subscription_tier?: string | null
          trial_end?: string | null
          trial_start?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          customer_id?: string | null
          email?: string
          id?: string
          is_trial?: boolean | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_id?: string | null
          subscription_tier?: string | null
          trial_end?: string | null
          trial_start?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      tecnicos: {
        Row: {
          contato: string | null
          empresa_id: string
          funcao: string | null
          id: string
          nome: string
        }
        Insert: {
          contato?: string | null
          empresa_id: string
          funcao?: string | null
          id?: string
          nome: string
        }
        Update: {
          contato?: string | null
          empresa_id?: string
          funcao?: string | null
          id?: string
          nome?: string
        }
        Relationships: [
          {
            foreignKeyName: "tecnicos_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      transacoes_financeiras: {
        Row: {
          categoria: string | null
          cliente_id: string | null
          data: string
          descricao: string | null
          empresa_id: string
          id: string
          tipo: string
          valor: number
        }
        Insert: {
          categoria?: string | null
          cliente_id?: string | null
          data?: string
          descricao?: string | null
          empresa_id: string
          id?: string
          tipo: string
          valor: number
        }
        Update: {
          categoria?: string | null
          cliente_id?: string | null
          data?: string
          descricao?: string | null
          empresa_id?: string
          id?: string
          tipo?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "transacoes_financeiras_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transacoes_financeiras_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      veiculos: {
        Row: {
          ano: number | null
          chassi: string | null
          cliente_id: string
          combustivel: string | null
          cor: string | null
          created_at: string
          empresa_id: string
          id: string
          marca: string
          modelo: string
          placa: string
          quilometragem: number | null
          updated_at: string
        }
        Insert: {
          ano?: number | null
          chassi?: string | null
          cliente_id: string
          combustivel?: string | null
          cor?: string | null
          created_at?: string
          empresa_id: string
          id?: string
          marca: string
          modelo: string
          placa: string
          quilometragem?: number | null
          updated_at?: string
        }
        Update: {
          ano?: number | null
          chassi?: string | null
          cliente_id?: string
          combustivel?: string | null
          cor?: string | null
          created_at?: string
          empresa_id?: string
          id?: string
          marca?: string
          modelo?: string
          placa?: string
          quilometragem?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_veiculo_cliente"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_veiculo_empresa"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "veiculos_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "veiculos_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_plan_access: {
        Args: { required_plan: string }
        Returns: boolean
      }
      check_trial_os_limit: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      create_empresa_and_profile: {
        Args: { p_nome_empresa: string; p_role?: string }
        Returns: {
          empresa_id: string
        }[]
      }
      get_user_empresa_id: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_user_plan_info: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      validate_cnpj: {
        Args: { cnpj_input: string }
        Returns: boolean
      }
      validate_cpf: {
        Args: { cpf_input: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
