export interface OrdemServicoData {
  numero_os: number;
  cliente_nome: string;
  cliente_telefone?: string;
  cliente_email?: string;
  cliente_endereco?: string;
  cliente_cpf?: string;
  veiculo_marca?: string;
  veiculo_modelo?: string;
  veiculo_placa?: string;
  veiculo_ano?: number;
  veiculo_cor?: string;
  veiculo_combustivel?: string;
  veiculo_km?: number;
  status: string;
  data_abertura: string;
  data_entrega?: string;
  defeitos_reclamacoes?: string;
  descricao?: string;
  relatorio_tecnico?: string;
  servicos?: Array<{
    descricao: string;
    quantidade: number;
    valor: number;
    subtotal: number;
  }>;
  pecas?: Array<{
    descricao: string;
    quantidade: number;
    valor: number;
    observacao?: string;
    subtotal: number;
  }>;
  total_servicos: number;
  total_pecas: number;
  desconto_valor?: number;
  desconto_percentual?: number;
  taxa_entrega?: number;
  outras_taxas?: number;
  total_geral: number;
  empresa_nome: string;
  empresa_telefone?: string;
  empresa_endereco?: string;
  empresa_cnpj?: string;
  empresa_logo?: string;
  empresa_responsavel?: string;
  garantia?: string;
  clausulas_contratuais?: string;
  condicoes_pagamento?: string;
  meios_pagamento?: string[];
  observacoes?: string;
}

export const generateOSPDF = async (osData: OrdemServicoData): Promise<void> => {
  try {
    const { jsPDF } = await import('jspdf');
    const html2canvas = (await import('html2canvas')).default;

    // Criar elemento HTML temporário para o PDF
    const tempDiv = document.createElement('div');
    tempDiv.style.position = 'absolute';
    tempDiv.style.left = '-9999px';
    tempDiv.style.width = '210mm';
    tempDiv.style.backgroundColor = 'white';
    tempDiv.style.padding = '20px';
    tempDiv.style.fontFamily = 'Arial, sans-serif';
    tempDiv.style.fontSize = '14px';
    tempDiv.style.lineHeight = '1.4';
    
    const logoImg = osData.empresa_logo ? `<img src="${osData.empresa_logo}" alt="Logo" style="max-height: 80px; max-width: 200px; object-fit: contain;" />` : '';
    
    tempDiv.innerHTML = `
      <div style="max-width: 210mm; margin: 0 auto; background: white; color: #333; font-family: Arial, sans-serif;">
        
        <!-- Cabeçalho -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; padding: 20px 0; border-bottom: 1px solid #ccc; margin-bottom: 20px;">
          <div style="flex: 1;">
            ${logoImg}
          </div>
          
          <div style="flex: 2; text-align: center;">
            <h1 style="margin: 0; font-size: 18px; font-weight: bold; color: #333; text-transform: uppercase; letter-spacing: 1px;">
              ${osData.empresa_nome}
            </h1>
          </div>
          
          <div style="flex: 1; text-align: right; font-size: 11px; color: #666; line-height: 1.4;">
            ${osData.empresa_responsavel ? `<p style="margin: 0 0 4px 0;">Responsável: ${osData.empresa_responsavel}</p>` : ''}
            ${osData.empresa_cnpj ? `<p style="margin: 0 0 4px 0;">CNPJ: ${formatCNPJ(osData.empresa_cnpj)}</p>` : ''}
            ${osData.empresa_endereco ? `<p style="margin: 0 0 4px 0;">${osData.empresa_endereco}</p>` : ''}
            ${osData.empresa_telefone ? `<p style="margin: 0 0 4px 0;">Tel/WhatsApp: ${formatPhone(osData.empresa_telefone)}</p>` : ''}
            <div style="border-top: 1px solid #ccc; padding-top: 4px; margin-top: 8px;">
              <p style="margin: 0; font-size: 10px;">Data: ${new Date().toLocaleDateString('pt-BR')}</p>
            </div>
          </div>
        </div>
        
        <!-- Título da Ordem de Serviço -->
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="margin: 0; font-size: 16px; font-weight: bold; color: #333; text-transform: uppercase;">
            ORDEM DE SERVIÇO
          </h2>
          <div style="margin-top: 5px; padding: 5px 10px; border: 1px solid #333; display: inline-block;">
            <span style="font-size: 14px; font-weight: bold;">Nº ${osData.numero_os}</span>
          </div>
          <p style="margin: 5px 0 0 0; font-size: 11px; color: #666;">Data de Abertura: ${new Date(osData.data_abertura).toLocaleDateString('pt-BR')}</p>
        </div>

        <!-- Informações do Cliente e Veículo em 2 Colunas -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
          <!-- Cliente -->
          <div>
            <h3 style="margin: 0 0 10px 0; font-size: 14px; font-weight: bold; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 4px;">
              CLIENTE
            </h3>
            <p style="margin: 4px 0; font-size: 12px;"><strong>Nome:</strong> ${osData.cliente_nome}</p>
            ${osData.cliente_telefone ? `<p style="margin: 4px 0; font-size: 12px;"><strong>Telefone:</strong> ${formatPhone(osData.cliente_telefone)}</p>` : ''}
            ${osData.cliente_cpf ? `<p style="margin: 4px 0; font-size: 12px;"><strong>CPF:</strong> ${osData.cliente_cpf}</p>` : ''}
            ${osData.cliente_email ? `<p style="margin: 4px 0; font-size: 12px;"><strong>E-mail:</strong> ${osData.cliente_email}</p>` : ''}
            ${osData.cliente_endereco ? `<p style="margin: 4px 0; font-size: 12px;"><strong>Endereço:</strong> ${osData.cliente_endereco}</p>` : ''}
          </div>
          
          <!-- Veículo -->
          <div>
            <h3 style="margin: 0 0 10px 0; font-size: 14px; font-weight: bold; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 4px;">
              VEÍCULO
            </h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 12px;">
              <div>
                ${osData.veiculo_marca ? `<p style="margin: 4px 0;"><strong>Marca:</strong> ${osData.veiculo_marca}</p>` : ''}
                ${osData.veiculo_placa ? `<p style="margin: 4px 0;"><strong>Placa:</strong> ${osData.veiculo_placa}</p>` : ''}
                ${osData.veiculo_ano ? `<p style="margin: 4px 0;"><strong>Ano:</strong> ${osData.veiculo_ano}</p>` : ''}
                ${osData.veiculo_km ? `<p style="margin: 4px 0;"><strong>KM:</strong> ${osData.veiculo_km.toLocaleString()}</p>` : ''}
              </div>
              <div>
                ${osData.veiculo_modelo ? `<p style="margin: 4px 0;"><strong>Modelo:</strong> ${osData.veiculo_modelo}</p>` : ''}
                ${osData.veiculo_cor ? `<p style="margin: 4px 0;"><strong>Cor:</strong> ${osData.veiculo_cor}</p>` : ''}
                ${osData.veiculo_combustivel ? `<p style="margin: 4px 0;"><strong>Combustível:</strong> ${osData.veiculo_combustivel}</p>` : ''}
              </div>
            </div>
          </div>
        </div>

        <!-- Defeito -->
        ${osData.defeitos_reclamacoes ? `
          <div style="margin-bottom: 20px;">
            <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: bold; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 4px;">
              DEFEITO
            </h3>
            <div style="border: 1px solid #ddd; padding: 10px; background: #f9f9f9;">
              <p style="margin: 0; font-size: 12px; line-height: 1.4;">${osData.defeitos_reclamacoes}</p>
            </div>
          </div>
        ` : ''}

        <!-- Serviços -->
        ${osData.servicos && osData.servicos.length > 0 ? `
          <div style="margin-bottom: 20px;">
            <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: bold; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 4px;">
              SERVIÇOS
            </h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
              <thead>
                <tr style="background: #f0f0f0;">
                  <th style="border: 1px solid #ddd; padding: 6px; text-align: left;">Descrição</th>
                  <th style="border: 1px solid #ddd; padding: 6px; text-align: center; width: 60px;">Unidade</th>
                  <th style="border: 1px solid #ddd; padding: 6px; text-align: right; width: 80px;">Preço unitário</th>
                  <th style="border: 1px solid #ddd; padding: 6px; text-align: center; width: 40px;">Qtd.</th>
                  <th style="border: 1px solid #ddd; padding: 6px; text-align: right; width: 80px;">Preço</th>
                </tr>
              </thead>
              <tbody>
                ${osData.servicos.map(servico => `
                  <tr>
                    <td style="border: 1px solid #ddd; padding: 6px;">${servico.descricao}</td>
                    <td style="border: 1px solid #ddd; padding: 6px; text-align: center;">UN</td>
                    <td style="border: 1px solid #ddd; padding: 6px; text-align: right;">${formatCurrency(servico.valor)}</td>
                    <td style="border: 1px solid #ddd; padding: 6px; text-align: center;">${servico.quantidade}</td>
                    <td style="border: 1px solid #ddd; padding: 6px; text-align: right;">${formatCurrency(servico.subtotal)}</td>
                  </tr>
                `).join('')}
                <tr style="background: #f0f0f0; font-weight: bold;">
                  <td colspan="4" style="border: 1px solid #ddd; padding: 6px; text-align: right;">Subtotal Serviços:</td>
                  <td style="border: 1px solid #ddd; padding: 6px; text-align: right;">${formatCurrency(osData.total_servicos)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        ` : ''}

        <!-- Peças -->
        ${osData.pecas && osData.pecas.length > 0 ? `
          <div style="margin-bottom: 20px;">
            <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: bold; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 4px;">
              PEÇAS
            </h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
              <thead>
                <tr style="background: #f0f0f0;">
                  <th style="border: 1px solid #ddd; padding: 6px; text-align: left;">Descrição</th>
                  <th style="border: 1px solid #ddd; padding: 6px; text-align: center; width: 60px;">Unidade</th>
                  <th style="border: 1px solid #ddd; padding: 6px; text-align: right; width: 80px;">Preço unitário</th>
                  <th style="border: 1px solid #ddd; padding: 6px; text-align: center; width: 40px;">Qtd.</th>
                  <th style="border: 1px solid #ddd; padding: 6px; text-align: right; width: 80px;">Preço</th>
                </tr>
              </thead>
              <tbody>
                ${osData.pecas.map(peca => `
                  <tr>
                    <td style="border: 1px solid #ddd; padding: 6px;">${peca.descricao}</td>
                    <td style="border: 1px solid #ddd; padding: 6px; text-align: center;">UN</td>
                    <td style="border: 1px solid #ddd; padding: 6px; text-align: right;">${formatCurrency(peca.valor)}</td>
                    <td style="border: 1px solid #ddd; padding: 6px; text-align: center;">${peca.quantidade}</td>
                    <td style="border: 1px solid #ddd; padding: 6px; text-align: right;">${formatCurrency(peca.subtotal)}</td>
                  </tr>
                `).join('')}
                <tr style="background: #f0f0f0; font-weight: bold;">
                  <td colspan="4" style="border: 1px solid #ddd; padding: 6px; text-align: right;">Subtotal Peças:</td>
                  <td style="border: 1px solid #ddd; padding: 6px; text-align: right;">${formatCurrency(osData.total_pecas)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        ` : ''}

        <!-- Resumo Financeiro -->
        <div style="margin-bottom: 20px;">
          <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: bold; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 4px;">
            RESUMO FINANCEIRO
          </h3>
          <div style="text-align: right; font-size: 12px;">
            <p style="margin: 4px 0;"><strong>Subtotal Serviços:</strong> ${formatCurrency(osData.total_servicos)}</p>
            <p style="margin: 4px 0;"><strong>Subtotal Peças:</strong> ${formatCurrency(osData.total_pecas)}</p>
            ${osData.desconto_valor && osData.desconto_valor > 0 ? `
              <p style="margin: 4px 0; color: #dc2626;"><strong>Desconto:</strong> -${formatCurrency(osData.desconto_valor)}</p>
            ` : ''}
            ${osData.desconto_percentual && osData.desconto_percentual > 0 ? `
              <p style="margin: 4px 0; color: #dc2626;"><strong>Desconto (%):</strong> ${osData.desconto_percentual}%</p>
            ` : ''}
            ${osData.taxa_entrega && osData.taxa_entrega > 0 ? `
              <p style="margin: 4px 0;"><strong>Taxa de Entrega:</strong> ${formatCurrency(osData.taxa_entrega)}</p>
            ` : ''}
            ${osData.outras_taxas && osData.outras_taxas > 0 ? `
              <p style="margin: 4px 0;"><strong>Outras Taxas:</strong> ${formatCurrency(osData.outras_taxas)}</p>
            ` : ''}
            <div style="border: 2px solid #333; padding: 8px; display: inline-block; margin-top: 8px;">
              <p style="margin: 0; font-size: 16px; font-weight: bold;">TOTAL GERAL: ${formatCurrency(osData.total_geral)}</p>
            </div>
          </div>
        </div>

        <!-- Meios de Pagamento -->
        ${osData.meios_pagamento && osData.meios_pagamento.length > 0 ? `
          <div style="margin-bottom: 20px;">
            <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: bold; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 4px;">
              MEIOS DE PAGAMENTO
            </h3>
            <p style="margin: 0; font-size: 12px;">${osData.meios_pagamento.join(', ')}</p>
          </div>
        ` : `
          <div style="margin-bottom: 20px;">
            <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: bold; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 4px;">
              MEIOS DE PAGAMENTO
            </h3>
            <p style="margin: 0; font-size: 12px;">Transferência bancária, Dinheiro, Cheque, PIX, Cartão de débito, Cartão de crédito</p>
          </div>
        `}

        <!-- Garantia -->
        ${osData.garantia ? `
          <div style="margin-bottom: 20px;">
            <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: bold; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 4px;">
              GARANTIA
            </h3>
            <div style="border: 1px solid #ddd; padding: 10px;">
              <h4 style="margin: 0 0 6px 0; font-size: 12px; font-weight: bold;">Condições da garantia</h4>
              <p style="margin: 0; font-size: 11px; line-height: 1.4;">${osData.garantia}</p>
            </div>
          </div>
        ` : ''}

        <!-- Relatório -->
        ${osData.relatorio_tecnico ? `
          <div style="margin-bottom: 20px;">
            <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: bold; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 4px;">
              RELATÓRIO
            </h3>
            <div style="border: 1px solid #ddd; padding: 10px; background: #f9f9f9;">
              <p style="margin: 0; font-size: 11px; line-height: 1.4;">${osData.relatorio_tecnico}</p>
            </div>
          </div>
        ` : ''}

        <!-- Assinaturas -->
        <div style="margin-top: 40px;">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px;">
            <div style="text-align: center;">
              <div style="border-bottom: 1px solid #333; margin-bottom: 8px; height: 40px;"></div>
              <p style="margin: 0; font-size: 12px; font-weight: bold;">${osData.empresa_nome}</p>
              <p style="margin: 0; font-size: 11px; color: #666;">${osData.empresa_responsavel || 'Responsável Técnico'}</p>
            </div>
            <div style="text-align: center;">
              <div style="border-bottom: 1px solid #333; margin-bottom: 8px; height: 40px;"></div>
              <p style="margin: 0; font-size: 12px; font-weight: bold;">${osData.cliente_nome}</p>
              <p style="margin: 0; font-size: 11px; color: #666;">${osData.cliente_cpf ? `CPF: ${osData.cliente_cpf}` : 'Cliente'}</p>
            </div>
          </div>
        </div>

        <!-- Rodapé -->
        <div style="margin-top: 30px; border-top: 1px solid #ddd; padding-top: 10px; text-align: center;">
          <p style="margin: 0; font-size: 10px; color: #666;">
            ${osData.empresa_endereco || ''} - Tel: ${osData.empresa_telefone || ''} - E-mail: ${osData.empresa_cnpj ? `CNPJ: ${osData.empresa_cnpj}` : ''}
          </p>
          <p style="margin: 2px 0 0 0; font-size: 10px; color: #666;">
            Emitido em ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}
          </p>
        </div>
      </div>
    `;

    document.body.appendChild(tempDiv);

    // Converter para canvas
    const canvas = await html2canvas(tempDiv, {
      width: 794, // A4 width in pixels at 96 DPI
      height: 1123, // A4 height in pixels at 96 DPI
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff'
    });

    document.body.removeChild(tempDiv);

    // Criar PDF
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgData = canvas.toDataURL('image/png');
    
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = canvas.width;
    const imgHeight = canvas.height;
    const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
    const imgX = (pdfWidth - imgWidth * ratio) / 2;
    const imgY = 0;

    pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);

    // Salvar o PDF
    pdf.save(`OS-${osData.numero_os}-${osData.cliente_nome.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`);

  } catch (error) {
    console.error('Error generating PDF:', error);
    throw new Error('Não foi possível gerar o PDF. Tente novamente.');
  }
};

const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
};

const formatCNPJ = (cnpj: string): string => {
  const cleaned = cnpj.replace(/\D/g, '');
  if (cleaned.length === 14) {
    return cleaned.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  }
  return cnpj;
};

const formatPhone = (phone: string): string => {
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 11) {
    return cleaned.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  } else if (cleaned.length === 10) {
    return cleaned.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  }
  return phone;
};