import { z } from 'zod';

// Phase 3: Input Validation & Data Protection

// Common validation schemas
export const emailSchema = z.string()
  .email('Email inválido')
  .max(254, 'Email muito longo')
  .trim()
  .toLowerCase();

export const passwordSchema = z.string()
  .min(8, 'Senha deve ter pelo menos 8 caracteres')
  .max(128, 'Senha muito longa')
  .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, 'Senha deve conter pelo menos uma letra minúscula, uma maiúscula e um número');

export const nameSchema = z.string()
  .min(2, 'Nome deve ter pelo menos 2 caracteres')
  .max(100, 'Nome muito longo')
  .trim()
  .regex(/^[a-zA-ZÀ-ÿ\s]+$/, 'Nome deve conter apenas letras e espaços');

export const phoneSchema = z.string()
  .regex(/^\d{10,11}$/, 'Telefone deve ter 10 ou 11 dígitos')
  .optional();

export const cnpjSchema = z.string()
  .regex(/^\d{14}$/, 'CNPJ deve ter 14 dígitos')
  .optional();

export const placaSchema = z.string()
  .regex(/^[A-Z]{3}-?\d{4}$|^[A-Z]{3}\d[A-Z]\d{2}$/, 'Placa deve estar no formato ABC-1234 ou ABC1D23')
  .optional();

// Validação de CPF
export const cpfSchema = z.string()
  .regex(/^\d{11}$/, 'CPF deve ter 11 dígitos')
  .refine(validateCpfDigits, 'CPF inválido')
  .optional();

// Função para validar dígitos do CPF
export function validateCpfDigits(cpf: string): boolean {
  if (!cpf || cpf.length !== 11) return false;
  
  // Verifica sequências inválidas
  if (/^(\d)\1{10}$/.test(cpf)) return false;
  
  // Valida primeiro dígito
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cpf.charAt(i)) * (10 - i);
  }
  let digit = 11 - (sum % 11);
  if (digit >= 10) digit = 0;
  if (digit !== parseInt(cpf.charAt(9))) return false;
  
  // Valida segundo dígito
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cpf.charAt(i)) * (11 - i);
  }
  digit = 11 - (sum % 11);
  if (digit >= 10) digit = 0;
  return digit === parseInt(cpf.charAt(10));
}

// Função para formatar placa
export const formatPlaca = (placa: string): string => {
  if (!placa) return '';
  
  // Remove todos os caracteres não alfanuméricos e converte para maiúsculo
  const clean = placa.replace(/[^A-Z0-9]/g, '').toUpperCase();
  
  // Se está digitando e ainda não chegou ao formato completo, retorna o que tem
  if (clean.length <= 3) {
    return clean;
  }
  
  // Placa antiga (ABC1234) -> ABC-1234
  if (/^[A-Z]{3}\d{1,4}$/.test(clean)) {
    if (clean.length === 7) {
      return `${clean.slice(0, 3)}-${clean.slice(3)}`;
    }
    // Durante a digitação, adiciona hífen após as 3 letras
    return `${clean.slice(0, 3)}-${clean.slice(3)}`;
  }
  
  // Placa Mercosul (ABC1D23) -> mantém sem hífen
  if (/^[A-Z]{3}\d[A-Z]?\d{0,2}$/.test(clean)) {
    return clean;
  }
  
  // Para outros casos, tenta detectar se é placa antiga ou nova
  if (clean.length >= 4) {
    const fourthChar = clean[3];
    // Se o 4º caractere é letra, é Mercosul
    if (/[A-Z]/.test(fourthChar)) {
      return clean.slice(0, 7); // Limita a 7 caracteres para Mercosul
    } else {
      // Se o 4º caractere é número, é placa antiga
      const letters = clean.slice(0, 3);
      const numbers = clean.slice(3).replace(/[^0-9]/g, '');
      return `${letters}-${numbers}`.slice(0, 8); // ABC-1234
    }
  }
  
  return clean;
};

// Form validation schemas
export const loginFormSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Senha é obrigatória')
});

export const registerFormSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  confirmPassword: z.string(),
  workshopName: nameSchema,
  cnpj: cnpjSchema,
  phone: phoneSchema,
  address: z.string().max(500, 'Endereço muito longo').optional()
}).refine((data) => data.password === data.confirmPassword, {
  message: "Senhas não conferem",
  path: ["confirmPassword"],
});

export const clienteFormSchema = z.object({
  nome: nameSchema,
  telefone: phoneSchema,
  email: emailSchema.optional().or(z.literal('')),
  endereco: z.string().max(500, 'Endereço muito longo').optional()
});

export const veiculoFormSchema = z.object({
  cliente_id: z.string().min(1, 'Cliente é obrigatório'),
  marca: z.string().min(1, 'Marca é obrigatória').max(50, 'Marca muito longa'),
  modelo: z.string().min(1, 'Modelo é obrigatório').max(50, 'Modelo muito longo'),
  ano: z.coerce.number().optional(),
  placa: placaSchema,
  cor: z.string().optional(),
  quilometragem: z.coerce.number().optional(),
  combustivel: z.string().optional()
});

export const transacaoFormSchema = z.object({
  tipo: z.enum(['entrada', 'saida'], { required_error: 'Tipo é obrigatório' }),
  valor: z.number().positive('Valor deve ser positivo'),
  categoria: z.string().min(1, 'Categoria é obrigatória'),
  descricao: z.string().min(1, 'Descrição é obrigatória').max(200, 'Descrição muito longa'),
  data: z.string().min(1, 'Data é obrigatória'),
  metodo_pagamento: z.string().min(1, 'Método de pagamento é obrigatório'),
  cliente: z.string().max(100, 'Nome do cliente muito longo').optional(),
  observacoes: z.string().max(500, 'Observações muito longas').optional()
});

// Data sanitization utilities
export const sanitizeInput = (input: string): string => {
  return input
    .trim()
    .replace(/[<>]/g, '') // Remove HTML tags
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+=/gi, ''); // Remove event handlers
};

export const sanitizeObject = (obj: Record<string, any>): Record<string, any> => {
  const sanitized: Record<string, any> = {};
  
  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === 'string') {
      sanitized[key] = sanitizeInput(value);
    } else if (typeof value === 'object' && value !== null) {
      sanitized[key] = sanitizeObject(value);
    } else {
      sanitized[key] = value;
    }
  }
  
  return sanitized;
};

// Rate limiting helpers
export const createRateLimiter = (maxRequests: number, windowMs: number) => {
  const requests = new Map<string, number[]>();
  
  return (identifier: string): boolean => {
    const now = Date.now();
    const windowStart = now - windowMs;
    
    if (!requests.has(identifier)) {
      requests.set(identifier, []);
    }
    
    const userRequests = requests.get(identifier)!;
    const validRequests = userRequests.filter(time => time > windowStart);
    
    if (validRequests.length >= maxRequests) {
      return false; // Rate limit exceeded
    }
    
    validRequests.push(now);
    requests.set(identifier, validRequests);
    return true;
  };
};

// CSRF token generator
export const generateCSRFToken = (): string => {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
};

// Phone number formatting utilities
export const formatPhone = (phone: string): string => {
  if (!phone) return '';
  
  // Remove all non-digits
  const digits = phone.replace(/\D/g, '');
  
  // Format based on length
  if (digits.length === 10) {
    // Format: (XX) XXXX-XXXX
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  } else if (digits.length === 11) {
    // Format: (XX) 9XXXX-XXXX
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
  }
  
  return phone; // Return as-is if invalid length
};

export const unformatPhone = (phone: string): string => {
  if (!phone) return '';
  return phone.replace(/\D/g, '');
};

// CNPJ formatting utilities
export const formatCnpj = (cnpj: string): string => {
  if (!cnpj) return '';
  
  // Remove all non-digits
  const digits = cnpj.replace(/\D/g, '');
  
  // Format CPF: XXX.XXX.XXX-XX (11 digits)
  if (digits.length === 11) {
    return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9)}`;
  }
  
  // Format CNPJ: XX.XXX.XXX/XXXX-XX (14 digits)
  if (digits.length === 14) {
    return `${digits.slice(0, 2)}.${digits.slice(2, 5)}.${digits.slice(5, 8)}/${digits.slice(8, 12)}-${digits.slice(12)}`;
  }
  
  return digits; // Return partial formatting
};

export const unformatCnpj = (cnpj: string): string => {
  if (!cnpj) return '';
  return cnpj.replace(/\D/g, '');
};

// Validate CSRF token
export const validateCSRFToken = (token: string, expectedToken: string): boolean => {
  if (!token || !expectedToken || token.length !== expectedToken.length) {
    return false;
  }
  
  // Constant-time comparison to prevent timing attacks
  let result = 0;
  for (let i = 0; i < token.length; i++) {
    result |= token.charCodeAt(i) ^ expectedToken.charCodeAt(i);
  }
  
  return result === 0;
};