import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { LoginForm } from '@/components/auth/LoginForm';
import { RegisterForm } from '@/components/auth/RegisterForm';

export const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  useEffect(() => {
    // CRÍTICO: Detectar recovery em qualquer página como fallback
    const hash = window.location.hash || '';
    const search = window.location.search || '';
    
    // Múltiplas formas de detectar recovery
    const isRecoveryHash = hash.includes('type=recovery');
    const isRecoverySearch = search.includes('type=recovery') || searchParams.get('type') === 'recovery';
    const hasToken = hash.includes('token=') || search.includes('token=') || searchParams.get('token');
    const isReset = searchParams.get('reset') === 'true';
    
    console.log('🔍 Auth page recovery detection:', {
      hash,
      search,
      isRecoveryHash,
      isRecoverySearch, 
      hasToken,
      isReset,
      searchParams: Object.fromEntries(searchParams.entries())
    });
    
    if (isRecoveryHash || isRecoverySearch || hasToken || isReset) {
      console.log('🔄 Recovery detected in Auth page, redirecting to /nova-senha');
      navigate('/nova-senha', { replace: true });
    }
  }, [searchParams, navigate]);

  const toggleMode = () => {
    setIsLogin(!isLogin);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted p-4">
      <div className="w-full max-w-md">
        {isLogin ? (
          <LoginForm onToggleMode={toggleMode} />
        ) : (
          <RegisterForm onToggleMode={toggleMode} />
        )}
      </div>
    </div>
  );
};