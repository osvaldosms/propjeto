import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

export const AuthCallback: React.FC = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        console.log('🔐 AuthCallback started - URL:', window.location.href);
        console.log('🔍 URL Hash:', window.location.hash);
        console.log('🔍 URL Search:', window.location.search);
        console.log('🔍 Full Location:', window.location);
        
        // CRÍTICO: Verificar hash da URL primeiro para recuperação de senha
        const hash = window.location.hash || '';
        const search = window.location.search || '';
        
        console.log('🔍 AuthCallback - Hash:', hash);
        console.log('🔍 AuthCallback - Search:', search);
        
        // Verificar múltiplas formas de detectar recovery
        const isRecoveryHash = hash.includes('type=recovery');
        const isRecoverySearch = search.includes('type=recovery');
        const hasToken = hash.includes('token=') || search.includes('token=');
        
        console.log('🔍 Detection results:', {
          isRecoveryHash,
          isRecoverySearch,
          hasToken,
          shouldRedirect: isRecoveryHash || isRecoverySearch || hasToken
        });
        
        if (isRecoveryHash || isRecoverySearch || hasToken) {
          console.log('🔄 RECOVERY DETECTED - Redirecting to /nova-senha');
          navigate('/nova-senha', { replace: true });
          return;
        }

        // Configurar listener para eventos de auth como backup
        const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
          console.log('🔐 Auth callback event:', event, 'Session exists:', !!session);
          
          if (event === 'PASSWORD_RECOVERY') {
            console.log('🔄 PASSWORD_RECOVERY event detected, redirecting to /nova-senha');
            navigate('/nova-senha', { replace: true });
            return;
          }
          
          if (event === 'SIGNED_IN' && session) {
            // CRÍTICO: NUNCA redirecionar para dashboard se há type=recovery na URL
            const currentHash = window.location.hash || '';
            const currentSearch = window.location.search || '';
            
            console.log('🔍 SIGNED_IN - Current hash:', currentHash);
            console.log('🔍 SIGNED_IN - Current search:', currentSearch);
            
            if (currentHash.includes('type=recovery') || currentSearch.includes('type=recovery')) {
              console.log('🚫 BLOCKING dashboard redirect - Recovery flow detected');
              navigate('/nova-senha', { replace: true });
              return;
            }
            
            console.log('✅ User signed in (not recovery), redirecting to dashboard');
            navigate('/dashboard', { replace: true });
          }
        });

        // Processar a sessão da URL
        console.log('⚙️ Processing URL session...');
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('❌ Error getting session in auth callback:', error);
          navigate('/auth', { replace: true });
          return;
        }

        if (session) {
          const isRecovery = hash.includes('type=recovery') || search.includes('type=recovery');
          console.log('📋 Session found:', {
            userId: session.user?.id,
            email: session.user?.email,
            isRecovery: isRecovery
          });
          
          // CRÍTICO: Se é recovery, SEMPRE redirecionar para nova senha
          if (isRecovery) {
            console.log('🔄 Recovery session detected, redirecting to /nova-senha');
            navigate('/nova-senha', { replace: true });
            return;
          }
          
          // Só redirecionar para dashboard se NÃO for recovery
          console.log('✅ Valid session found (not recovery), redirecting to dashboard');
          navigate('/dashboard', { replace: true });
        }

        // Cleanup subscription após processamento
        setTimeout(() => {
          subscription.unsubscribe();
        }, 5000);

      } catch (error) {
        console.error('❌ Auth callback system error:', error);
        navigate('/auth', { replace: true });
      }
    };

    handleAuthCallback();
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
        <p className="text-muted-foreground">Processando autenticação...</p>
      </div>
    </div>
  );
};