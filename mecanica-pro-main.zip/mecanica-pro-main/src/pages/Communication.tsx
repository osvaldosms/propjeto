import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MessageSquare, 
  Send, 
  Phone,
  Mail,
  Bell,
  Users,
  Calendar,
  Clock,
  Check,
  Plus
} from 'lucide-react';

const Communication = () => {
  const [selectedChat, setSelectedChat] = useState<number | null>(1);
  const [newMessage, setNewMessage] = useState('');

  // Dados mockados para demonstração
  const conversations = [
    {
      id: 1,
      client: 'João Silva',
      lastMessage: 'Obrigado pelo excelente serviço!',
      time: '10:30',
      unread: 0,
      status: 'online',
      vehicle: 'Honda Civic - ABC-1234'
    },
    {
      id: 2,
      client: 'Maria Oliveira',
      lastMessage: 'Quando posso buscar meu carro?',
      time: '09:15',
      unread: 2,
      status: 'offline',
      vehicle: 'Toyota Corolla - XYZ-5678'
    },
    {
      id: 3,
      client: 'Roberto Costa',
      lastMessage: 'Preciso agendar uma revisão',
      time: 'Ontem',
      unread: 1,
      status: 'offline',
      vehicle: 'Volkswagen Gol - DEF-9012'
    }
  ];

  const messages = [
    {
      id: 1,
      sender: 'client',
      text: 'Olá! Gostaria de saber se meu carro ficou pronto.',
      time: '10:25'
    },
    {
      id: 2,
      sender: 'workshop',
      text: 'Olá João! Sim, seu Honda Civic está pronto. Fizemos a troca de óleo e a revisão completa.',
      time: '10:27'
    },
    {
      id: 3,
      sender: 'client',
      text: 'Perfeito! Qual foi o valor total?',
      time: '10:28'
    },
    {
      id: 4,
      sender: 'workshop',
      text: 'O valor total foi R$ 450,00. Pode vir buscar quando desejar.',
      time: '10:29'
    },
    {
      id: 5,
      sender: 'client',
      text: 'Obrigado pelo excelente serviço!',
      time: '10:30'
    }
  ];

  const notifications = [
    {
      id: 1,
      type: 'service_complete',
      title: 'Serviço Concluído',
      message: 'Honda Civic de João Silva está pronto para retirada',
      time: '2 min atrás',
      read: false
    },
    {
      id: 2,
      type: 'new_message',
      title: 'Nova Mensagem',
      message: 'Maria Oliveira enviou uma mensagem',
      time: '15 min atrás',
      read: false
    },
    {
      id: 3,
      type: 'appointment',
      title: 'Novo Agendamento',
      message: 'Roberto Costa agendou uma revisão para amanhã',
      time: '1 hora atrás',
      read: true
    }
  ];

  const templates = [
    {
      id: 1,
      name: 'Serviço Concluído',
      content: 'Olá {cliente}! Seu {veiculo} está pronto para retirada. O serviço foi concluído com sucesso.'
    },
    {
      id: 2,
      name: 'Lembrete de Agendamento',
      content: 'Olá {cliente}! Lembramos que você tem um agendamento amanhã às {horario} para seu {veiculo}.'
    },
    {
      id: 3,
      name: 'Orçamento Aprovado',
      content: 'Olá {cliente}! Seu orçamento foi aprovado. Iniciaremos o serviço em seu {veiculo} hoje.'
    }
  ];

  const sendMessage = () => {
    if (newMessage.trim()) {
      // Aqui seria enviada a mensagem
      console.log('Enviando mensagem:', newMessage);
      setNewMessage('');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Comunicação</h1>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Nova Conversa
        </Button>
      </div>

      <Tabs defaultValue="chat" className="space-y-4">
        <TabsList>
          <TabsTrigger value="chat">Chat</TabsTrigger>
          <TabsTrigger value="notifications">Notificações</TabsTrigger>
          <TabsTrigger value="templates">Modelos</TabsTrigger>
          <TabsTrigger value="bulk">Mensagem em Massa</TabsTrigger>
        </TabsList>
        
        <TabsContent value="chat" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
            {/* Lista de conversas */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Conversas
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  {conversations.map((conversation) => (
                    <div
                      key={conversation.id}
                      className={`p-4 cursor-pointer hover:bg-muted/50 ${
                        selectedChat === conversation.id ? 'bg-muted' : ''
                      }`}
                      onClick={() => setSelectedChat(conversation.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <h4 className="font-medium">{conversation.client}</h4>
                            <div className={`w-2 h-2 rounded-full ${
                              conversation.status === 'online' ? 'bg-green-500' : 'bg-gray-300'
                            }`} />
                          </div>
                          <p className="text-sm text-muted-foreground mb-1">
                            {conversation.vehicle}
                          </p>
                          <p className="text-sm text-muted-foreground line-clamp-1">
                            {conversation.lastMessage}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">{conversation.time}</p>
                          {conversation.unread > 0 && (
                            <Badge className="mt-1" variant="destructive">
                              {conversation.unread}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Área de chat */}
            <Card className="lg:col-span-2">
              {selectedChat ? (
                <>
                  <CardHeader className="border-b">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>
                          {conversations.find(c => c.id === selectedChat)?.client}
                        </CardTitle>
                        <p className="text-sm text-muted-foreground">
                          {conversations.find(c => c.id === selectedChat)?.vehicle}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Phone className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Mail className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="p-0">
                    <div className="h-96 overflow-y-auto p-4 space-y-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${
                            message.sender === 'workshop' ? 'justify-end' : 'justify-start'
                          }`}
                        >
                          <div
                            className={`max-w-xs p-3 rounded-lg ${
                              message.sender === 'workshop'
                                ? 'bg-primary text-primary-foreground'
                                : 'bg-muted'
                            }`}
                          >
                            <p className="text-sm">{message.text}</p>
                            <p className={`text-xs mt-1 ${
                              message.sender === 'workshop'
                                ? 'text-primary-foreground/70'
                                : 'text-muted-foreground'
                            }`}>
                              {message.time}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="border-t p-4">
                      <div className="flex space-x-2">
                        <Input
                          placeholder="Digite sua mensagem..."
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                        />
                        <Button onClick={sendMessage}>
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </>
              ) : (
                <CardContent className="flex items-center justify-center h-full">
                  <div className="text-center text-muted-foreground">
                    <MessageSquare className="w-12 h-12 mx-auto mb-4" />
                    <p>Selecione uma conversa para começar</p>
                  </div>
                </CardContent>
              )}
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="w-4 h-4 mr-2" />
                Notificações
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 border rounded-lg ${
                      !notification.read ? 'bg-muted/50' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium">{notification.title}</h4>
                          {!notification.read && (
                            <Badge variant="destructive" className="text-xs">
                              Novo
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          {notification.message}
                        </p>
                        <p className="text-xs text-muted-foreground mt-2">
                          {notification.time}
                        </p>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Check className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="templates" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Modelos de Mensagem</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {templates.map((template) => (
                  <div key={template.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{template.name}</h4>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          Editar
                        </Button>
                        <Button size="sm">
                          Usar
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {template.content}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="bulk" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-4 h-4 mr-2" />
                Mensagem em Massa
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Destinatários</label>
                <Input placeholder="Selecionar clientes..." className="mt-1" />
              </div>
              
              <div>
                <label className="text-sm font-medium">Mensagem</label>
                <Textarea 
                  placeholder="Digite sua mensagem..."
                  className="mt-1"
                  rows={4}
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button variant="outline">
                  Salvar como Modelo
                </Button>
                <Button>
                  <Send className="w-4 h-4 mr-2" />
                  Enviar para Todos
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Communication;