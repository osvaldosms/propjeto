import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { NovoClienteVeiculoModal } from '@/components/modals/NovoClienteVeiculoModal';
import { Cliente } from '@/types/workshop';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Search, Edit, Trash2, Phone, Mail, Loader } from 'lucide-react';

export const Customers: React.FC = () => {
  const { empresa } = useAuth();
  const { toast } = useToast();
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCliente, setEditingCliente] = useState<Cliente | null>(null);

  // Load clientes from Supabase
  useEffect(() => {
    loadClientes();
  }, [empresa]);

  // Removido: useEffect que executava busca automática no searchTerm
  // para evitar atualizações indesejadas durante minimização da tela

  const loadClientes = async () => {
    if (!empresa?.id) return;
    
    try {
      setLoading(true);
      let query = supabase
        .from('clientes')
        .select('*')
        .eq('empresa_id', empresa.id)
        .order('nome');

      const { data, error } = await query;

      if (error) throw error;
      setClientes(data || []);
    } catch (error) {
      console.error('Error loading clientes:', error);
      toast({
        title: "Erro ao carregar clientes",
        description: "Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredClientes = searchTerm 
    ? clientes.filter(cliente =>
        cliente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (cliente.telefone && cliente.telefone.includes(searchTerm)) ||
        (cliente.email && cliente.email.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    : clientes;

  const handleClienteVeiculoSuccess = (clienteId: string, veiculoId: string) => {
    loadClientes();
    toast({
      title: "Cliente e veículo criados!",
      description: "Cliente e veículo foram cadastrados com sucesso.",
    });
  };

  const handleEdit = (cliente: Cliente) => {
    setEditingCliente(cliente);
    setIsModalOpen(true);
  };

  const handleDelete = async (cliente: Cliente) => {
    if (!empresa?.id) return;
    
    const confirmed = window.confirm(`Tem certeza que deseja deletar o cliente ${cliente.nome}?`);
    if (confirmed) {
      try {
        const { error } = await supabase
          .from('clientes')
          .delete()
          .eq('id', cliente.id)
          .eq('empresa_id', empresa.id);

        if (error) throw error;

        // Update local state
        setClientes(prev => prev.filter(c => c.id !== cliente.id));
        
        toast({
          title: "Cliente deletado!",
          description: `${cliente.nome} foi removido.`,
        });
      } catch (error) {
        console.error('Error deleting cliente:', error);
        toast({
          title: "Erro ao deletar cliente",
          description: "Tente novamente.",
          variant: "destructive",
        });
      }
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingCliente(null);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader className="animate-spin h-8 w-8 mx-auto mb-4" />
          <p className="text-muted-foreground">Carregando clientes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Clientes</h1>
          <p className="text-muted-foreground">
            Gerencie os clientes da sua oficina
          </p>
        </div>
        <Button 
          onClick={() => setIsModalOpen(true)}
          size="sm"
          className="flex items-center gap-2 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-md hover:shadow-lg transition-all duration-200 hover:scale-[1.02] border-0 text-primary-foreground font-medium"
        >
          <Plus className="h-4 w-4" />
          Novo Cliente
        </Button>
      </div>

      {/* Busca */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center space-x-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome, telefone ou e-mail..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
          </div>
        </CardContent>
      </Card>

      {/* Lista de Clientes */}
      <div className="grid gap-4">
        {filteredClientes.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-muted-foreground">
                {searchTerm ? 'Nenhum cliente encontrado.' : 'Nenhum cliente cadastrado ainda.'}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredClientes.map((cliente) => (
            <Card key={cliente.id}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold">{cliente.nome}</h3>
                      {cliente.email && <Badge variant="secondary">{cliente.email}</Badge>}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-muted-foreground">
                      {cliente.telefone && (
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          {cliente.telefone}
                        </div>
                      )}
                      {cliente.email && (
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4" />
                          {cliente.email}
                        </div>
                      )}
                      {cliente.endereco && (
                        <div className="md:col-span-2">
                          {cliente.endereco}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(cliente)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(cliente)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Modal de Formulário Unificado */}
      {!editingCliente && (
        <NovoClienteVeiculoModal
          isOpen={isModalOpen}
          onClose={closeModal}
          onSuccess={handleClienteVeiculoSuccess}
        />
      )}
    </div>
  );
};