import React, { useState } from 'react';
import { MetricCard } from '@/components/dashboard/MetricCard';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { NovaOsModal } from '@/components/modals/NovaOsModal';
import {
  ClipboardList,
  DollarSign,
  Users,
  Car,
  AlertTriangle,
  Calendar,
  Plus,
  Eye,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { OrdemServico, Cliente, Veiculo } from '@/types/workshop';
import { TrialBanner } from '@/components/access/TrialBanner';
import { usePlanAccess } from '@/hooks/usePlanAccess';

// Dados simulados para demonstração
const mockData = {
  metrics: {
    monthlyRevenue: 'R$ 45.320',
    activeOrders: 23,
    totalCustomers: 156,
    vehiclesInService: 8,
  },
  recentOrders: [
    {
      id: 'OS-001',
      customer: 'João Silva',
      vehicle: 'Honda Civic 2020',
      service: 'Revisão completa',
      status: 'em_execucao',
      value: 'R$ 850,00',
      date: '2024-01-20',
    },
    {
      id: 'OS-002',
      customer: 'Maria Santos',
      vehicle: 'Toyota Corolla 2019',
      service: 'Troca de óleo',
      status: 'aguardando_aprovacao',
      value: 'R$ 120,00',
      date: '2024-01-20',
    },
    {
      id: 'OS-003',
      customer: 'Pedro Costa',
      vehicle: 'Ford Focus 2018',
      service: 'Alinhamento e balanceamento',
      status: 'finalizado',
      value: 'R$ 150,00',
      date: '2024-01-19',
    },
  ],
  todaySchedule: [
    {
      time: '09:00',
      customer: 'Ana Lima',
      vehicle: 'Volkswagen Gol',
      service: 'Revisão preventiva',
    },
    {
      time: '14:30',
      customer: 'Carlos Oliveira',
      vehicle: 'Chevrolet Onix',
      service: 'Diagnóstico eletrônico',
    },
    {
      time: '16:00',
      customer: 'Lucia Ferreira',
      vehicle: 'Hyundai HB20',
      service: 'Troca de pastilhas',
    },
  ],
  lowStock: [
    { item: 'Óleo 5W30', quantity: 2, minimum: 10 },
    { item: 'Filtro de ar', quantity: 5, minimum: 15 },
    { item: 'Pastilhas de freio', quantity: 3, minimum: 12 },
  ],
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'em_execucao':
      return 'bg-warning text-warning-foreground';
    case 'aguardando_aprovacao':
      return 'bg-muted text-muted-foreground';
    case 'finalizado':
      return 'bg-success text-success-foreground';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

const getStatusLabel = (status: string) => {
  switch (status) {
    case 'em_execucao':
      return 'Em Execução';
    case 'aguardando_aprovacao':
      return 'Aguardando Aprovação';
    case 'finalizado':
      return 'Finalizado';
    default:
      return 'Desconhecido';
  }
};

export const Dashboard: React.FC = () => {
  const { workshop } = useAuth();
  const [isNovaOsOpen, setIsNovaOsOpen] = useState(false);
  const [ordens] = useLocalStorage<OrdemServico[]>('ordens_servico', []);
  const [clientes] = useLocalStorage<Cliente[]>('clientes', []);
  const [veiculos] = useLocalStorage<Veiculo[]>('veiculos', []);
  const { planInfo, getPlanLimits } = usePlanAccess();
  
  const planLimits = getPlanLimits();

  // Calcular métricas reais dos dados
  const ordensAtivas = ordens.filter(o => !['finalizada', 'cancelado'].includes(o.status));
  const faturamentoMes = ordens
    .filter(o => o.status === 'finalizada')
    .reduce((sum, o) => sum + 0, 0);
  const veiculosNaOficina = ordens.filter(o => o.status === 'em_andamento').length;

  const getClienteNome = (clienteId: string) => {
    const cliente = clientes.find(c => c.id === clienteId);
    return cliente ? cliente.nome : 'Cliente não encontrado';
  };

  const getVeiculoInfo = (veiculoId: string) => {
    const veiculo = veiculos.find(v => v.id === veiculoId);
    return veiculo ? `${veiculo.marca} ${veiculo.modelo}` : 'Veículo não encontrado';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'em_andamento':
        return 'bg-warning text-warning-foreground';
      case 'aguardando_pecas':
        return 'bg-secondary text-secondary-foreground';
      case 'finalizada':
        return 'bg-success text-success-foreground';
      case 'aberta':
        return 'bg-muted text-muted-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'em_andamento':
        return 'Em Andamento';
      case 'aguardando_pecas':
        return 'Aguardando Peças';
      case 'finalizada':
        return 'Finalizada';
      case 'aberta':
        return 'Aberta';
      default:
        return 'Desconhecido';
    }
  };

  return (
    <div className="space-y-6">
      <TrialBanner />
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">
            Bem-vindo de volta! Aqui está o resumo da sua oficina hoje.
          </p>
        </div>
        <Button onClick={() => setIsNovaOsOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nova O.S.
        </Button>
      </div>

      {/* Métricas principais */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Faturamento do Mês"
          value={faturamentoMes > 0 ? `R$ ${faturamentoMes.toFixed(2)}` : 'R$ 0,00'}
          description="Janeiro 2024"
          icon={DollarSign}
          trend={faturamentoMes > 0 ? { value: 12.5, isPositive: true } : undefined}
        />
        <MetricCard
          title="O.S. Ativas"
          value={ordensAtivas.length}
          description="Em andamento"
          icon={ClipboardList}
        />
        <MetricCard
          title="Total de Clientes"
          value={clientes.length}
          description="Cadastrados"
          icon={Users}
          trend={clientes.length > 0 ? { value: 8.2, isPositive: true } : undefined}
        />
        <MetricCard
          title="Veículos em Serviço"
          value={veiculosNaOficina}
          description="Na oficina hoje"
          icon={Car}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* Ordens de Serviço Recentes */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Ordens de Serviço Recentes</CardTitle>
            <CardDescription>
              Últimas O.S. criadas e atualizadas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {ordens.slice(0, 5).map((ordem) => (
                <div key={ordem.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{ordem.id}</span>
                      <Badge variant="secondary" className={getStatusColor(ordem.status)}>
                        {getStatusLabel(ordem.status)}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {getClienteNome(ordem.cliente_id)} • {getVeiculoInfo(ordem.veiculo_id)}
                    </p>
                    <p className="text-sm">{ordem.descricao}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">
                      Sem valor
                    </p>
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              {ordens.length === 0 && (
                <div className="text-center text-muted-foreground py-8">
                  <p>Nenhuma ordem de serviço cadastrada ainda.</p>
                  <Button 
                    variant="link" 
                    onClick={() => setIsNovaOsOpen(true)}
                    className="mt-2"
                  >
                    Criar primeira O.S.
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Agenda de Hoje */}
        <Card>
          <CardHeader>
            <CardTitle>Agenda de Hoje</CardTitle>
            <CardDescription>
              Agendamentos para hoje
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockData.todaySchedule.map((appointment, index) => (
                <div key={index} className="flex gap-3 p-2 border rounded">
                  <div className="flex items-center justify-center w-12 h-12 rounded bg-primary/10">
                    <Calendar className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{appointment.time}</p>
                    <p className="text-sm">{appointment.customer}</p>
                    <p className="text-xs text-muted-foreground">
                      {appointment.vehicle} • {appointment.service}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Alertas de Estoque */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-warning" />
              Alertas de Estoque Baixo
            </CardTitle>
            <CardDescription>
              {planLimits.hasInventoryModule 
                ? "Produtos próximos ao estoque mínimo"
                : "Módulo de estoque disponível no plano Profissional ou superior"
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            {planLimits.hasInventoryModule ? (
              <div className="grid gap-3 md:grid-cols-3">
                {mockData.lowStock.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg bg-warning/5">
                    <div>
                      <p className="font-medium">{item.item}</p>
                      <p className="text-sm text-muted-foreground">
                        Estoque: {item.quantity} | Mínimo: {item.minimum}
                      </p>
                    </div>
                    <Badge variant="secondary" className="bg-warning text-warning-foreground">
                      Baixo
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <AlertTriangle className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <p>Controle de estoque não disponível no seu plano atual.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal Nova O.S. */}
      <NovaOsModal 
        isOpen={isNovaOsOpen} 
        onClose={() => setIsNovaOsOpen(false)} 
      />
    </div>
  );
};