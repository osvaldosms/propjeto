import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  CreditCard,
  Calendar,
  FileText,
  Plus,
  Upload,
  Download,
  Search,
  Filter
} from 'lucide-react';
import { NovaTransacaoModal } from '@/components/modals/NovaTransacaoModal';
import { supabase } from '@/integrations/supabase/client';
import { TransacaoFinanceira } from '@/types/financial';
import { useToast } from '@/hooks/use-toast';
import { PlanRestrictionBanner } from '@/components/access/PlanRestrictionBanner';
import { TrialBanner } from '@/components/access/TrialBanner';
import { usePlanAccess } from '@/hooks/usePlanAccess';

const Financial = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [transacaoModalOpen, setTransacaoModalOpen] = useState(false);
  const [transactions, setTransactions] = useState<TransacaoFinanceira[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'receita' | 'despesa'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'confirmada' | 'pendente'>('all');
  const { toast } = useToast();
  const { checkAccess, getPlanLimits } = usePlanAccess();

  // Verificar se tem acesso ao módulo financeiro
  const hasFinancialAccess = checkAccess('profissional');
  const planLimits = getPlanLimits();

  // Buscar transações do banco
  const fetchTransactions = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from('transacoes_financeiras')
        .select('*')
        .order('data', { ascending: false });

      if (filterType !== 'all') {
        query = query.eq('tipo', filterType);
      }

      // Remove status filter since column doesn't exist in current schema

      if (searchTerm) {
        query = query.or(`descricao.ilike.%${searchTerm}%,cliente.ilike.%${searchTerm}%`);
      }

      const { data, error } = await query;

      if (error) throw error;
      
      setTransactions((data || []).map((item: any) => ({
        ...item,
        metodo_pagamento: item.metodo_pagamento || 'dinheiro',
        status: item.status || 'pendente',
        created_at: item.created_at || new Date().toISOString(),
        updated_at: item.updated_at || new Date().toISOString()
      })) as TransacaoFinanceira[]);
    } catch (error) {
      console.error('Erro ao buscar transações:', error);
      toast({
        title: "Erro ao carregar transações",
        description: "Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, [filterType, filterStatus, searchTerm]);

  // Calcular resumo financeiro
  const financialData = {
    revenue: transactions
      .filter(t => t.tipo === 'receita' && t.status === 'confirmada')
      .reduce((sum, t) => sum + t.valor, 0),
    expenses: transactions
      .filter(t => t.tipo === 'despesa' && t.status === 'confirmada')
      .reduce((sum, t) => sum + t.valor, 0),
    pending: transactions
      .filter(t => t.status === 'pendente')
      .reduce((sum, t) => sum + (t.tipo === 'receita' ? t.valor : -t.valor), 0),
    get profit() { return this.revenue - this.expenses; }
  };

  const getTypeIcon = (type: string) => {
    return type === 'receita' ? 
      <TrendingUp className="w-4 h-4 text-green-500" /> : 
      <TrendingDown className="w-4 h-4 text-red-500" />;
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      'confirmada': <Badge variant="default">Confirmada</Badge>,
      'pendente': <Badge variant="secondary">Pendente</Badge>,
      'cancelada': <Badge variant="destructive">Cancelada</Badge>
    };
    return statusMap[status as keyof typeof statusMap] || <Badge variant="secondary">{status}</Badge>;
  };

  // Função para exportar relatório
  const handleExportReport = (type: string) => {
    toast({
      title: "Exportando relatório",
      description: `Gerando ${type}...`,
    });
    // Implementar lógica de exportação
  };

  // Função para importar transações
  const handleImportTransactions = () => {
    toast({
      title: "Importação em desenvolvimento",
      description: "Funcionalidade será adicionada em breve.",
    });
  };

  const getMethodIcon = (method: string) => {
    const icons = {
      'cartao': <CreditCard className="w-4 h-4" />,
      'pix': <DollarSign className="w-4 h-4" />,
      'dinheiro': <DollarSign className="w-4 h-4" />,
      'debito': <CreditCard className="w-4 h-4" />
    };
    return icons[method as keyof typeof icons] || <DollarSign className="w-4 h-4" />;
  };

  // Se não tem acesso, mostrar banner de restrição
  if (!hasFinancialAccess) {
    return (
      <div className="space-y-6">
        <TrialBanner />
        <PlanRestrictionBanner 
          requiredPlan="profissional"
          feature="Módulo Financeiro"
          description="Gerencie receitas, despesas, relatórios e análises financeiras da sua oficina."
        />
        <div>
          <h1 className="text-3xl font-bold">Financeiro</h1>
          <p className="text-muted-foreground">
            Controle completo das finanças da sua oficina
          </p>
        </div>
        <div className="text-center py-16 text-muted-foreground">
          <DollarSign className="mx-auto h-16 w-16 mb-4 opacity-50" />
          <h3 className="text-lg font-medium mb-2">Módulo Financeiro Restrito</h3>
          <p>Este módulo está disponível apenas no plano Profissional ou superior.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <TrialBanner />
      
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Financeiro</h1>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            onClick={handleImportTransactions}
            disabled={!planLimits.hasExportFunction}
          >
            <Upload className="w-4 h-4 mr-2" />
            Importar
          </Button>
          <Button 
            variant="outline"
            disabled={!planLimits.hasReportsModule}
          >
            <FileText className="w-4 h-4 mr-2" />
            Relatório
          </Button>
          <Button onClick={() => setTransacaoModalOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Nova Transação
          </Button>
        </div>
      </div>

      {/* Cards de resumo */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
              }).format(financialData.revenue)}
            </div>
            <p className="text-xs text-muted-foreground">
              +12% em relação ao mês anterior
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despesas</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
              }).format(financialData.expenses)}
            </div>
            <p className="text-xs text-muted-foreground">
              -3% em relação ao mês anterior
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Lucro Líquido</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
              }).format(financialData.profit)}
            </div>
            <p className="text-xs text-muted-foreground">
              +18% em relação ao mês anterior
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">A Receber</CardTitle>
            <Calendar className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
              }).format(financialData.pending)}
            </div>
            <p className="text-xs text-muted-foreground">
              3 transações pendentes
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs para diferentes visões */}
      <Tabs defaultValue="transactions" className="space-y-4">
        <TabsList>
          <TabsTrigger value="transactions">Transações</TabsTrigger>
          <TabsTrigger value="reports">Relatórios</TabsTrigger>
          <TabsTrigger value="categories">Categorias</TabsTrigger>
        </TabsList>
        
        <TabsContent value="transactions" className="space-y-4">
          {/* Filtros */}
          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>Buscar</Label>
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar transações..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Tipo</Label>
                  <Select value={filterType} onValueChange={(value: any) => setFilterType(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="receita">Receitas</SelectItem>
                      <SelectItem value="despesa">Despesas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select value={filterStatus} onValueChange={(value: any) => setFilterStatus(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="confirmada">Confirmadas</SelectItem>
                      <SelectItem value="pendente">Pendentes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Ações</Label>
                  <Button variant="outline" className="w-full" onClick={fetchTransactions}>
                    <Filter className="w-4 h-4 mr-2" />
                    Atualizar
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Transações</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">Carregando...</div>
              ) : transactions.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Nenhuma transação encontrada
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Método</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Valor</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          {new Date(transaction.data).toLocaleDateString('pt-BR')}
                        </TableCell>
                        <TableCell className="font-medium">
                          {transaction.descricao}
                          {transaction.cliente && (
                            <div className="text-sm text-muted-foreground">
                              Cliente: {transaction.cliente}
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getTypeIcon(transaction.tipo)}
                            <span className="capitalize">{transaction.tipo}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getMethodIcon(transaction.metodo_pagamento)}
                            <span className="capitalize">{transaction.metodo_pagamento}</span>
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                        <TableCell className={`text-right font-medium ${
                          transaction.tipo === 'receita' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {new Intl.NumberFormat('pt-BR', {
                            style: 'currency',
                            currency: 'BRL'
                          }).format(transaction.valor)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Relatórios Financeiros</CardTitle>
            </CardHeader>
            <CardContent className="text-center py-8">
              <p className="text-muted-foreground mb-4">
                Gere relatórios detalhados sobre o desempenho financeiro da sua oficina
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button 
                  variant="outline" 
                  className="h-24 flex-col space-y-2"
                  onClick={() => handleExportReport('Relatório Mensal')}
                >
                  <FileText className="w-6 h-6" />
                  <span>Relatório Mensal</span>
                </Button>
                <Button 
                  variant="outline" 
                  className="h-24 flex-col space-y-2"
                  onClick={() => handleExportReport('Análise de Lucro')}
                >
                  <TrendingUp className="w-6 h-6" />
                  <span>Análise de Lucro</span>
                </Button>
                <Button 
                  variant="outline" 
                  className="h-24 flex-col space-y-2"
                  onClick={() => handleExportReport('Fluxo de Caixa')}
                >
                  <Calendar className="w-6 h-6" />
                  <span>Fluxo de Caixa</span>
                </Button>
              </div>
              
              <div className="mt-6 flex justify-center">
                <Button onClick={handleImportTransactions}>
                  <Upload className="w-4 h-4 mr-2" />
                  Importar Transações (OFX/CSV/Excel)
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="categories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Categorias de Receitas e Despesas</CardTitle>
            </CardHeader>
            <CardContent className="text-center py-8">
              <p className="text-muted-foreground">
                Gerencie as categorias para melhor organização das suas finanças
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <NovaTransacaoModal 
        isOpen={transacaoModalOpen}
        onClose={() => setTransacaoModalOpen(false)}
        onSuccess={fetchTransactions}
      />
    </div>
  );
};

export default Financial;