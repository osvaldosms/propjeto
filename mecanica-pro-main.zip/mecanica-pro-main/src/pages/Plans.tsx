import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Check, Crown, Star, Zap, ArrowRight, Loader } from 'lucide-react';

interface SubscriptionData {
  subscribed: boolean;
  subscription_tier?: string;
  subscription_end?: string;
}

export default function Plans() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [subscriptionLoading, setSubscriptionLoading] = useState(true);
  const [subscription, setSubscription] = useState<SubscriptionData>({ subscribed: false });
  const [paymentPeriod, setPaymentPeriod] = useState<'monthly' | 'semiannual' | 'annual'>('annual');

  const plans = [
    {
      id: 'essencial',
      name: 'Essencial',
      icon: <Star className="h-8 w-8" />,
      description: 'Ideal para oficinas que estão começando',
      pricing: {
        monthly: { price: 59, originalPrice: 59, perMonth: 59, savings: 0 },
        semiannual: { price: 299, originalPrice: 354, perMonth: 49.80, savings: 55 },
        annual: { price: 529, originalPrice: 708, perMonth: 44.10, savings: 179 }
      },
      features: [
        'Até 100 clientes',
        'Até 50 veículos por mês',
        'Ordens de serviço básicas',
        'Relatórios essenciais',
        'Controle de agendamento',
        'Gestão básica de estoque',
        'Suporte por email'
      ],
      color: 'blue',
      popular: false
    },
    {
      id: 'profissional',
      name: 'Profissional',
      icon: <Crown className="h-8 w-8" />,
      description: 'A melhor opção para oficinas em crescimento',
      pricing: {
        monthly: { price: 99, originalPrice: 99, perMonth: 99, savings: 0 },
        semiannual: { price: 499, originalPrice: 594, perMonth: 83.20, savings: 95 },
        annual: { price: 899, originalPrice: 1188, perMonth: 74.90, savings: 289 }
      },
      features: [
        'Todos os itens do plano ESSENCIAL +',
        'Clientes ilimitados',
        'Veículos ilimitados',
        'Gestão completa de OS',
        'Relatórios avançados e BI',
        'Controle financeiro completo',
        'Gestão avançada de estoque',
        'Assinaturas digitais',
        'Suporte prioritário'
      ],
      color: 'purple',
      popular: true
    },
    {
      id: 'premium',
      name: 'Premium',
      icon: <Zap className="h-8 w-8" />,
      description: 'Para oficinas que querem o máximo de performance',
      pricing: {
        monthly: { price: 169, originalPrice: 169, perMonth: 169, savings: 0 },
        semiannual: { price: 859, originalPrice: 1014, perMonth: 143.20, savings: 155 },
        annual: { price: 1499, originalPrice: 2028, perMonth: 124.90, savings: 529 }
      },
      features: [
        'Todos os itens do plano PROFISSIONAL +',
        'Multi-filiais ilimitadas',
        'API completa para integrações',
        'Automações avançadas',
        'Dashboard personalizado',
        'WhatsApp Business integrado',
        'Backup automático na nuvem',
        'Suporte 24/7 prioritário',
        'Consultor dedicado'
      ],
      color: 'emerald',
      popular: false
    }
  ];

  useEffect(() => {
    if (user) {
      checkSubscription();
    } else {
      setSubscriptionLoading(false);
    }
  }, [user]);

  const checkSubscription = async () => {
    try {
      setSubscriptionLoading(true);
      const { data, error } = await supabase.functions.invoke('check-subscription');
      
      if (error) throw error;
      
      setSubscription(data);
    } catch (error) {
      console.error('Error checking subscription:', error);
    } finally {
      setSubscriptionLoading(false);
    }
  };

  const handleSubscribe = async (planId: string, price: number) => {
    if (!user) {
      toast({
        title: "Faça login",
        description: "Você precisa estar logado para assinar um plano.",
        variant: "destructive",
      });
      return;
    }

    try {
      setLoading(true);
      
      const { data, error } = await supabase.functions.invoke('create-checkout', {
        body: {
          planId,
          price: price * 100, // Convert to cents
          period: paymentPeriod
        }
      });

      if (error) throw error;

      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (error) {
      console.error('Error creating checkout:', error);
      toast({
        title: "Erro",
        description: "Erro ao processar pagamento. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleManageSubscription = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase.functions.invoke('customer-portal');
      
      if (error) throw error;

      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (error) {
      console.error('Error opening customer portal:', error);
      toast({
        title: "Erro",
        description: "Erro ao abrir portal do cliente. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getIconColor = (color: string) => {
    switch (color) {
      case 'blue': return 'text-blue-600';
      case 'purple': return 'text-purple-600';
      case 'emerald': return 'text-emerald-600';
      default: return 'text-primary';
    }
  };

  const getIconBg = (color: string) => {
    switch (color) {
      case 'blue': return 'bg-blue-100';
      case 'purple': return 'bg-purple-100';
      case 'emerald': return 'bg-emerald-100';
      default: return 'bg-primary/10';
    }
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  };

  if (subscriptionLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader className="animate-spin h-8 w-8 mx-auto mb-4" />
          <p className="text-muted-foreground">Carregando planos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-12">
      {/* Header */}
      <div className="text-center space-y-6">
        <h1 className="text-5xl font-bold tracking-tight">Escolha seu Plano</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Transforme sua oficina com nossa plataforma completa de gestão. 
          Comece hoje mesmo e veja a diferença!
        </p>
        
        {subscription.subscribed && (
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-6 max-w-md mx-auto">
            <h3 className="font-semibold text-primary text-lg">Plano Ativo</h3>
            <p className="text-muted-foreground">
              {subscription.subscription_tier} • 
              {subscription.subscription_end && 
                ` Válido até ${new Date(subscription.subscription_end).toLocaleDateString('pt-BR')}`
              }
            </p>
            <Button 
              variant="outline" 
              onClick={handleManageSubscription}
              disabled={loading}
              className="mt-3"
            >
              {loading ? <Loader className="animate-spin h-4 w-4 mr-2" /> : null}
              Gerenciar Assinatura
            </Button>
          </div>
        )}
      </div>

      {/* Payment Period Selector */}
      <div className="flex justify-center">
        <Tabs 
          value={paymentPeriod} 
          onValueChange={(value) => setPaymentPeriod(value as typeof paymentPeriod)}
          className="w-auto"
        >
          <TabsList className="grid w-full grid-cols-3 bg-muted p-1 h-auto">
            <TabsTrigger value="monthly" className="relative">
              Mensal
            </TabsTrigger>
            <TabsTrigger value="semiannual" className="relative">
              Semestral
              <Badge variant="secondary" className="absolute -top-2 -right-2 text-xs bg-green-500 text-white">
                15% OFF
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="annual" className="relative">
              Anual
              <Badge variant="secondary" className="absolute -top-2 -right-2 text-xs bg-green-600 text-white">
                25% OFF
              </Badge>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Plans Grid */}
      <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
        {plans.map((plan, index) => {
          const currentPricing = plan.pricing[paymentPeriod];
          const isCurrentPlan = subscription.subscribed && 
            subscription.subscription_tier?.toLowerCase().includes(plan.id.toLowerCase());
          
          return (
            <Card 
              key={plan.id} 
              className={`relative transition-all duration-300 hover:shadow-lg ${
                plan.popular 
                  ? 'border-2 border-primary shadow-xl scale-105 bg-gradient-to-b from-primary/5 to-transparent' 
                  : 'border border-border hover:border-primary/50'
              } ${index === 1 ? 'lg:scale-105' : ''}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                  <Badge className="bg-primary text-primary-foreground px-4 py-1 text-sm font-semibold">
                    A MELHOR OPÇÃO
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center space-y-6 pb-8">
                <div className={`mx-auto p-4 rounded-full ${getIconBg(plan.color)} ${getIconColor(plan.color)}`}>
                  {plan.icon}
                </div>
                
                <div className="space-y-2">
                  <CardTitle className="text-3xl font-bold">{plan.name}</CardTitle>
                  <p className="text-muted-foreground text-lg">{plan.description}</p>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-baseline justify-center gap-2">
                    <span className="text-sm text-muted-foreground">R$</span>
                    <span className="text-5xl font-bold tracking-tight">
                      {formatPrice(currentPricing.price)}
                    </span>
                    <span className="text-muted-foreground text-lg">
                      /{paymentPeriod === 'monthly' ? 'mês' : paymentPeriod === 'semiannual' ? '6 meses' : 'ano'}
                    </span>
                  </div>
                  
                  {paymentPeriod !== 'monthly' && (
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">
                        R$ {currentPricing.perMonth.toFixed(2).replace('.', ',')}/mês
                      </p>
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                        <p className="text-green-700 font-semibold text-sm">
                          Você economiza R$ {currentPricing.savings}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-8 pt-0">
                <ul className="space-y-4">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-sm leading-relaxed">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className={`w-full py-6 text-lg font-semibold ${
                    plan.popular 
                      ? 'bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg' 
                      : ''
                  }`}
                  variant={plan.popular ? 'default' : 'outline'}
                  size="lg"
                  onClick={() => handleSubscribe(plan.id, currentPricing.price)}
                  disabled={loading || isCurrentPlan}
                >
                  {loading ? (
                    <Loader className="animate-spin h-5 w-5 mr-2" />
                  ) : isCurrentPlan ? (
                    'Plano Atual'
                  ) : (
                    <>
                      Começar agora
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Features Comparison */}
      <div className="max-w-6xl mx-auto space-y-8 pt-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold">Recursos completos para sua oficina</h2>
          <p className="text-lg text-muted-foreground">
            Descubra tudo o que nossa plataforma oferece para otimizar sua gestão
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-primary">Gestão Completa</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Cadastro de clientes e veículos
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Ordens de serviço digitais
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Controle de agendamento
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Gestão de estoque
              </li>
            </ul>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-primary">Relatórios e Análises</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Relatórios financeiros
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Análise de desempenho
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Histórico de serviços
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Métricas de produtividade
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-primary">Comunicação</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                WhatsApp integrado
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Notificações automáticas
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Portal do cliente
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                Assinaturas digitais
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="text-center space-y-6 pt-12">
        <h2 className="text-3xl font-bold">Pronto para começar?</h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Junte-se a centenas de oficinas que já transformaram sua gestão com nossa plataforma.
          Teste grátis por 7 dias!
        </p>
        <Button size="lg" className="px-8 py-6 text-lg">
          Começar teste grátis
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}