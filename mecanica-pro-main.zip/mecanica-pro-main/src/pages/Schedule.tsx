import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Plus, User, Car, Edit, X, Play } from 'lucide-react';
import { NovoAgendamentoModal } from '@/components/modals/NovoAgendamentoModal';
import { supabase } from '@/integrations/supabase/client';
import { Agendamento } from '@/types/workshop';
import { useToast } from '@/hooks/use-toast';

const Schedule = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [agendamentoModalOpen, setAgendamentoModalOpen] = useState(false);
  const [appointments, setAppointments] = useState<Agendamento[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Buscar agendamentos do banco
  const fetchAppointments = async () => {
    try {
      setLoading(true);
      const dateStr = selectedDate.toISOString().split('T')[0];
      
      const { data, error } = await supabase
        .from('agendamentos')
        .select('*')
        .eq('data_agendada', dateStr)
        .order('data_agendada');

      if (error) throw error;
      
      setAppointments((data || []).map((item: any) => ({
        ...item,
        cliente_nome: '',
        cliente_telefone: '',
        veiculo_descricao: '',
        servico_nome: '',
        servico_id: '',
        tecnico_nome: ''
      })) as Agendamento[]);
    } catch (error) {
      console.error('Erro ao buscar agendamentos:', error);
      toast({
        title: "Erro ao carregar agendamentos",
        description: "Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [selectedDate]);

  // Atualizar status do agendamento
  const updateAppointmentStatus = async (id: string, status: string) => {
    try {
      const { error } = await supabase
        .from('agendamentos')
        .update({ status })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Status atualizado!",
        description: `Agendamento ${status === 'cancelado' ? 'cancelado' : 'atualizado'} com sucesso.`,
      });

      fetchAppointments();
    } catch (error) {
      console.error('Erro ao atualizar agendamento:', error);
      toast({
        title: "Erro ao atualizar agendamento",
        description: "Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      'agendado': { label: 'Agendado', variant: 'secondary' as const },
      'confirmado': { label: 'Confirmado', variant: 'default' as const },
      'em_andamento': { label: 'Em Andamento', variant: 'destructive' as const },
      'concluido': { label: 'Concluído', variant: 'outline' as const },
      'cancelado': { label: 'Cancelado', variant: 'destructive' as const }
    };
    
    return statusConfig[status as keyof typeof statusConfig] || statusConfig.agendado;
  };

  const timeSlots = Array.from({ length: 10 }, (_, i) => {
    const hour = 8 + i;
    return `${hour.toString().padStart(2, '0')}:00`;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Agenda</h1>
        <Button onClick={() => setAgendamentoModalOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Novo Agendamento
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Calendário lateral */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="w-4 h-4 mr-2" />
              Calendário
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {selectedDate.getDate()}
                </div>
                <div className="text-sm text-muted-foreground">
                  {selectedDate.toLocaleDateString('pt-BR', { 
                    weekday: 'long',
                    month: 'long',
                    year: 'numeric'
                  })}
                </div>
              </div>
              
              {/* Mini calendário simples */}
              <div className="grid grid-cols-7 gap-1 text-center text-sm">
                {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((day, i) => (
                  <div key={i} className="p-2 font-medium text-muted-foreground">
                    {day}
                  </div>
                ))}
                {Array.from({ length: 31 }, (_, i) => (
                  <Button
                    key={i}
                    variant={i + 1 === selectedDate.getDate() ? "default" : "ghost"}
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setSelectedDate(new Date(2024, 0, i + 1))}
                  >
                    {i + 1}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Agenda do dia */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Agenda do Dia - {selectedDate.toLocaleDateString('pt-BR')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">Carregando agendamentos...</div>
            ) : (
              <div className="space-y-4">
                {timeSlots.map((timeSlot) => {
                  const appointment = appointments.find(apt => apt.data_agendada?.includes(timeSlot));
                  
                  return (
                    <div key={timeSlot} className="flex items-start space-x-4 p-4 border rounded-lg">
                      <div className="w-16 text-sm font-medium text-muted-foreground">
                        {timeSlot}
                      </div>
                      
                      {appointment ? (
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <User className="w-4 h-4 text-muted-foreground" />
                              <span className="font-medium">Cliente #{appointment.cliente_id?.substring(0, 8)}</span>
                            </div>
                            <Badge variant={getStatusBadge(appointment.status).variant}>
                              {getStatusBadge(appointment.status).label}
                            </Badge>
                          </div>
                          
                          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                            <Car className="w-4 h-4" />
                            <span>Veículo #{appointment.veiculo_id?.substring(0, 8)}</span>
                          </div>
                          
                          <div className="text-sm">
                            <strong>Observações:</strong> {appointment.observacoes || 'Sem observações'}
                          </div>
                          
                          <div className="text-sm">
                            <strong>Status:</strong> {appointment.status || 'Agendado'}
                          </div>
                          
                          
                          <div className="flex space-x-2 pt-2">
                            <Button size="sm" variant="outline">
                              <Edit className="w-4 h-4 mr-1" />
                              Editar
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => updateAppointmentStatus(appointment.id, 'cancelado')}
                            >
                              <X className="w-4 h-4 mr-1" />
                              Cancelar
                            </Button>
                            {(appointment.status === 'agendado' || appointment.status === 'confirmado') && (
                              <Button 
                                size="sm"
                                onClick={() => updateAppointmentStatus(appointment.id, 'em_andamento')}
                              >
                                <Play className="w-4 h-4 mr-1" />
                                Iniciar Serviço
                              </Button>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className="flex-1 flex items-center justify-center py-8 text-muted-foreground">
                          <Button 
                            variant="ghost" 
                            className="h-auto flex-col space-y-2"
                            onClick={() => setAgendamentoModalOpen(true)}
                          >
                            <Plus className="w-6 h-6" />
                            <span>Disponível</span>
                          </Button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Estatísticas do dia */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Agendamentos Hoje</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{appointments.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Em Andamento</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {appointments.filter(apt => apt.status === 'em_andamento').length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {appointments.filter(apt => apt.status === 'agendado').length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa Ocupação</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round((appointments.length / timeSlots.length) * 100)}%
            </div>
          </CardContent>
        </Card>
      </div>
      
      <NovoAgendamentoModal 
        isOpen={agendamentoModalOpen}
        onClose={() => setAgendamentoModalOpen(false)}
        onSuccess={fetchAppointments}
      />
    </div>
  );
};

export default Schedule;