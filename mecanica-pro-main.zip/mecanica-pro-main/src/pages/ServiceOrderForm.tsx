import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { OrdemServicoFormCompleta } from '@/components/forms/OrdemServicoFormCompleta';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useOrdemServicoCreation } from '@/hooks/useOrdemServicoCreation';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { OrdemServicoCompleta, StatusOS } from '@/types/ordem-servico';

export const ServiceOrderForm: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { empresa } = useAuth();
  const { toast } = useToast();
  const { createOrdemServico } = useOrdemServicoCreation();
  
  const [ordemExistente, setOrdemExistente] = useState<(OrdemServicoCompleta & { servicos?: any[], pecas?: any[] }) | null>(null);
  const [loading, setLoading] = useState(!!id);

  useEffect(() => {
    if (id && empresa?.id) {
      loadOrdemExistente();
    }
  }, [id, empresa?.id]);

  const loadOrdemExistente = async () => {
    if (!id || !empresa?.id) return;
    
    setLoading(true);
    try {
      // Carregar ordem de serviço
      const { data: ordem, error: ordemError } = await supabase
        .from('ordens_servico')
        .select('*')
        .eq('id', id)
        .eq('empresa_id', empresa.id)
        .single();

      if (ordemError) throw ordemError;

      // Carregar serviços da OS
      const { data: servicos, error: servicosError } = await supabase
        .from('servicos_os')
        .select('*')
        .eq('ordem_servico_id', id);

      if (servicosError) throw servicosError;

      // Carregar peças da OS
      const { data: pecas, error: pecasError } = await supabase
        .from('pecas_os')
        .select('*')
        .eq('ordem_servico_id', id);

      if (pecasError) throw pecasError;

      // Mapear para OrdemServicoCompleta
      const ordemCompleta: OrdemServicoCompleta & { servicos?: any[], pecas?: any[] } = {
        id: ordem.id,
        numero_os: ordem.numero_os || parseInt(ordem.id.slice(-6), 16),
        empresa_id: ordem.empresa_id,
        cliente_id: ordem.cliente_id,
        veiculo_id: ordem.veiculo_id,
        tecnico_id: ordem.tecnico_id,
        data_pedido: ordem.data_abertura,
        data_inicio: ordem.data_abertura,
        data_fim: ordem.data_entrega,
        status: (ordem.status || 'aguardando_aprovacao') as StatusOS,
        defeitos_reclamacoes: ordem.defeitos_reclamacoes || ordem.defeito_relatado,
        descricao: ordem.descricao,
        total_servicos: ordem.total_servicos || 0,
        total_pecas: ordem.total_pecas || 0,
        desconto_valor: ordem.desconto_valor || 0,
        desconto_percentual: ordem.desconto_percentual || 0,
        taxa_entrega: ordem.taxa_entrega || 0,
        outras_taxas: ordem.outras_taxas || 0,
        total_geral: ordem.total_geral || 0,
        compromisso_retorno: ordem.data_entrega,
        notificacao_automatica: ordem.notificacao_automatica || false,
        condicoes_pagamento: ordem.condicoes_pagamento,
        meios_pagamento: [],
        garantia: ordem.garantia,
        clausulas_contratuais: ordem.clausulas_contratuais,
        informacoes_adicionais: ordem.informacoes_adicionais,
        relatorio_tecnico: ordem.relatorio_tecnico,
        checklist_entrada: [],
        checklist_saida: [],
        historico_alteracoes: [],
        created_at: ordem.data_abertura,
        servicos: servicos || [],
        pecas: pecas || []
      };

      setOrdemExistente(ordemCompleta);
    } catch (error) {
      console.error('Erro ao carregar ordem existente:', error);
      toast({
        title: "Erro ao carregar ordem",
        description: "Não foi possível carregar os dados da ordem de serviço.",
        variant: "destructive",
      });
      navigate('/service-orders');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (data: any) => {
    try {
      if (id) {
        // Atualizar ordem existente
        await updateOrdemServico(data);
      } else {
        // Criar nova ordem
        await createOrdemServico(data);
      }
      navigate('/service-orders');
    } catch (error) {
      // Erro já tratado no hook/função
    }
  };

  const updateOrdemServico = async (data: any) => {
    if (!id || !empresa?.id) return;

    try {
      // Atualizar ordem principal
      const { error: ordemError } = await supabase
        .from('ordens_servico')
        .update({
          cliente_id: data.cliente_id,
          veiculo_id: data.veiculo_id,
          tecnico_id: data.tecnico_id,
          status: data.status,
          data_entrega: data.data_entrega,
          defeitos_reclamacoes: data.defeitos_reclamacoes,
          descricao: data.descricao,
          relatorio_tecnico: data.relatorio_tecnico,
          total_servicos: data.total_servicos,
          total_pecas: data.total_pecas,
          desconto_valor: data.desconto_valor,
          desconto_percentual: data.desconto_percentual,
          taxa_entrega: data.taxa_entrega,
          outras_taxas: data.outras_taxas,
          total_geral: data.total_geral,
          garantia: data.garantia,
          clausulas_contratuais: data.clausulas_contratuais,
          condicoes_pagamento: data.condicoes_pagamento,
          informacoes_adicionais: data.informacoes_adicionais,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .eq('empresa_id', empresa.id);

      if (ordemError) throw ordemError;

      // Deletar serviços existentes e recriar
      await supabase
        .from('servicos_os')
        .delete()
        .eq('ordem_servico_id', id);

      if (data.servicos && data.servicos.length > 0) {
        const { error: servicosError } = await supabase
          .from('servicos_os')
          .insert(data.servicos.map((servico: any) => ({
            ordem_servico_id: id,
            descricao: servico.descricao,
            valor: servico.valor,
            quantidade: servico.quantidade,
            subtotal: servico.subtotal
          })));

        if (servicosError) throw servicosError;
      }

      // Deletar peças existentes e recriar
      await supabase
        .from('pecas_os')
        .delete()
        .eq('ordem_servico_id', id);

      if (data.pecas && data.pecas.length > 0) {
        const { error: pecasError } = await supabase
          .from('pecas_os')
          .insert(data.pecas.map((peca: any) => ({
            ordem_servico_id: id,
            descricao: peca.descricao,
            valor: peca.valor,
            quantidade: peca.quantidade,
            observacao: peca.observacao,
            subtotal: peca.subtotal
          })));

        if (pecasError) throw pecasError;
      }

      toast({
        title: "Ordem atualizada",
        description: "Ordem de serviço atualizada com sucesso.",
      });
    } catch (error) {
      console.error('Erro ao atualizar ordem:', error);
      toast({
        title: "Erro ao atualizar",
        description: "Não foi possível atualizar a ordem de serviço.",
        variant: "destructive",
      });
      throw error;
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">Carregando ordem de serviço...</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{id ? 'Editar Ordem de Serviço' : 'Nova Ordem de Serviço'}</CardTitle>
        </CardHeader>
        <CardContent>
          <OrdemServicoFormCompleta 
            ordemExistente={ordemExistente}
            onSubmit={handleSubmit} 
            onCancel={() => navigate(-1)} 
          />
        </CardContent>
      </Card>
    </div>
  );
};
