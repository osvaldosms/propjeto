import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Search, Edit, Trash2, Eye, Clock, FileText, Download, Send } from 'lucide-react';
import { 
  OrdemServicoCompleta, 
  StatusOS, 
  StatusOSLabels, 
  StatusOSColors 
} from '@/types/ordem-servico';
import { Cliente, Veiculo } from '@/types/workshop';
import { OSVisualization } from '@/components/forms/OSVisualization';

export const ServiceOrders: React.FC = () => {
  const navigate = useNavigate();
  const { empresa } = useAuth();
  const { toast } = useToast();
  
  // Estados principais
  const [ordens, setOrdens] = useState<OrdemServicoCompleta[]>([]);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Estados de filtros
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  
  // Estados de modais
  const [viewingOrdem, setViewingOrdem] = useState<OrdemServicoCompleta | null>(null);

  // Carregar dados iniciais
  useEffect(() => {
    if (empresa?.id) {
      loadData();
    } else if (!empresa) {
      setLoading(false); // Se não há empresa, pare o loading
    }
  }, [empresa]);

  const loadData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadOrdens(),
        loadClientes()
        // Removido loadVeiculos() - veículos serão carregados apenas quando necessário por cliente
      ]);
    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        title: "Erro ao carregar dados",
        description: "Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const loadOrdens = async () => {
    if (!empresa?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('ordens_servico')
        .select('*')
        .eq('empresa_id', empresa.id)
        .order('data_abertura', { ascending: false });

      if (error) throw error;
      // Mapear dados do banco para o tipo OrdemServicoCompleta
      const ordensCompletas = (data || []).map((ordem: any) => ({
        id: ordem.id,
        numero_os: ordem.numero_os || parseInt(ordem.id.slice(-6), 16),
        empresa_id: ordem.empresa_id,
        cliente_id: ordem.cliente_id,
        veiculo_id: ordem.veiculo_id,
        tecnico_id: ordem.tecnico_id,
        data_pedido: ordem.data_abertura,
        data_inicio: ordem.data_abertura,
        data_fim: ordem.data_entrega,
        status: (ordem.status || 'aguardando_aprovacao') as StatusOS,
        defeitos_reclamacoes: ordem.defeitos_reclamacoes || ordem.defeito_relatado,
        descricao: ordem.descricao,
        total_servicos: ordem.total_servicos || 0,
        total_pecas: ordem.total_pecas || 0,
        desconto_valor: ordem.desconto_valor || 0,
        desconto_percentual: ordem.desconto_percentual || 0,
        taxa_entrega: ordem.taxa_entrega || 0,
        outras_taxas: ordem.outras_taxas || 0,
        total_geral: ordem.total_geral || 0,
        compromisso_retorno: ordem.data_entrega,
        notificacao_automatica: false,
        condicoes_pagamento: '',
        meios_pagamento: [],
        garantia: ordem.garantia || '',
        clausulas_contratuais: ordem.clausulas_contratuais || '',
        informacoes_adicionais: '',
        relatorio_tecnico: ordem.relatorio_tecnico || '',
        checklist_entrada: [],
        checklist_saida: [],
        historico_alteracoes: [],
        created_at: ordem.data_abertura,
      } as OrdemServicoCompleta));
      
      setOrdens(ordensCompletas);
    } catch (error) {
      console.error('Error loading orders:', error);
      throw error;
    }
  };

  const loadClientes = async () => {
    if (!empresa?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .eq('empresa_id', empresa.id)
        .order('nome');

      if (error) throw error;
      setClientes(data || []);
    } catch (error) {
      console.error('Error loading clients:', error);
      throw error;
    }
  };

  // Função removida - veículos não devem ser carregados globalmente
  // Esta função causava vazamento de dados permitindo ver veículos de outros clientes

  // Filtrar ordens
  const filteredOrdens = ordens.filter(ordem => {
    const cliente = clientes.find(c => c.id === ordem.cliente_id);
    const veiculo = veiculos.find(v => v.id === ordem.veiculo_id);
    
    const matchesSearch = (
      ordem.numero_os?.toString().includes(searchTerm) ||
      ordem.defeitos_reclamacoes?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ordem.descricao?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (cliente && cliente.nome.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (veiculo && `${veiculo.marca} ${veiculo.modelo}`.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    
    const matchesStatus = statusFilter === 'todos' || ordem.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const handleEdit = (ordem: OrdemServicoCompleta) => {
    navigate(`/service-order-form/${ordem.id}`);
  };

  const handleView = async (ordem: OrdemServicoCompleta) => {
    try {
      // Carregar detalhes completos da ordem incluindo serviços e peças
      const { data: ordemDetalhes, error: ordemError } = await supabase
        .from('ordens_servico')
        .select('*')
        .eq('id', ordem.id)
        .single();

      if (ordemError) throw ordemError;

      // Carregar serviços
      const { data: servicos, error: servicosError } = await supabase
        .from('servicos_os')
        .select('*')
        .eq('ordem_servico_id', ordem.id);

      if (servicosError) throw servicosError;

      // Carregar peças
      const { data: pecas, error: pecasError } = await supabase
        .from('pecas_os')
        .select('*')
        .eq('ordem_servico_id', ordem.id);

      if (pecasError) throw pecasError;

      // Carregar veículo se não estiver carregado
      if (!veiculos.find(v => v.id === ordem.veiculo_id)) {
        const { data: veiculoData, error: veiculoError } = await supabase
          .from('veiculos')
          .select('*')
          .eq('id', ordem.veiculo_id)
          .single();

        if (!veiculoError && veiculoData) {
          setVeiculos(prev => [...prev.filter(v => v.id !== veiculoData.id), veiculoData]);
        }
      }

      // Atualizar ordem com dados completos
      const ordemCompleta = {
        ...ordem,
        total_servicos: ordemDetalhes.total_servicos || 0,
        total_pecas: ordemDetalhes.total_pecas || 0,
        total_geral: ordemDetalhes.total_geral || 0,
        desconto_valor: ordemDetalhes.desconto_valor || 0,
        desconto_percentual: ordemDetalhes.desconto_percentual || 0,
        taxa_entrega: ordemDetalhes.taxa_entrega || 0,
        outras_taxas: ordemDetalhes.outras_taxas || 0,
        servicos: servicos || [],
        pecas: pecas || [],
      };

      setViewingOrdem(ordemCompleta);
    } catch (error) {
      console.error('Erro ao carregar detalhes da ordem:', error);
      toast({
        title: "Erro ao carregar detalhes",
        description: "Não foi possível carregar os detalhes da ordem.",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (ordem: OrdemServicoCompleta) => {
    if (!confirm(`Tem certeza que deseja excluir a O.S. #${ordem.numero_os}?`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from('ordens_servico')
        .delete()
        .eq('id', ordem.id);

      if (error) throw error;

      setOrdens(ordens.filter(o => o.id !== ordem.id));
      
      toast({
        title: "Ordem de Serviço excluída",
        description: `O.S. #${ordem.numero_os} foi excluída com sucesso.`,
      });
    } catch (error) {
      console.error('Error deleting order:', error);
      toast({
        title: "Erro ao excluir ordem",
        description: "Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleExportPDF = async (ordem: OrdemServicoCompleta) => {
    try {
      const { generateOSPDF } = await import('@/lib/pdfGenerator');
      
      // Carregar dados completos para o PDF (incluindo serviços e peças)
      const { data: ordemDetalhes } = await supabase
        .from('ordens_servico')
        .select('*')
        .eq('id', ordem.id)
        .single();

      const { data: servicos } = await supabase
        .from('servicos_os')
        .select('*')
        .eq('ordem_servico_id', ordem.id);

      const { data: pecas } = await supabase
        .from('pecas_os')
        .select('*')
        .eq('ordem_servico_id', ordem.id);

      const veiculoData = getVeiculoData(ordem.veiculo_id);
      
      await generateOSPDF({
        numero_os: ordem.numero_os,
        cliente_nome: getClienteNome(ordem.cliente_id),
        ...veiculoData,
        status: StatusOSLabels[ordem.status],
        data_abertura: ordem.data_pedido,
        data_entrega: ordem.data_fim,
        defeitos_reclamacoes: ordem.defeitos_reclamacoes,
        descricao: ordem.descricao,
        relatorio_tecnico: ordem.relatorio_tecnico,
        total_servicos: ordemDetalhes?.total_servicos || 0,
        total_pecas: ordemDetalhes?.total_pecas || 0,
        total_geral: ordemDetalhes?.total_geral || 0,
        servicos: servicos?.map(s => ({
          descricao: s.descricao,
          valor: s.valor,
          quantidade: s.quantidade,
          subtotal: s.subtotal || (s.valor * s.quantidade)
        })) || [],
        pecas: pecas?.map(p => ({
          descricao: p.descricao,
          valor: p.valor,
          quantidade: p.quantidade,
          subtotal: p.subtotal || (p.valor * p.quantidade)
        })) || [],
        empresa_nome: empresa?.nome || 'Oficina',
        empresa_telefone: (empresa as any)?.telefone,
        empresa_endereco: (empresa as any)?.endereco || (empresa as any)?.endereco_completo,
        empresa_cnpj: empresa?.cnpj,
        empresa_logo: (empresa as any)?.logo,
        empresa_responsavel: (empresa as any)?.responsavel_tecnico,
        garantia: ordem.garantia,
        clausulas_contratuais: ordem.clausulas_contratuais
      });

      toast({
        title: "PDF gerado com sucesso!",
        description: `O.S. #${ordem.numero_os} foi exportada em PDF.`,
      });
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      toast({
        title: "Erro ao gerar PDF",
        description: "Não foi possível gerar o PDF. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleSendWhatsApp = (ordem: OrdemServicoCompleta) => {
    // TODO: Implementar envio via WhatsApp
    toast({
      title: "Enviar WhatsApp",
      description: "Funcionalidade em desenvolvimento.",
    });
  };

  // Helper functions
  const getClienteNome = (clienteId: string) => {
    const cliente = clientes.find(c => c.id === clienteId);
    return cliente ? cliente.nome : 'Cliente não encontrado';
  };

  const getVeiculoInfo = (veiculoId: string) => {
    const veiculo = veiculos.find(v => v.id === veiculoId);
    return veiculo ? `${veiculo.marca} ${veiculo.modelo} - ${veiculo.placa}` : 'Veículo não encontrado';
  };

  const getVeiculoData = (veiculoId: string) => {
    const veiculo = veiculos.find(v => v.id === veiculoId);
    return veiculo ? {
      marca: veiculo.marca,
      modelo: veiculo.modelo,
      placa: veiculo.placa,
      ano: veiculo.ano,
      cor: veiculo.cor,
      combustivel: veiculo.combustivel
    } : {};
  };

  const getStatusBadge = (status: StatusOS) => {
    return (
      <Badge className={StatusOSColors[status]}>
        {StatusOSLabels[status]}
      </Badge>
    );
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando ordens de serviço...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Ordens de Serviço</h1>
          <p className="text-muted-foreground">
            Gerencie todas as ordens de serviço da sua oficina
          </p>
        </div>
        <Button onClick={() => navigate('/service-order-form')}>
          <Plus className="mr-2 h-4 w-4" />
          Nova O.S.
        </Button>
      </div>

      {/* Filtros */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 flex-1">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por número, cliente, veículo ou descrição..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os Status</SelectItem>
                {Object.entries(StatusOSLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Ordens de Serviço */}
      <div className="grid gap-4">
        {filteredOrdens.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground mb-4">
                {searchTerm || statusFilter !== 'todos' 
                  ? 'Nenhuma ordem de serviço encontrada com os filtros aplicados.' 
                  : 'Nenhuma ordem de serviço cadastrada ainda.'}
              </p>
              {searchTerm === '' && statusFilter === 'todos' && (
                <Button onClick={() => navigate('/service-order-form')}>
                  <Plus className="mr-2 h-4 w-4" />
                  Criar primeira O.S.
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          filteredOrdens.map((ordem) => (
            <Card key={ordem.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="text-lg font-semibold">
                        O.S. #{ordem.numero_os}
                      </h3>
                      {getStatusBadge(ordem.status)}
                      {ordem.compromisso_retorno && (
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          Entrega: {formatDate(ordem.compromisso_retorno)}
                        </div>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 mb-3">
                      <div className="text-sm">
                        <strong>Cliente:</strong> {getClienteNome(ordem.cliente_id)}
                      </div>
                      <div className="text-sm">
                        <strong>Veículo:</strong> {getVeiculoInfo(ordem.veiculo_id)}
                      </div>
                      <div className="text-sm">
                        <strong>Total:</strong> {formatCurrency(ordem.total_geral || 0)}
                      </div>
                    </div>
                    
                     {ordem.defeitos_reclamacoes && (
                      <div className="text-sm text-muted-foreground mb-2">
                        <strong>Problema:</strong> {ordem.defeitos_reclamacoes}
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div>
                        Aberto em: {formatDate(ordem.created_at)}
                      </div>
                      {ordem.data_fim && (
                        <div>
                          Entrega: {formatDate(ordem.data_fim)}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 ml-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleSendWhatsApp(ordem)}
                      title="Enviar por WhatsApp"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleExportPDF(ordem)}
                      title="Exportar PDF"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleView(ordem)}
                      title="Visualizar"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(ordem)}
                      title="Editar"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(ordem)}
                      title="Excluir"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>


      {/* Modal de Visualização */}
      <Dialog open={!!viewingOrdem} onOpenChange={() => setViewingOrdem(null)}>
        <DialogContent className="max-w-5xl max-h-[95vh] overflow-y-auto p-0">
          <DialogHeader className="p-6 pb-0">
            <DialogTitle>
              Visualizar Ordem de Serviço
            </DialogTitle>
          </DialogHeader>
          {viewingOrdem && (
            <div className="p-6 pt-0">
              <OSVisualization 
                ordem={viewingOrdem as any}
                cliente={clientes.find(c => c.id === viewingOrdem.cliente_id)}
                veiculo={veiculos.find(v => v.id === viewingOrdem.veiculo_id)}
                empresa={empresa}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};