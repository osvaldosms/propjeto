import React from 'react';
import { CompanySettings } from '@/components/settings/CompanySettings';
import { TrialBanner } from '@/components/access/TrialBanner';

const Settings: React.FC = () => {
  return (
    <div className="space-y-6">
      <TrialBanner />
      
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
        <p className="text-muted-foreground">
          Gerencie as configurações da sua oficina
        </p>
      </div>

      <CompanySettings />
    </div>
  );
};

export default Settings;