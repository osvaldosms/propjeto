import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Plus, 
  Users, 
  Clock,
  Star,
  Calendar,
  Phone,
  Mail,
  MapPin
} from 'lucide-react';
import { NovoMembroModal } from '@/components/modals/NovoMembroModal';

const Team = () => {
  const [membroModalOpen, setMembroModalOpen] = useState(false);
  // Dados mockados para demonstração
  const teamMembers = [
    {
      id: 1,
      name: 'Carlos Santos',
      role: 'Mecânico Sênior',
      email: 'carlos@oficina.com',
      phone: '(11) 99999-1111',
      specialties: ['Motor', 'Transmissão'],
      rating: 4.8,
      servicesCompleted: 145,
      hoursWorked: 168,
      status: 'ativo',
      avatar: '/placeholder.svg'
    },
    {
      id: 2,
      name: 'Ana Paula Silva',
      role: 'Mecânica',
      email: 'ana@oficina.com',
      phone: '(11) 99999-2222',
      specialties: ['Freios', 'Suspensão'],
      rating: 4.9,
      servicesCompleted: 98,
      hoursWorked: 152,
      status: 'ativo',
      avatar: '/placeholder.svg'
    },
    {
      id: 3,
      name: 'Pedro Lima',
      role: 'Eletricista Automotivo',
      email: 'pedro@oficina.com',
      phone: '(11) 99999-3333',
      specialties: ['Elétrica', 'Eletrônica'],
      rating: 4.7,
      servicesCompleted: 76,
      hoursWorked: 144,
      status: 'ativo',
      avatar: '/placeholder.svg'
    },
    {
      id: 4,
      name: 'Roberta Costa',
      role: 'Atendente',
      email: 'roberta@oficina.com',
      phone: '(11) 99999-4444',
      specialties: ['Atendimento', 'Vendas'],
      rating: 4.6,
      servicesCompleted: 0,
      hoursWorked: 160,
      status: 'ativo',
      avatar: '/placeholder.svg'
    }
  ];

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      'ativo': { label: 'Ativo', variant: 'default' as const },
      'inativo': { label: 'Inativo', variant: 'secondary' as const },
      'ferias': { label: 'Férias', variant: 'outline' as const }
    };
    
    return statusConfig[status as keyof typeof statusConfig] || statusConfig.ativo;
  };

  const totalMembers = teamMembers.length;
  const activeMembers = teamMembers.filter(m => m.status === 'ativo').length;
  const totalServices = teamMembers.reduce((sum, member) => sum + member.servicesCompleted, 0);
  const avgRating = teamMembers.reduce((sum, member) => sum + member.rating, 0) / teamMembers.length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Equipe</h1>
        <Button onClick={() => setMembroModalOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Adicionar Membro
        </Button>
      </div>

      {/* Cards de resumo */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Membros</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalMembers}</div>
            <p className="text-xs text-muted-foreground">
              {activeMembers} ativos
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Serviços Concluídos</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalServices}</div>
            <p className="text-xs text-muted-foreground">
              Este mês
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avaliação Média</CardTitle>
            <Star className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgRating.toFixed(1)} ⭐</div>
            <p className="text-xs text-muted-foreground">
              Baseado em avaliações de clientes
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Horas Trabalhadas</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {teamMembers.reduce((sum, member) => sum + member.hoursWorked, 0)}h
            </div>
            <p className="text-xs text-muted-foreground">
              Total este mês
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Grid de membros da equipe */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teamMembers.map((member) => (
          <Card key={member.id}>
            <CardHeader className="text-center">
              <Avatar className="w-20 h-20 mx-auto mb-4">
                <AvatarImage src={member.avatar} alt={member.name} />
                <AvatarFallback>{member.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-xl">{member.name}</CardTitle>
                <p className="text-muted-foreground">{member.role}</p>
                <div className="mt-2">
                  <Badge variant={getStatusBadge(member.status).variant}>
                    {getStatusBadge(member.status).label}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center text-sm">
                  <Mail className="w-4 h-4 mr-2 text-muted-foreground" />
                  <span>{member.email}</span>
                </div>
                <div className="flex items-center text-sm">
                  <Phone className="w-4 h-4 mr-2 text-muted-foreground" />
                  <span>{member.phone}</span>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Especialidades</h4>
                <div className="flex flex-wrap gap-1">
                  {member.specialties.map((specialty) => (
                    <Badge key={specialty} variant="secondary" className="text-xs">
                      {specialty}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-primary">{member.servicesCompleted}</div>
                  <div className="text-xs text-muted-foreground">Serviços</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-yellow-600">{member.rating} ⭐</div>
                  <div className="text-xs text-muted-foreground">Avaliação</div>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <Button variant="outline" className="flex-1" size="sm">
                  Editar
                </Button>
                <Button variant="outline" className="flex-1" size="sm">
                  Detalhes
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabela detalhada */}
      <Card>
        <CardHeader>
          <CardTitle>Detalhes da Equipe</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Membro</TableHead>
                <TableHead>Cargo</TableHead>
                <TableHead>Especialidades</TableHead>
                <TableHead>Serviços</TableHead>
                <TableHead>Horas</TableHead>
                <TableHead>Avaliação</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {teamMembers.map((member) => (
                <TableRow key={member.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={member.avatar} alt={member.name} />
                        <AvatarFallback>{member.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{member.name}</div>
                        <div className="text-sm text-muted-foreground">{member.email}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{member.role}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {member.specialties.map((specialty) => (
                        <Badge key={specialty} variant="outline" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell className="text-center">{member.servicesCompleted}</TableCell>
                  <TableCell className="text-center">{member.hoursWorked}h</TableCell>
                  <TableCell className="text-center">{member.rating} ⭐</TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadge(member.status).variant}>
                      {getStatusBadge(member.status).label}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <NovoMembroModal 
        isOpen={membroModalOpen}
        onClose={() => setMembroModalOpen(false)}
      />
    </div>
  );
};

export default Team;