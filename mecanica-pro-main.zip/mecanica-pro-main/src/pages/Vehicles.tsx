import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { VeiculoForm } from '@/components/forms/VeiculoForm';
import { Veiculo, Cliente, VeiculoFormData } from '@/types/workshop';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Search, Edit, Trash2, Car, User, Loader } from 'lucide-react';

export const Vehicles: React.FC = () => {
  const { empresa } = useAuth();
  const { toast } = useToast();
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingVeiculo, setEditingVeiculo] = useState<Veiculo | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Load data from Supabase
  useEffect(() => {
    loadData();
  }, [empresa]);

  const loadData = async () => {
    if (!empresa?.id) return;
    
    try {
      setLoading(true);
      
      // Load both veiculos and clientes
      const [veiculosResult, clientesResult] = await Promise.all([
        supabase
          .from('veiculos')
          .select('*')
          .eq('empresa_id', empresa.id)
          .order('modelo'),
        supabase
          .from('clientes')
          .select('*')
          .eq('empresa_id', empresa.id)
          .order('nome')
      ]);

      if (veiculosResult.error) throw veiculosResult.error;
      if (clientesResult.error) throw clientesResult.error;

      setVeiculos(veiculosResult.data || []);
      setClientes(clientesResult.data || []);
    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        title: "Erro ao carregar dados",
        description: "Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getClienteNome = (clienteId: string): string => {
    const cliente = clientes.find(c => c.id === clienteId);
    return cliente?.nome || 'Cliente não encontrado';
  };

  const filteredVeiculos = veiculos.filter(veiculo => {
    const clienteNome = getClienteNome(veiculo.cliente_id);
    return (
      (veiculo.marca?.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (veiculo.modelo?.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (veiculo.placa?.toLowerCase().includes(searchTerm.toLowerCase())) ||
      clienteNome.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const handleSubmit = async (data: VeiculoFormData) => {
    if (!empresa?.id) return;
    
    try {
      const veiculoData = {
        ...data,
        empresa_id: empresa.id,
      };

      if (editingVeiculo) {
        // Update existing veiculo
        const { error } = await supabase
          .from('veiculos')
          .update(veiculoData)
          .eq('id', editingVeiculo.id)
          .eq('empresa_id', empresa.id);

        if (error) {
          console.error('Supabase error:', error);
          throw new Error(getErrorMessage(error));
        }

        // Update local state
        setVeiculos(prev => prev.map(veiculo =>
          veiculo.id === editingVeiculo.id ? { ...veiculo, ...veiculoData } : veiculo
        ));
        
        toast({
          title: "Veículo atualizado!",
          description: `${data.marca} ${data.modelo} foi atualizado com sucesso.`,
        });
      } else {
        // Create new veiculo
        const { data: result, error } = await supabase
          .from('veiculos')
          .insert([veiculoData])
          .select()
          .single();

        if (error) {
          console.error('Supabase error:', error);
          throw new Error(getErrorMessage(error));
        }

        // Update local state
        setVeiculos(prev => [...prev, result]);
        
        toast({
          title: "Veículo cadastrado!",
          description: `${data.marca} ${data.modelo} foi adicionado com sucesso.`,
        });
      }
      
      closeModal();
    } catch (error) {
      console.error('Error saving veiculo:', error);
      const errorMessage = error instanceof Error ? error.message : "Erro desconhecido. Tente novamente.";
      toast({
        title: "Erro ao salvar veículo",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const getErrorMessage = (error: any): string => {
    if (error?.message) {
      // Traduzir mensagens comuns do PostgreSQL/triggers
      if (error.message.includes('Já existe um veículo com esta placa')) {
        return 'Já existe um veículo com esta placa nesta empresa';
      }
      if (error.message.includes('Placa deve estar no formato')) {
        return 'Placa deve estar no formato ABC1234 ou ABC1D23';
      }
      if (error.message.includes('Marca do veículo é obrigatória')) {
        return 'Marca do veículo é obrigatória';
      }
      if (error.message.includes('Modelo do veículo é obrigatório')) {
        return 'Modelo do veículo é obrigatório';
      }
      if (error.message.includes('Veículo e cliente devem pertencer à mesma empresa')) {
        return 'Erro de associação: cliente e veículo devem pertencer à mesma empresa';
      }
      if (error.message.includes('Cliente não encontrado')) {
        return 'Cliente selecionado não foi encontrado';
      }
      
      return error.message;
    }
    
    return "Erro desconhecido. Verifique os dados e tente novamente.";
  };

  const handleEdit = (veiculo: Veiculo) => {
    setEditingVeiculo(veiculo);
    setIsModalOpen(true);
  };

  const handleDelete = async (veiculo: Veiculo) => {
    if (!empresa?.id) return;
    
    const confirmed = window.confirm(`Tem certeza que deseja deletar o veículo ${veiculo.marca} ${veiculo.modelo}?`);
    if (confirmed) {
      try {
        const { error } = await supabase
          .from('veiculos')
          .delete()
          .eq('id', veiculo.id)
          .eq('empresa_id', empresa.id);

        if (error) throw error;

        // Update local state
        setVeiculos(prev => prev.filter(v => v.id !== veiculo.id));
        
        toast({
          title: "Veículo deletado!",
          description: `${veiculo.marca} ${veiculo.modelo} foi removido.`,
        });
      } catch (error) {
        console.error('Error deleting veiculo:', error);
        toast({
          title: "Erro ao deletar veículo",
          description: "Tente novamente.",
          variant: "destructive",
        });
      }
    }
  };

  const closeModal = () => {
    if (hasUnsavedChanges) {
      const confirmed = window.confirm(
        'Você tem alterações não salvas. Deseja realmente fechar? Todas as alterações serão perdidas.'
      );
      if (!confirmed) return;
    }
    
    setIsModalOpen(false);
    setEditingVeiculo(null);
    setHasUnsavedChanges(false);
  };

  const handleDataChange = (hasChanges: boolean) => {
    setHasUnsavedChanges(hasChanges);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader className="animate-spin h-8 w-8 mx-auto mb-4" />
          <p className="text-muted-foreground">Carregando veículos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Veículos</h1>
          <p className="text-muted-foreground">
            Gerencie os veículos dos seus clientes
          </p>
        </div>
        <Button onClick={() => setIsModalOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Novo Veículo
        </Button>
      </div>

      {/* Busca */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center space-x-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por marca, modelo, placa ou cliente..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
          </div>
        </CardContent>
      </Card>

      {/* Lista de Veículos */}
      <div className="grid gap-4">
        {filteredVeiculos.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-muted-foreground">
                {searchTerm ? 'Nenhum veículo encontrado.' : 'Nenhum veículo cadastrado ainda.'}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredVeiculos.map((veiculo) => (
            <Card key={veiculo.id}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <Car className="h-5 w-5 text-muted-foreground" />
                      <h3 className="text-lg font-semibold">
                        {veiculo.marca} {veiculo.modelo}
                      </h3>
                      {veiculo.ano && <Badge variant="outline">{veiculo.ano}</Badge>}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 text-sm text-muted-foreground">
                      {veiculo.placa && (
                        <div>
                          <strong>Placa:</strong> {veiculo.placa}
                        </div>
                      )}
                      {veiculo.cor && (
                        <div>
                          <strong>Cor:</strong> {veiculo.cor}
                        </div>
                      )}
                      {veiculo.quilometragem && (
                        <div>
                          <strong>Km:</strong> {veiculo.quilometragem.toLocaleString()}
                        </div>
                      )}
                      <div className="md:col-span-2 lg:col-span-3 flex items-center gap-2">
                        <User className="h-4 w-4" />
                        <strong>Cliente:</strong> {getClienteNome(veiculo.cliente_id)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(veiculo)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(veiculo)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Modal de Formulário */}
      <Dialog open={isModalOpen} onOpenChange={closeModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingVeiculo ? 'Editar Veículo' : 'Novo Veículo'}
            </DialogTitle>
          </DialogHeader>
          <VeiculoForm
            veiculo={editingVeiculo}
            clientes={clientes}
            onSubmit={handleSubmit}
            onCancel={closeModal}
            onDataChange={handleDataChange}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
};