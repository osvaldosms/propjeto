export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'manager' | 'technician';
  workshopId: string;
  createdAt: string;
}

export interface Workshop {
  id: string;
  name: string;
  cnpj: string;
  email: string;
  phone: string;
  address: string;
  plan: 'essential' | 'professional' | 'premium';
  isActive: boolean;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  workshop: Workshop | null;
  isAuthenticated: boolean;
}