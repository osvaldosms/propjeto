export interface ItemEstoque {
  id: string;
  empresa_id: string;
  nome: string;
  categoria?: string;
  quantidade: number;
  estoque_minimo: number;
  preco_unitario: number;
  fornecedor?: string;
  created_at: string;
  updated_at: string;
}

export interface CategoriaEstoque {
  id: string;
  nome: string;
  empresa_id: string;
}

export type ItemEstoqueFormData = Omit<ItemEstoque, 'id' | 'empresa_id' | 'created_at' | 'updated_at'>;

export const getStockStatus = (quantidade: number, minimo: number) => {
  if (quantidade <= 0) return { status: 'Sem Estoque', variant: 'destructive' as const };
  if (quantidade <= minimo) return { status: 'Baixo', variant: 'destructive' as const };
  if (quantidade <= minimo * 2) return { status: 'Médio', variant: 'secondary' as const };
  return { status: 'Alto', variant: 'default' as const };
};