export interface TransacaoFinanceira {
  id: string;
  empresa_id: string;
  tipo: 'receita' | 'despesa';
  descricao: string;
  valor: number;
  categoria: string;
  metodo_pagamento: string;
  data: string;
  cliente?: string;
  observacoes?: string;
  status: 'confirmada' | 'pendente' | 'cancelada';
  created_at: string;
  updated_at: string;
}

export interface CategoriaFinanceira {
  id: string;
  empresa_id: string;
  nome: string;
  tipo: 'receita' | 'despesa';
  cor: string;
  created_at: string;
}

export interface NovaTransacaoData {
  tipo: 'receita' | 'despesa';
  descricao: string;
  valor: string;
  categoria: string;
  metodo_pagamento: string;
  data: string;
  cliente?: string;
  observacoes?: string;
}