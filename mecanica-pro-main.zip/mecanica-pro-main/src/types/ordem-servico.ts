// Tipos expandidos para o módulo completo de Ordem de Serviço

export interface OrdemServicoCompleta {
  id: string;
  numero_os: number;
  empresa_id: string;
  cliente_id: string;
  veiculo_id: string;
  tecnico_id?: string;
  
  // Dados básicos
  data_pedido: string;
  data_inicio: string;
  data_fim?: string;
  status: StatusOS;
  
  // Defeitos e reclamações
  defeitos_reclamacoes?: string;
  descricao?: string;
  
  // Financeiro
  total_servicos: number;
  total_pecas: number;
  desconto_valor: number;
  desconto_percentual: number;
  taxa_entrega: number;
  outras_taxas: number;
  total_geral: number;
  
  // Compromissos e notificações
  compromisso_retorno?: string;
  notificacao_automatica: boolean;
  
  // Pagamento
  condicoes_pagamento?: string;
  meios_pagamento?: string[];
  
  // Garantia e contratos
  garantia?: string;
  clausulas_contratuais?: string;
  informacoes_adicionais?: string;
  relatorio_tecnico?: string;
  
  // Checklists
  checklist_entrada?: ChecklistItem[];
  checklist_saida?: ChecklistItem[];
  
  // Histórico
  historico_alteracoes: HistoricoAlteracao[];
  
  // Timestamps
  created_at: string;
}

export interface ServicoOS {
  id: string;
  ordem_servico_id: string;
  descricao: string;
  valor: number;
  quantidade: number;
  subtotal: number;
  created_at: string;
}

export interface PecaOS {
  id: string;
  ordem_servico_id: string;
  descricao: string;
  valor: number;
  quantidade: number;
  observacao?: string;
  subtotal: number;
  created_at: string;
}

export interface AnexoOS {
  id: string;
  ordem_servico_id: string;
  empresa_id: string;
  nome_arquivo: string;
  tipo_arquivo: string;
  url_arquivo: string;
  tipo_anexo: 'antes' | 'durante' | 'depois' | 'documento';
  created_at: string;
}

export interface AssinaturaOS {
  id: string;
  ordem_servico_id: string;
  tipo_assinatura: 'cliente' | 'responsavel';
  assinatura_base64: string;
  nome_assinante: string;
  data_assinatura: string;
  created_at: string;
}

export interface ChecklistItem {
  id: string;
  descricao: string;
  verificado: boolean;
  observacao?: string;
}

export interface HistoricoAlteracao {
  data: string;
  usuario: string;
  acao: string;
  detalhes: string;
}

export type StatusOS = 
  | 'rascunho'
  | 'aguardando_aprovacao'
  | 'aprovado'
  | 'aguardando_peca'
  | 'em_execucao'
  | 'pronto_retirada'
  | 'finalizado'
  | 'cancelado';

export const StatusOSLabels: Record<StatusOS, string> = {
  rascunho: 'Rascunho',
  aguardando_aprovacao: 'Aguardando Aprovação',
  aprovado: 'Aprovado',
  aguardando_peca: 'Aguardando Peça',
  em_execucao: 'Em Execução',
  pronto_retirada: 'Pronto para Retirada',
  finalizado: 'Finalizado',
  cancelado: 'Cancelado'
};

export const StatusOSColors: Record<StatusOS, string> = {
  rascunho: 'bg-slate-100 text-slate-800',
  aguardando_aprovacao: 'bg-yellow-100 text-yellow-800',
  aprovado: 'bg-blue-100 text-blue-800',
  aguardando_peca: 'bg-orange-100 text-orange-800',
  em_execucao: 'bg-purple-100 text-purple-800',
  pronto_retirada: 'bg-green-100 text-green-800',
  finalizado: 'bg-gray-100 text-gray-800',
  cancelado: 'bg-red-100 text-red-800'
};

export const MeiosPagamento = [
  'dinheiro',
  'pix',
  'transferencia',
  'debito',
  'credito',
  'cheque',
  'cartao_loja',
  'carnê'
] as const;

export type MeioPagamento = typeof MeiosPagamento[number];

export const MeiosPagamentoLabels: Record<MeioPagamento, string> = {
  dinheiro: 'Dinheiro',
  pix: 'PIX',
  transferencia: 'Transferência',
  debito: 'Cartão de Débito',
  credito: 'Cartão de Crédito',
  cheque: 'Cheque',
  cartao_loja: 'Cartão da Loja',
  carnê: 'Carnê'
};