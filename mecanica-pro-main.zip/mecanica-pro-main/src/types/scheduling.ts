export interface Agendamento {
  id: string;
  empresa_id: string;
  cliente_id?: string;
  cliente_nome: string;
  cliente_telefone: string;
  veiculo_id?: string;
  veiculo_descricao: string;
  servico_id?: string;
  servico_nome: string;
  tecnico_id?: string;
  tecnico_nome: string;
  data_agendamento: string;
  hora_inicio: string;
  hora_fim?: string;
  duracao_estimada?: number;
  status: 'agendado' | 'confirmado' | 'em_andamento' | 'concluido' | 'cancelado';
  observacoes?: string;
  valor_estimado?: number;
  created_at: string;
  updated_at: string;
}

export interface Servico {
  id: string;
  empresa_id: string;
  nome: string;
  descricao?: string;
  preco_base?: number;
  duracao_estimada?: number;
  ativo: boolean;
  created_at: string;
}

export interface Tecnico {
  id: string;
  empresa_id: string;
  nome: string;
  telefone?: string;
  especialidades?: string[];
  ativo: boolean;
  created_at: string;
}

export interface NovoAgendamentoData {
  cliente: string;
  telefone: string;
  veiculo: string;
  servico: string;
  data: string;
  hora: string;
  tecnico: string;
  observacoes?: string;
}