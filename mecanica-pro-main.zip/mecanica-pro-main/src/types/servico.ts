export interface Servico {
  id: string;
  empresa_id: string;
  nome: string;
  descricao?: string;
  preco?: number;
}

export interface ServicoOS {
  id: string;
  ordem_servico_id: string;
  servico_id: string;
  valor?: number;
  quantidade: number;
}

export type ServicoFormData = Omit<Servico, 'id' | 'empresa_id'>;