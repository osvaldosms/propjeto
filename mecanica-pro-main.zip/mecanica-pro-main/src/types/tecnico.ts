export interface Tecnico {
  id: string;
  empresa_id: string;
  nome: string;
  funcao?: string;
  contato?: string;
}

export type TecnicoFormData = Omit<Tecnico, 'id' | 'empresa_id'>;