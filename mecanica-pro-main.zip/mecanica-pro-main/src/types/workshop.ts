// Tipos baseados no schema real do Supabase - usando snake_case
export interface Cliente {
  id: string;
  nome: string;
  email?: string;
  telefone?: string;
  endereco?: string;
  cpf?: string;
  empresa_id: string;
  created_at: string;
}

export interface Veiculo {
  id: string;
  cliente_id: string;
  marca: string;
  modelo: string;
  ano?: number;
  placa: string;
  cor?: string;
  quilometragem?: number;
  chassi?: string;
  combustivel?: string;
  empresa_id: string;
  created_at: string;
}

export interface OrdemServico {
  id: string;
  cliente_id: string;
  veiculo_id: string;
  tecnico_id?: string;
  empresa_id: string;
  descricao?: string;
  defeito_relatado?: string;
  status?: string;
  data_abertura: string;
  data_entrega?: string;
  garantia?: string;
  clausulas_contratuais?: string;
  relatorio_tecnico?: string;
}

export interface Empresa {
  id: string;
  nome: string;
  cnpj?: string;
  email?: string;
  telefone?: string;
  endereco?: string;
  endereco_completo?: string;
  whatsapp?: string;
  instagram?: string;
  facebook?: string;
  responsavel_tecnico?: string;
  logo?: string;
  created_at: string;
}

export interface Profile {
  id: string;
  nome: string;
  empresa_id: string;
  perfil: string;
  created_at: string;
  updated_at: string;
}

// Novos tipos para tabelas adicionais
export interface Tecnico {
  id: string;
  empresa_id: string;
  nome: string;
  funcao?: string;
  contato?: string;
}

export interface Servico {
  id: string;
  empresa_id: string;
  nome: string;
  descricao?: string;
  preco?: number;
}

export interface ServicoOS {
  id: string;
  ordem_servico_id: string;
  servico_id: string;
  descricao?: string;
  valor?: number;
  quantidade: number;
  subtotal?: number;
}

export interface PecaOS {
  id: string;
  ordem_servico_id: string;
  item_estoque_id: string;
  descricao?: string;
  quantidade: number;
  valor?: number;
  subtotal?: number;
  observacao?: string;
}

export interface ItemEstoque {
  id: string;
  empresa_id: string;
  nome: string;
  categoria?: string;
  quantidade: number;
  estoque_minimo: number;
  preco_unitario: number;
  fornecedor?: string;
  created_at: string;
  updated_at: string;
}

export interface CategoriaFinanceira {
  id: string;
  empresa_id: string;
  nome: string;
}

export interface TransacaoFinanceira {
  id: string;
  empresa_id: string;
  tipo: string;
  descricao?: string;
  valor: number;
  categoria?: string;
  data: string;
  cliente_id?: string;
}

export interface Agendamento {
  id: string;
  empresa_id: string;
  cliente_id?: string;
  veiculo_id?: string;
  data_agendada?: string;
  status?: string;
  observacoes?: string;
}

// Tipos para formulários (Omit campos auto-gerados)
export type ClienteFormData = Omit<Cliente, 'id' | 'empresa_id' | 'created_at'>;
export type VeiculoFormData = Omit<Veiculo, 'id' | 'empresa_id' | 'created_at'>;
export type OrdemServicoFormData = Omit<OrdemServico, 'id' | 'empresa_id'> & {
  status: string;
};
export type TecnicoFormData = Omit<Tecnico, 'id' | 'empresa_id'>;
export type ServicoFormData = Omit<Servico, 'id' | 'empresa_id'>;
export type ItemEstoqueFormData = Omit<ItemEstoque, 'id' | 'empresa_id' | 'created_at' | 'updated_at'>;

// Legacy type aliases para compatibilidade
export type StatusOrdemServico = OrdemServico['status'];