import { supabase } from '@/integrations/supabase/client';

export interface AuthCleanupResult {
  keysRemoved: number;
  success: boolean;
}

export const cleanupAuthState = (): AuthCleanupResult => {
  console.log('🧹 Starting comprehensive auth state cleanup...');
  
  let keysRemoved = 0;
  
  try {
    // Clean localStorage
    const localStorageKeys = Object.keys(localStorage);
    localStorageKeys.forEach((key) => {
      if (key.startsWith('supabase.auth.') || 
          key.includes('sb-') || 
          key.includes('workshop') ||
          key.includes('auth-token') ||
          key.includes('refresh-token') ||
          key.includes('session') ||
          key.includes('user-') ||
          key.includes('profile-')) {
        console.log(`🗑️ Removing localStorage key: ${key}`);
        localStorage.removeItem(key);
        keysRemoved++;
      }
    });
    
    // Clean sessionStorage
    const sessionStorageKeys = Object.keys(sessionStorage || {});
    sessionStorageKeys.forEach((key) => {
      if (key.startsWith('supabase.auth.') || 
          key.includes('sb-') ||
          key.includes('auth-token') ||
          key.includes('refresh-token') ||
          key.includes('session') ||
          key.includes('user-')) {
        console.log(`🗑️ Removing sessionStorage key: ${key}`);
        sessionStorage.removeItem(key);
        keysRemoved++;
      }
    });
    
    console.log(`✅ Auth cleanup complete. Removed ${keysRemoved} keys`);
    return { keysRemoved, success: true };
  } catch (error) {
    console.error('❌ Error during auth cleanup:', error);
    return { keysRemoved, success: false };
  }
};

export const checkEmailConfirmationStatus = async (email: string): Promise<{
  isConfirmed: boolean;
  needsConfirmation: boolean;
  error?: string;
}> => {
  try {
    // Attempt to get user info to check confirmation status
    const { data: { user }, error } = await supabase.auth.getUser();
    
    if (error || !user) {
      return {
        isConfirmed: false,
        needsConfirmation: true,
        error: 'Usuário não encontrado'
      };
    }
    
    const isConfirmed = !!user.email_confirmed_at;
    
    return {
      isConfirmed,
      needsConfirmation: !isConfirmed,
    };
  } catch (error) {
    console.error('Error checking email confirmation:', error);
    return {
      isConfirmed: false,
      needsConfirmation: true,
      error: 'Erro ao verificar confirmação de email'
    };
  }
};

export const resendConfirmationEmail = async (email: string): Promise<{
  success: boolean;
  error?: string;
}> => {
  try {
    console.log('📧 Resending confirmation email for:', email.replace(/(.{2}).*(@.*)/, '$1***$2'));
    
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email: email,
      options: {
        emailRedirectTo: `${window.location.origin}/dashboard`
      }
    });

    if (error) {
      console.warn('Resend email error:', error.message);
      return { success: false, error: error.message };
    }

    console.log('✅ Confirmation email resent successfully');
    return { success: true };
  } catch (error) {
    console.error('Resend email system error:', error);
    return { success: false, error: 'Erro ao reenviar email de confirmação' };
  }
};

export const handleAuthError = (error: any): string => {
  const errorMessage = error?.message || error || 'Erro desconhecido';
  
  // Map common Supabase auth errors to user-friendly messages
  if (errorMessage.includes('Invalid login credentials')) {
    return 'Email ou senha incorretos. Verifique seus dados e tente novamente.';
  }
  
  if (errorMessage.includes('Email not confirmed')) {
    return 'Email não confirmado. Verifique sua caixa de entrada ou solicite um novo email de confirmação.';
  }
  
  if (errorMessage.includes('Too many requests')) {
    return 'Muitas tentativas de login. Aguarde alguns minutos antes de tentar novamente.';
  }
  
  if (errorMessage.includes('User already registered')) {
    return 'Este email já está cadastrado. Tente fazer login ou recuperar sua senha.';
  }
  
  if (errorMessage.includes('Signup not allowed')) {
    return 'Cadastros não permitidos no momento. Tente novamente mais tarde.';
  }
  
  if (errorMessage.includes('Invalid email')) {
    return 'Email inválido. Verifique o formato do email.';
  }
  
  if (errorMessage.includes('Password should be at least')) {
    return 'A senha deve ter pelo menos 6 caracteres.';
  }
  
  return errorMessage;
};

export const debugAuthState = async (): Promise<void> => {
  console.log('🔍 DEBUG: Current auth state');
  
  try {
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    console.log('Session:', session ? 'Found' : 'None', sessionError || '');
    
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    console.log('User:', user ? `${user.email} (confirmed: ${user.email_confirmed_at ? 'yes' : 'no'})` : 'None', userError || '');
    
    // Check localStorage for auth keys
    const authKeys = Object.keys(localStorage).filter(key => 
      key.includes('supabase') || key.includes('auth') || key.includes('sb-')
    );
    console.log('Auth keys in localStorage:', authKeys.length, authKeys);
    
    console.log('Current URL:', window.location.href);
    console.log('User agent:', navigator.userAgent);
  } catch (error) {
    console.error('Debug error:', error);
  }
};