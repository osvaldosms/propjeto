import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { checkRateLimit, getRateLimitHeaders, logSecurityEvent } from '../shared/rate-limiter.ts';

// Phase 2: Enhanced security headers and rate limiting
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "X-XSS-Protection": "1; mode=block",
  "Referrer-Policy": "strict-origin-when-cross-origin"
};

// Stricter rate limiting for payment operations
const PAYMENT_RATE_LIMIT_CONFIG = {
  maxRequests: 5, // Lower limit for payment operations
  windowMs: 60000, // 1 minute
  cleanupIntervalMs: 300000 // 5 minutes
};

// Helper logging function
const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[CREATE-CHECKOUT] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Rate limiting with enhanced security
  const clientIP = req.headers.get("x-forwarded-for") || req.headers.get("x-real-ip") || "unknown";
  if (!checkRateLimit(clientIP, PAYMENT_RATE_LIMIT_CONFIG)) {
    logSecurityEvent('PAYMENT_RATE_LIMIT_EXCEEDED', {
      endpoint: 'create-checkout',
      clientId: clientIP,
      userAgent: req.headers.get('user-agent')
    });
    
    logStep('Rate limit exceeded', { clientId: clientIP });
    return new Response(JSON.stringify({ error: "Rate limit exceeded" }), {
      headers: { 
        ...corsHeaders, 
        ...getRateLimitHeaders(clientIP, PAYMENT_RATE_LIMIT_CONFIG),
        "Content-Type": "application/json" 
      },
      status: 429,
    });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? ""
  );

  try {
    logStep("Function started");
    
    // Enhanced input validation
    const body = await req.json();
    logStep("Request body received", { bodyKeys: Object.keys(body) });
    
    
    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;
    if (!user?.email) throw new Error("User not authenticated or email not available");

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", { apiVersion: "2023-10-16" });
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
    }

    // Get plan details from request body
    const { planId, price, period } = body;
    
    if (!planId || !price || !period) {
      throw new Error("Dados do plano incompletos");
    }
    
    // Plan names mapping
    const planNames = {
      essencial: "Plano Essencial",
      profissional: "Plano Profissional", 
      premium: "Plano Premium"
    };
    
    const planName = planNames[planId as keyof typeof planNames] || "Plano";
    
    // Validate price (convert from cents to validate reasonable range)
    if (price < 1000 || price > 200000) { // R$10 to R$2000
      throw new Error("Valor do plano inválido");
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      line_items: [
        {
          price_data: {
            currency: "brl",
            product_data: { name: planName },
            unit_amount: price, // Price already in cents from frontend
            recurring: { 
              interval: period === 'monthly' ? 'month' : period === 'semiannual' ? 'month' : 'year',
              interval_count: period === 'semiannual' ? 6 : 1
            },
          },
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: `${req.headers.get("origin")}/dashboard?success=true`,
      cancel_url: `${req.headers.get("origin")}/plans?canceled=true`,
    });

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});