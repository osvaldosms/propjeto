// Shared rate limiting utilities for edge functions
// This ensures consistent rate limiting behavior across all functions

interface RateLimitEntry {
  requests: number[];
  lastCleanup: number;
}

const rateLimitMap = new Map<string, RateLimitEntry>();

// Default rate limit configuration
export const DEFAULT_RATE_LIMIT_CONFIG = {
  maxRequests: 10,
  windowMs: 60000, // 1 minute
  cleanupIntervalMs: 300000 // 5 minutes
};

export function checkRateLimit(
  clientId: string, 
  config = DEFAULT_RATE_LIMIT_CONFIG
): boolean {
  const now = Date.now();
  const windowStart = now - config.windowMs;
  
  // Get or create rate limit entry
  let entry = rateLimitMap.get(clientId);
  if (!entry) {
    entry = { requests: [], lastCleanup: now };
    rateLimitMap.set(clientId, entry);
  }
  
  // Remove old requests
  entry.requests = entry.requests.filter(time => time > windowStart);
  
  // Check if limit exceeded
  if (entry.requests.length >= config.maxRequests) {
    return false; // Rate limit exceeded
  }
  
  // Add current request
  entry.requests.push(now);
  
  // Periodic cleanup of old entries
  if (now - entry.lastCleanup > config.cleanupIntervalMs) {
    entry.lastCleanup = now;
    
    // Clean up old entries from the map
    for (const [key, value] of rateLimitMap.entries()) {
      if (now - value.lastCleanup > config.cleanupIntervalMs * 2) {
        rateLimitMap.delete(key);
      }
    }
  }
  
  return true; // Request allowed
}

export function getRateLimitHeaders(
  clientId: string,
  config = DEFAULT_RATE_LIMIT_CONFIG
): Record<string, string> {
  const entry = rateLimitMap.get(clientId);
  const remaining = Math.max(0, config.maxRequests - (entry?.requests.length || 0));
  const resetTime = Math.ceil(Date.now() / 1000) + Math.ceil(config.windowMs / 1000);
  
  return {
    'X-RateLimit-Limit': config.maxRequests.toString(),
    'X-RateLimit-Remaining': remaining.toString(),
    'X-RateLimit-Reset': resetTime.toString(),
  };
}

export function logSecurityEvent(event: string, details: Record<string, any>): void {
  console.log(`🔒 Security Event: ${event}`, {
    timestamp: new Date().toISOString(),
    ...details
  });
}