-- Create profiles table for additional user information
CREATE TABLE public.profiles (
  id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  nome TEXT NOT NULL,
  empresa_id UUID REFERENCES public.empresas(id) ON DELETE CASCADE,
  perfil TEXT DEFAULT 'admin'::text,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Users can view their own profile" 
ON public.profiles FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles FOR UPDATE 
USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles FOR INSERT 
WITH CHECK (auth.uid() = id);

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = ''
AS $$
BEGIN
  -- Create empresa first if it doesn't exist
  INSERT INTO public.empresas (id, nome, cnpj, created_at)
  VALUES (
    gen_random_uuid(),
    COALESCE(NEW.raw_user_meta_data ->> 'workshop_name', 'Oficina'),
    COALESCE(NEW.raw_user_meta_data ->> 'cnpj', ''),
    now()
  )
  ON CONFLICT DO NOTHING;
  
  -- Get the empresa_id (either newly created or existing)
  WITH empresa_data AS (
    SELECT id as empresa_id FROM public.empresas 
    WHERE nome = COALESCE(NEW.raw_user_meta_data ->> 'workshop_name', 'Oficina')
    LIMIT 1
  )
  INSERT INTO public.profiles (id, nome, empresa_id, perfil, created_at, updated_at)
  SELECT 
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email),
    empresa_data.empresa_id,
    'admin',
    now(),
    now()
  FROM empresa_data;
  
  RETURN NEW;
END;
$$;

-- Create trigger for new user signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Update existing tables to use auth user id instead of custom user id
-- Update usuarios table data to be compatible with new structure
-- Note: This keeps existing data but maps it to proper auth structure