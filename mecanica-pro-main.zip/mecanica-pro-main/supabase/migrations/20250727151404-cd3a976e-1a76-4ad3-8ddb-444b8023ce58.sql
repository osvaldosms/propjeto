-- Primeiro, vamos verificar se a tabela ordens_servico_itens já existe para serviços
-- Se não existir, criaremos uma estrutura completa para o módulo de OS

-- Tabela para itens de serviços na OS
CREATE TABLE IF NOT EXISTS public.servicos_os (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  ordem_servico_id UUID NOT NULL,
  descricao TEXT NOT NULL,
  valor DECIMAL(10,2) NOT NULL DEFAULT 0,
  quantidade INTEGER NOT NULL DEFAULT 1,
  subtotal DECIMAL(10,2) GENERATED ALWAYS AS (valor * quantidade) STORED,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela para itens de peças na OS
CREATE TABLE IF NOT EXISTS public.pecas_os (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  ordem_servico_id UUID NOT NULL,
  descricao TEXT NOT NULL,
  valor DECIMAL(10,2) NOT NULL DEFAULT 0,
  quantidade INTEGER NOT NULL DEFAULT 1,
  observacao TEXT,
  subtotal DECIMAL(10,2) GENERATED ALWAYS AS (valor * quantidade) STORED,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela para anexos da OS
CREATE TABLE IF NOT EXISTS public.anexos_os (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  ordem_servico_id UUID NOT NULL,
  empresa_id UUID NOT NULL,
  nome_arquivo TEXT NOT NULL,
  tipo_arquivo TEXT NOT NULL,
  url_arquivo TEXT NOT NULL,
  tipo_anexo TEXT NOT NULL CHECK (tipo_anexo IN ('antes', 'durante', 'depois', 'documento')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela para assinaturas digitais
CREATE TABLE IF NOT EXISTS public.assinaturas_os (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  ordem_servico_id UUID NOT NULL,
  tipo_assinatura TEXT NOT NULL CHECK (tipo_assinatura IN ('cliente', 'responsavel')),
  assinatura_base64 TEXT NOT NULL,
  nome_assinante TEXT NOT NULL,
  data_assinatura TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Modificar a tabela ordens_servico para incluir novos campos
ALTER TABLE public.ordens_servico 
ADD COLUMN IF NOT EXISTS numero_os SERIAL,
ADD COLUMN IF NOT EXISTS data_pedido TIMESTAMP WITH TIME ZONE DEFAULT now(),
ADD COLUMN IF NOT EXISTS defeitos_reclamacoes TEXT,
ADD COLUMN IF NOT EXISTS desconto_valor DECIMAL(10,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS desconto_percentual DECIMAL(5,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS taxa_entrega DECIMAL(10,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS outras_taxas DECIMAL(10,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS compromisso_retorno TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS condicoes_pagamento TEXT,
ADD COLUMN IF NOT EXISTS meios_pagamento TEXT[], -- Array para múltiplos meios
ADD COLUMN IF NOT EXISTS garantia TEXT,
ADD COLUMN IF NOT EXISTS clausulas_contratuais TEXT,
ADD COLUMN IF NOT EXISTS informacoes_adicionais TEXT,
ADD COLUMN IF NOT EXISTS relatorio_tecnico TEXT,
ADD COLUMN IF NOT EXISTS checklist_entrada JSONB,
ADD COLUMN IF NOT EXISTS checklist_saida JSONB,
ADD COLUMN IF NOT EXISTS historico_alteracoes JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS notificacao_automatica BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS total_servicos DECIMAL(10,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_pecas DECIMAL(10,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_geral DECIMAL(10,2) DEFAULT 0;

-- Atualizar status possíveis
ALTER TABLE public.ordens_servico 
ALTER COLUMN status TYPE TEXT,
ADD CONSTRAINT check_status_os CHECK (status IN (
  'aguardando_aprovacao',
  'aprovado', 
  'aguardando_peca',
  'em_execucao',
  'pronto_retirada',
  'finalizado',
  'cancelado'
));

-- Função para calcular totais automaticamente
CREATE OR REPLACE FUNCTION public.calcular_totais_os()
RETURNS TRIGGER AS $$
BEGIN
  -- Calcular total de serviços
  UPDATE public.ordens_servico 
  SET total_servicos = (
    SELECT COALESCE(SUM(subtotal), 0) 
    FROM public.servicos_os 
    WHERE ordem_servico_id = NEW.ordem_servico_id
  )
  WHERE id = NEW.ordem_servico_id;
  
  -- Calcular total de peças
  UPDATE public.ordens_servico 
  SET total_pecas = (
    SELECT COALESCE(SUM(subtotal), 0) 
    FROM public.pecas_os 
    WHERE ordem_servico_id = NEW.ordem_servico_id
  )
  WHERE id = NEW.ordem_servico_id;
  
  -- Calcular total geral
  UPDATE public.ordens_servico 
  SET total_geral = (
    total_servicos + total_pecas + COALESCE(taxa_entrega, 0) + COALESCE(outras_taxas, 0) - 
    CASE 
      WHEN desconto_percentual > 0 THEN (total_servicos + total_pecas) * (desconto_percentual / 100)
      ELSE COALESCE(desconto_valor, 0)
    END
  )
  WHERE id = NEW.ordem_servico_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para recalcular totais
DROP TRIGGER IF EXISTS trigger_calcular_totais_servicos ON public.servicos_os;
CREATE TRIGGER trigger_calcular_totais_servicos
  AFTER INSERT OR UPDATE OR DELETE ON public.servicos_os
  FOR EACH ROW EXECUTE FUNCTION public.calcular_totais_os();

DROP TRIGGER IF EXISTS trigger_calcular_totais_pecas ON public.pecas_os;
CREATE TRIGGER trigger_calcular_totais_pecas
  AFTER INSERT OR UPDATE OR DELETE ON public.pecas_os
  FOR EACH ROW EXECUTE FUNCTION public.calcular_totais_os();

-- Habilitar RLS nas novas tabelas
ALTER TABLE public.servicos_os ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pecas_os ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.anexos_os ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assinaturas_os ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para servicos_os
CREATE POLICY "Users can manage services in their company orders" 
ON public.servicos_os 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.ordens_servico os 
    WHERE os.id = servicos_os.ordem_servico_id 
    AND os.empresa_id = (
      SELECT usuarios.empresa_id 
      FROM usuarios 
      WHERE usuarios.id = auth.uid()
    )
  )
);

-- Políticas RLS para pecas_os
CREATE POLICY "Users can manage parts in their company orders" 
ON public.pecas_os 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.ordens_servico os 
    WHERE os.id = pecas_os.ordem_servico_id 
    AND os.empresa_id = (
      SELECT usuarios.empresa_id 
      FROM usuarios 
      WHERE usuarios.id = auth.uid()
    )
  )
);

-- Políticas RLS para anexos_os
CREATE POLICY "Users can manage attachments in their company orders" 
ON public.anexos_os 
FOR ALL 
USING (empresa_id = (
  SELECT usuarios.empresa_id 
  FROM usuarios 
  WHERE usuarios.id = auth.uid()
));

-- Políticas RLS para assinaturas_os
CREATE POLICY "Users can manage signatures in their company orders" 
ON public.assinaturas_os 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.ordens_servico os 
    WHERE os.id = assinaturas_os.ordem_servico_id 
    AND os.empresa_id = (
      SELECT usuarios.empresa_id 
      FROM usuarios 
      WHERE usuarios.id = auth.uid()
    )
  )
);