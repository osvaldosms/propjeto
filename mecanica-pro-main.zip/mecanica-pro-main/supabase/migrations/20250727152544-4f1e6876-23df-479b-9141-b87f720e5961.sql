-- Corrigir função com search_path seguro
CREATE OR REPLACE FUNCTION public.calcular_totais_os()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  -- Calcular total de serviços
  UPDATE public.ordens_servico 
  SET total_servicos = (
    SELECT COALESCE(SUM(subtotal), 0) 
    FROM public.servicos_os 
    WHERE ordem_servico_id = NEW.ordem_servico_id
  )
  WHERE id = NEW.ordem_servico_id;
  
  -- Calcular total de peças
  UPDATE public.ordens_servico 
  SET total_pecas = (
    SELECT COALESCE(SUM(subtotal), 0) 
    FROM public.pecas_os 
    WHERE ordem_servico_id = NEW.ordem_servico_id
  )
  WHERE id = NEW.ordem_servico_id;
  
  -- Calcular total geral
  UPDATE public.ordens_servico 
  SET total_geral = (
    total_servicos + total_pecas + COALESCE(taxa_entrega, 0) + COALESCE(outras_taxas, 0) - 
    CASE 
      WHEN desconto_percentual > 0 THEN (total_servicos + total_pecas) * (desconto_percentual / 100)
      ELSE COALESCE(desconto_valor, 0)
    END
  )
  WHERE id = NEW.ordem_servico_id;
  
  RETURN NEW;
END;
$$;