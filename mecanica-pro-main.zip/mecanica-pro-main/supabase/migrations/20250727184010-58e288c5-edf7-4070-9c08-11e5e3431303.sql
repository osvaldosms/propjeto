-- Criar tabela de transações financeiras
CREATE TABLE public.transacoes_financeiras (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('receita', 'despesa')),
  descricao TEXT NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  categoria TEXT NOT NULL,
  metodo_pagamento TEXT NOT NULL,
  data DATE NOT NULL,
  cliente TEXT,
  observacoes TEXT,
  status TEXT NOT NULL DEFAULT 'confirmada' CHECK (status IN ('confirmada', 'pendente', 'cancelada')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de categorias financeiras
CREATE TABLE public.categorias_financeiras (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL,
  nome TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('receita', 'despesa')),
  cor TEXT DEFAULT '#3B82F6',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de serviços disponíveis
CREATE TABLE public.servicos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL,
  nome TEXT NOT NULL,
  descricao TEXT,
  preco_base DECIMAL(10,2),
  duracao_estimada INTEGER, -- em minutos
  ativo BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de agendamentos
CREATE TABLE public.agendamentos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL,
  cliente_id UUID,
  cliente_nome TEXT NOT NULL,
  cliente_telefone TEXT NOT NULL,
  veiculo_id UUID,
  veiculo_descricao TEXT NOT NULL,
  servico_id UUID,
  servico_nome TEXT NOT NULL,
  tecnico_id UUID,
  tecnico_nome TEXT NOT NULL,
  data_agendamento DATE NOT NULL,
  hora_inicio TIME NOT NULL,
  hora_fim TIME,
  duracao_estimada INTEGER,
  status TEXT NOT NULL DEFAULT 'agendado' CHECK (status IN ('agendado', 'confirmado', 'em_andamento', 'concluido', 'cancelado')),
  observacoes TEXT,
  valor_estimado DECIMAL(10,2),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de técnicos
CREATE TABLE public.tecnicos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL,
  nome TEXT NOT NULL,
  telefone TEXT,
  especialidades TEXT[],
  ativo BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.transacoes_financeiras ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categorias_financeiras ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.servicos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agendamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tecnicos ENABLE ROW LEVEL SECURITY;

-- RLS Policies for transacoes_financeiras
CREATE POLICY "Users can manage financial transactions in their company" 
ON public.transacoes_financeiras 
FOR ALL 
USING (empresa_id = (SELECT empresa_id FROM usuarios WHERE id = auth.uid()));

-- RLS Policies for categorias_financeiras
CREATE POLICY "Users can manage financial categories in their company" 
ON public.categorias_financeiras 
FOR ALL 
USING (empresa_id = (SELECT empresa_id FROM usuarios WHERE id = auth.uid()));

-- RLS Policies for servicos
CREATE POLICY "Users can manage services in their company" 
ON public.servicos 
FOR ALL 
USING (empresa_id = (SELECT empresa_id FROM usuarios WHERE id = auth.uid()));

-- RLS Policies for agendamentos
CREATE POLICY "Users can manage appointments in their company" 
ON public.agendamentos 
FOR ALL 
USING (empresa_id = (SELECT empresa_id FROM usuarios WHERE id = auth.uid()));

-- RLS Policies for tecnicos
CREATE POLICY "Users can manage technicians in their company" 
ON public.tecnicos 
FOR ALL 
USING (empresa_id = (SELECT empresa_id FROM usuarios WHERE id = auth.uid()));

-- Função para atualizar updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para updated_at
CREATE TRIGGER update_transacoes_financeiras_updated_at
  BEFORE UPDATE ON public.transacoes_financeiras
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_agendamentos_updated_at
  BEFORE UPDATE ON public.agendamentos
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Inserir categorias padrão
INSERT INTO public.categorias_financeiras (empresa_id, nome, tipo, cor) VALUES
-- Para receitas
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Serviços de Manutenção', 'receita', '#10B981'),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Peças e Acessórios', 'receita', '#3B82F6'),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Diagnóstico', 'receita', '#8B5CF6'),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Emergência', 'receita', '#F59E0B'),
-- Para despesas
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Compra de Peças', 'despesa', '#EF4444'),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Ferramentas', 'despesa', '#F97316'),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Energia Elétrica', 'despesa', '#6366F1'),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Aluguel', 'despesa', '#EC4899'),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Salários', 'despesa', '#14B8A6'),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Combustível', 'despesa', '#84CC16');

-- Inserir serviços padrão
INSERT INTO public.servicos (empresa_id, nome, descricao, preco_base, duracao_estimada) VALUES
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Troca de óleo', 'Troca de óleo do motor', 80.00, 30),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Revisão completa', 'Revisão geral do veículo', 350.00, 120),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Alinhamento e balanceamento', 'Alinhamento e balanceamento das rodas', 120.00, 60),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Troca de pastilhas', 'Troca de pastilhas de freio', 180.00, 45),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Diagnóstico eletrônico', 'Diagnóstico computadorizado', 100.00, 30),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Reparo do motor', 'Reparo geral do motor', 800.00, 240),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Troca de pneus', 'Troca e montagem de pneus', 60.00, 30);

-- Inserir técnicos padrão
INSERT INTO public.tecnicos (empresa_id, nome, telefone, especialidades) VALUES
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Carlos Santos', '(11) 99999-0001', ARRAY['Motor', 'Freios', 'Suspensão']),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Ana Paula Silva', '(11) 99999-0002', ARRAY['Elétrica', 'Ar condicionado', 'Injeção eletrônica']),
((SELECT empresa_id FROM usuarios WHERE id = auth.uid() LIMIT 1), 'Pedro Lima', '(11) 99999-0003', ARRAY['Câmbio', 'Embreagem', 'Direção']);