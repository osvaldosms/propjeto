-- Criar tabela de transações financeiras
CREATE TABLE public.transacoes_financeiras (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('receita', 'despesa')),
  descricao TEXT NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  categoria TEXT NOT NULL,
  metodo_pagamento TEXT NOT NULL,
  data DATE NOT NULL,
  cliente TEXT,
  observacoes TEXT,
  status TEXT NOT NULL DEFAULT 'confirmada' CHECK (status IN ('confirmada', 'pendente', 'cancelada')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de categorias financeiras
CREATE TABLE public.categorias_financeiras (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL,
  nome TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('receita', 'despesa')),
  cor TEXT DEFAULT '#3B82F6',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de serviços disponíveis
CREATE TABLE public.servicos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL,
  nome TEXT NOT NULL,
  descricao TEXT,
  preco_base DECIMAL(10,2),
  duracao_estimada INTEGER, -- em minutos
  ativo BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de agendamentos
CREATE TABLE public.agendamentos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL,
  cliente_id UUID,
  cliente_nome TEXT NOT NULL,
  cliente_telefone TEXT NOT NULL,
  veiculo_id UUID,
  veiculo_descricao TEXT NOT NULL,
  servico_id UUID,
  servico_nome TEXT NOT NULL,
  tecnico_id UUID,
  tecnico_nome TEXT NOT NULL,
  data_agendamento DATE NOT NULL,
  hora_inicio TIME NOT NULL,
  hora_fim TIME,
  duracao_estimada INTEGER,
  status TEXT NOT NULL DEFAULT 'agendado' CHECK (status IN ('agendado', 'confirmado', 'em_andamento', 'concluido', 'cancelado')),
  observacoes TEXT,
  valor_estimado DECIMAL(10,2),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de técnicos
CREATE TABLE public.tecnicos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL,
  nome TEXT NOT NULL,
  telefone TEXT,
  especialidades TEXT[],
  ativo BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.transacoes_financeiras ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categorias_financeiras ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.servicos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agendamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tecnicos ENABLE ROW LEVEL SECURITY;

-- RLS Policies for transacoes_financeiras
CREATE POLICY "Users can manage financial transactions in their company" 
ON public.transacoes_financeiras 
FOR ALL 
USING (empresa_id = (SELECT empresa_id FROM usuarios WHERE id = auth.uid()));

-- RLS Policies for categorias_financeiras
CREATE POLICY "Users can manage financial categories in their company" 
ON public.categorias_financeiras 
FOR ALL 
USING (empresa_id = (SELECT empresa_id FROM usuarios WHERE id = auth.uid()));

-- RLS Policies for servicos
CREATE POLICY "Users can manage services in their company" 
ON public.servicos 
FOR ALL 
USING (empresa_id = (SELECT empresa_id FROM usuarios WHERE id = auth.uid()));

-- RLS Policies for agendamentos
CREATE POLICY "Users can manage appointments in their company" 
ON public.agendamentos 
FOR ALL 
USING (empresa_id = (SELECT empresa_id FROM usuarios WHERE id = auth.uid()));

-- RLS Policies for tecnicos
CREATE POLICY "Users can manage technicians in their company" 
ON public.tecnicos 
FOR ALL 
USING (empresa_id = (SELECT empresa_id FROM usuarios WHERE id = auth.uid()));

-- Função para atualizar updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para updated_at
CREATE TRIGGER update_transacoes_financeiras_updated_at
  BEFORE UPDATE ON public.transacoes_financeiras
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_agendamentos_updated_at
  BEFORE UPDATE ON public.agendamentos
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();