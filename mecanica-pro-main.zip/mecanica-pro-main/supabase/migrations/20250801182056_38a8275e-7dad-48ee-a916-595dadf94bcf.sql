-- Corrigir trigger para criar usuários corretamente
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  -- Primeiro criar/obter empresa
  INSERT INTO public.empresas (id, nome, cnpj, created_at)
  VALUES (
    gen_random_uuid(),
    COALESCE(NEW.raw_user_meta_data ->> 'workshop_name', COALESCE(NEW.raw_user_meta_data ->> 'full_name', 'Oficina')),
    COALESCE(NEW.raw_user_meta_data ->> 'cnpj', ''),
    now()
  )
  ON CONFLICT DO NOTHING;
  
  -- Inserir profile ligado à empresa
  INSERT INTO public.profiles (id, nome, empresa_id, perfil, created_at, updated_at)
  SELECT 
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email),
    e.id,
    'admin',
    now(),
    now()
  FROM public.empresas e 
  WHERE e.nome = COALESCE(NEW.raw_user_meta_data ->> 'workshop_name', COALESCE(NEW.raw_user_meta_data ->> 'full_name', 'Oficina'))
  LIMIT 1
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$;

-- Inserir dados básicos de teste para facilitar primeiros testes
DO $$
DECLARE
    empresa_teste_id uuid;
    cliente_teste_id uuid;
    veiculo_teste_id uuid;
    servico_teste_id uuid;
BEGIN
    -- Pegar uma empresa existente ou criar uma de teste
    SELECT id INTO empresa_teste_id FROM empresas LIMIT 1;
    
    IF empresa_teste_id IS NULL THEN
        INSERT INTO empresas (id, nome, cnpj) 
        VALUES (gen_random_uuid(), 'Oficina de Teste', '12.345.678/0001-90')
        RETURNING id INTO empresa_teste_id;
    END IF;
    
    -- Inserir cliente de teste
    INSERT INTO clientes (id, nome, telefone, email, empresa_id)
    VALUES (gen_random_uuid(), 'João Silva', '(11) 99999-9999', 'joao@teste.com', empresa_teste_id)
    ON CONFLICT DO NOTHING
    RETURNING id INTO cliente_teste_id;
    
    -- Se não retornou ID, pegar um existente
    IF cliente_teste_id IS NULL THEN
        SELECT id INTO cliente_teste_id FROM clientes WHERE empresa_id = empresa_teste_id LIMIT 1;
    END IF;
    
    -- Inserir veículo de teste
    IF cliente_teste_id IS NOT NULL THEN
        INSERT INTO veiculos (id, marca, modelo, ano, placa, cliente_id, empresa_id)
        VALUES (gen_random_uuid(), 'Toyota', 'Corolla', 2020, 'ABC-1234', cliente_teste_id, empresa_teste_id)
        ON CONFLICT DO NOTHING;
    END IF;
    
    -- Inserir serviços básicos
    INSERT INTO servicos (id, nome, descricao, preco_base, duracao_estimada, empresa_id) VALUES
    (gen_random_uuid(), 'Troca de Óleo', 'Troca de óleo do motor', 80.00, 30, empresa_teste_id),
    (gen_random_uuid(), 'Alinhamento', 'Alinhamento e balanceamento', 120.00, 60, empresa_teste_id),
    (gen_random_uuid(), 'Revisão Geral', 'Revisão completa do veículo', 300.00, 120, empresa_teste_id)
    ON CONFLICT DO NOTHING;
    
    -- Inserir técnico básico
    INSERT INTO tecnicos (id, nome, telefone, empresa_id) VALUES
    (gen_random_uuid(), 'Carlos Mecânico', '(11) 98888-8888', empresa_teste_id)
    ON CONFLICT DO NOTHING;
    
END $$;