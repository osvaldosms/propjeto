-- Phase 1: Critical RLS Policy Consolidation
-- Remove conflicting policies and standardize to use profiles table

-- Drop conflicting policies on categorias_financeiras
DROP POLICY IF EXISTS "Users can manage financial categories in their company" ON categorias_financeiras;

-- Drop conflicting policies on itens_estoque  
DROP POLICY IF EXISTS "Users can manage inventory items in their company" ON itens_estoque;

-- Drop conflicting policies on empresas
DROP POLICY IF EXISTS "Policy_empresas" ON empresas;
DROP POLICY IF EXISTS "Users can create companies" ON empresas;

-- Drop conflicting policies on servicos
DROP POLICY IF EXISTS "Users can manage services in their company" ON servicos;

-- Drop conflicting policies on tecnicos
DROP POLICY IF EXISTS "Users can manage technicians in their company" ON tecnicos;

-- Create security definer function to get user's company ID safely
CREATE OR REPLACE FUNCTION public.get_user_empresa_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT empresa_id FROM public.profiles WHERE id = auth.uid();
$$;

-- Create unified RLS policies using the security definer function

-- Categorias Financeiras - unified policy
CREATE POLICY "Users can manage their company financial categories"
ON categorias_financeiras
FOR ALL
USING (empresa_id = public.get_user_empresa_id())
WITH CHECK (empresa_id = public.get_user_empresa_id());

-- Itens Estoque - unified policy  
CREATE POLICY "Users can manage their company inventory"
ON itens_estoque
FOR ALL
USING (empresa_id = public.get_user_empresa_id())
WITH CHECK (empresa_id = public.get_user_empresa_id());

-- Empresas - allow users to manage only their own company
CREATE POLICY "Users can manage their own company"
ON empresas
FOR ALL
USING (id = public.get_user_empresa_id())
WITH CHECK (id = public.get_user_empresa_id());

-- Servicos - unified policy
CREATE POLICY "Users can manage their company services"
ON servicos  
FOR ALL
USING (empresa_id = public.get_user_empresa_id())
WITH CHECK (empresa_id = public.get_user_empresa_id());

-- Tecnicos - unified policy
CREATE POLICY "Users can manage their company technicians"
ON tecnicos
FOR ALL  
USING (empresa_id = public.get_user_empresa_id())
WITH CHECK (empresa_id = public.get_user_empresa_id());

-- Add security function to validate user access to ordem_servico
CREATE OR REPLACE FUNCTION public.user_can_access_ordem_servico(os_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM ordens_servico 
    WHERE id = os_id 
    AND empresa_id = public.get_user_empresa_id()
  );
$$;

-- Update service and parts policies to use security function
DROP POLICY IF EXISTS "Users can manage services in their company orders" ON servicos_os;
CREATE POLICY "Users can manage services in their company orders"
ON servicos_os
FOR ALL
USING (public.user_can_access_ordem_servico(ordem_servico_id))
WITH CHECK (public.user_can_access_ordem_servico(ordem_servico_id));

DROP POLICY IF EXISTS "Users can manage parts in their company orders" ON pecas_os;  
CREATE POLICY "Users can manage parts in their company orders"
ON pecas_os
FOR ALL
USING (public.user_can_access_ordem_servico(ordem_servico_id))
WITH CHECK (public.user_can_access_ordem_servico(ordem_servico_id));

-- Update attachments and signatures policies
DROP POLICY IF EXISTS "Users can manage attachments in their company orders" ON anexos_os;
CREATE POLICY "Users can manage attachments in their company orders"
ON anexos_os
FOR ALL
USING (empresa_id = public.get_user_empresa_id())
WITH CHECK (empresa_id = public.get_user_empresa_id());

DROP POLICY IF EXISTS "Users can manage signatures in their company orders" ON assinaturas_os;
CREATE POLICY "Users can manage signatures in their company orders"  
ON assinaturas_os
FOR ALL
USING (public.user_can_access_ordem_servico(ordem_servico_id))
WITH CHECK (public.user_can_access_ordem_servico(ordem_servico_id));

-- Add audit logging table for security monitoring
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id),
  empresa_id uuid,
  action text NOT NULL,
  table_name text NOT NULL,
  record_id uuid,
  old_values jsonb,
  new_values jsonb,
  ip_address inet,
  user_agent text,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on audit logs
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Only allow users to view their own company's audit logs
CREATE POLICY "Users can view their company audit logs"
ON audit_logs
FOR SELECT
USING (empresa_id = public.get_user_empresa_id());

-- Create audit trigger function
CREATE OR REPLACE FUNCTION public.audit_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  INSERT INTO public.audit_logs (
    user_id,
    empresa_id, 
    action,
    table_name,
    record_id,
    old_values,
    new_values
  ) VALUES (
    auth.uid(),
    public.get_user_empresa_id(),
    TG_OP,
    TG_TABLE_NAME,
    CASE WHEN TG_OP = 'DELETE' THEN OLD.id ELSE NEW.id END,
    CASE WHEN TG_OP IN ('UPDATE', 'DELETE') THEN row_to_json(OLD) ELSE NULL END,
    CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN row_to_json(NEW) ELSE NULL END
  );
  
  RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$;