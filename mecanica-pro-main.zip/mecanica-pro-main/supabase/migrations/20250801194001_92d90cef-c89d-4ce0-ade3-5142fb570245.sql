-- Phase 1: Critical RLS Policy Consolidation (Fixed)
-- Drop ALL existing conflicting policies first

-- Drop all policies on categorias_financeiras
DROP POLICY IF EXISTS "Users can manage financial categories in their company" ON categorias_financeiras;
DROP POLICY IF EXISTS "Users can manage their company data" ON categorias_financeiras;

-- Drop all policies on itens_estoque  
DROP POLICY IF EXISTS "Users can manage inventory items in their company" ON itens_estoque;
DROP POLICY IF EXISTS "Users can manage their company inventory" ON itens_estoque;

-- Drop all policies on empresas
DROP POLICY IF EXISTS "Policy_empresas" ON empresas;
DROP POLICY IF EXISTS "Users can create companies" ON empresas;
DROP POLICY IF EXISTS "Users can manage their own company" ON empresas;

-- Drop all policies on servicos
DROP POLICY IF EXISTS "Users can manage services in their company" ON servicos;
DROP POLICY IF EXISTS "Users can manage their company services" ON servicos;

-- Drop all policies on tecnicos
DROP POLICY IF EXISTS "Users can manage technicians in their company" ON tecnicos;
DROP POLICY IF EXISTS "Users can manage their company technicians" ON tecnicos;

-- Create security definer function to get user's company ID safely
CREATE OR REPLACE FUNCTION public.get_user_empresa_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT empresa_id FROM public.profiles WHERE id = auth.uid();
$$;

-- Create unified RLS policies using the security definer function

-- Categorias Financeiras - single unified policy
CREATE POLICY "Company financial categories access"
ON categorias_financeiras
FOR ALL
USING (empresa_id = public.get_user_empresa_id())
WITH CHECK (empresa_id = public.get_user_empresa_id());

-- Itens Estoque - single unified policy  
CREATE POLICY "Company inventory access"
ON itens_estoque
FOR ALL
USING (empresa_id = public.get_user_empresa_id())
WITH CHECK (empresa_id = public.get_user_empresa_id());

-- Empresas - allow users to manage only their own company
CREATE POLICY "Company management access"
ON empresas
FOR ALL
USING (id = public.get_user_empresa_id())
WITH CHECK (id = public.get_user_empresa_id());

-- Servicos - single unified policy
CREATE POLICY "Company services access"
ON servicos  
FOR ALL
USING (empresa_id = public.get_user_empresa_id())
WITH CHECK (empresa_id = public.get_user_empresa_id());

-- Tecnicos - single unified policy
CREATE POLICY "Company technicians access"
ON tecnicos
FOR ALL  
USING (empresa_id = public.get_user_empresa_id())
WITH CHECK (empresa_id = public.get_user_empresa_id());