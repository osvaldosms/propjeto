-- Fix security warnings and continue with Phase 2

-- Fix function search path issue
CREATE OR REPLACE FUNCTION public.get_user_empresa_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = 'public'
AS $$
  SELECT empresa_id FROM public.profiles WHERE id = auth.uid();
$$;

-- Fix all existing functions to have proper search path
CREATE OR REPLACE FUNCTION public.calcular_subtotal_servico()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  NEW.subtotal = NEW.valor * NEW.quantidade;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.calcular_subtotal_peca()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  NEW.subtotal = NEW.valor * NEW.quantidade;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.calcular_totais_os()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Calcular total de serviços
  UPDATE public.ordens_servico 
  SET total_servicos = (
    SELECT COALESCE(SUM(valor * quantidade), 0) 
    FROM public.servicos_os 
    WHERE ordem_servico_id = NEW.ordem_servico_id
  )
  WHERE id = NEW.ordem_servico_id;
  
  -- Calcular total de peças
  UPDATE public.ordens_servico 
  SET total_pecas = (
    SELECT COALESCE(SUM(valor * quantidade), 0) 
    FROM public.pecas_os 
    WHERE ordem_servico_id = NEW.ordem_servico_id
  )
  WHERE id = NEW.ordem_servico_id;
  
  -- Calcular total geral considerando descontos e taxas
  UPDATE public.ordens_servico 
  SET total_geral = (
    (total_servicos + total_pecas) - 
    CASE 
      WHEN COALESCE(desconto_percentual, 0) > 0 THEN 
        (total_servicos + total_pecas) * (COALESCE(desconto_percentual, 0) / 100)
      ELSE 
        COALESCE(desconto_valor, 0)
    END + 
    COALESCE(taxa_entrega, 0) + 
    COALESCE(outras_taxas, 0)
  )
  WHERE id = NEW.ordem_servico_id;
  
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Primeiro criar/obter empresa
  INSERT INTO public.empresas (id, nome, cnpj, created_at)
  VALUES (
    gen_random_uuid(),
    COALESCE(NEW.raw_user_meta_data ->> 'workshop_name', COALESCE(NEW.raw_user_meta_data ->> 'full_name', 'Oficina')),
    COALESCE(NEW.raw_user_meta_data ->> 'cnpj', ''),
    now()
  )
  ON CONFLICT DO NOTHING;
  
  -- Inserir profile ligado à empresa
  INSERT INTO public.profiles (id, nome, empresa_id, perfil, created_at, updated_at)
  SELECT 
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email),
    e.id,
    'admin',
    now(),
    now()
  FROM public.empresas e 
  WHERE e.nome = COALESCE(NEW.raw_user_meta_data ->> 'workshop_name', COALESCE(NEW.raw_user_meta_data ->> 'full_name', 'Oficina'))
  LIMIT 1
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$;

-- Add audit logging for security monitoring
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id),
  empresa_id uuid,
  action text NOT NULL,
  table_name text NOT NULL,
  record_id uuid,
  old_values jsonb,
  new_values jsonb,
  ip_address inet,
  user_agent text,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on audit logs
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Only allow users to view their own company's audit logs
CREATE POLICY "Company audit logs access"
ON audit_logs
FOR SELECT
USING (empresa_id = public.get_user_empresa_id());

-- Create audit trigger function
CREATE OR REPLACE FUNCTION public.audit_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  INSERT INTO public.audit_logs (
    user_id,
    empresa_id, 
    action,
    table_name,
    record_id,
    old_values,
    new_values
  ) VALUES (
    auth.uid(),
    public.get_user_empresa_id(),
    TG_OP,
    TG_TABLE_NAME,
    CASE WHEN TG_OP = 'DELETE' THEN OLD.id ELSE NEW.id END,
    CASE WHEN TG_OP IN ('UPDATE', 'DELETE') THEN row_to_json(OLD) ELSE NULL END,
    CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN row_to_json(NEW) ELSE NULL END
  );
  
  RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$;