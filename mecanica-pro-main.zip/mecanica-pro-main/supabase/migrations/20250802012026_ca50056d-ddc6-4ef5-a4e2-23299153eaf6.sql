-- CRITICAL SECURITY FIXES - Phase 1: RLS Corrections

-- Re-enable RLS on critical tables that were disabled
ALTER TABLE public.clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.veiculos ENABLE ROW LEVEL SECURITY;

-- Drop existing conflicting policies on clientes
DROP POLICY IF EXISTS "Policy_clientes" ON public.clientes;
DROP POLICY IF EXISTS "Só pode deletar clientes da sua empresa" ON public.clientes;
DROP POLICY IF EXISTS "Só pode editar clientes da sua empresa" ON public.clientes;
DROP POLICY IF EXISTS "Só pode inserir clientes na sua empresa" ON public.clientes;
DROP POLICY IF EXISTS "Só pode ver clientes da sua empresa" ON public.clientes;

-- Drop existing conflicting policies on veiculos
DROP POLICY IF EXISTS "Policy_veiculos" ON public.veiculos;

-- Create standardized RLS policies for clientes using get_user_empresa_id()
CREATE POLICY "Company clients access" 
ON public.clientes 
FOR ALL 
USING (empresa_id = get_user_empresa_id())
WITH CHECK (empresa_id = get_user_empresa_id());

-- Create standardized RLS policies for veiculos using get_user_empresa_id()
CREATE POLICY "Company vehicles access" 
ON public.veiculos 
FOR ALL 
USING (empresa_id = get_user_empresa_id())
WITH CHECK (empresa_id = get_user_empresa_id());

-- Standardize agendamentos policies (drop old and recreate)
DROP POLICY IF EXISTS "Users can manage appointments in their company" ON public.agendamentos;

CREATE POLICY "Company appointments access" 
ON public.agendamentos 
FOR ALL 
USING (empresa_id = get_user_empresa_id())
WITH CHECK (empresa_id = get_user_empresa_id());

-- Standardize transacoes_financeiras policies
DROP POLICY IF EXISTS "Users can manage financial transactions in their company" ON public.transacoes_financeiras;

CREATE POLICY "Company financial transactions access" 
ON public.transacoes_financeiras 
FOR ALL 
USING (empresa_id = get_user_empresa_id())
WITH CHECK (empresa_id = get_user_empresa_id());

-- Standardize anexos_os policies
DROP POLICY IF EXISTS "Users can manage attachments in their company orders" ON public.anexos_os;

CREATE POLICY "Company order attachments access" 
ON public.anexos_os 
FOR ALL 
USING (empresa_id = get_user_empresa_id())
WITH CHECK (empresa_id = get_user_empresa_id());

-- Fix ordens_servico policies (drop old and recreate with consistent naming)
DROP POLICY IF EXISTS "Policy_ordens_servico" ON public.ordens_servico;

CREATE POLICY "Company service orders access" 
ON public.ordens_servico 
FOR ALL 
USING (empresa_id = get_user_empresa_id())
WITH CHECK (empresa_id = get_user_empresa_id());

-- Add validation triggers for critical data integrity
CREATE OR REPLACE FUNCTION public.validate_cliente_data()
RETURNS TRIGGER AS $$
BEGIN
  -- Ensure nome is not empty after trimming
  IF trim(NEW.nome) = '' THEN
    RAISE EXCEPTION 'Nome do cliente não pode estar vazio';
  END IF;
  
  -- Validate email format if provided
  IF NEW.email IS NOT NULL AND NEW.email != '' THEN
    IF NEW.email !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
      RAISE EXCEPTION 'Formato de email inválido';
    END IF;
  END IF;
  
  -- Ensure empresa_id is set
  IF NEW.empresa_id IS NULL THEN
    NEW.empresa_id = get_user_empresa_id();
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.validate_veiculo_data()
RETURNS TRIGGER AS $$
BEGIN
  -- Ensure required fields are not empty
  IF trim(COALESCE(NEW.marca, '')) = '' THEN
    RAISE EXCEPTION 'Marca do veículo é obrigatória';
  END IF;
  
  IF trim(COALESCE(NEW.modelo, '')) = '' THEN
    RAISE EXCEPTION 'Modelo do veículo é obrigatório';
  END IF;
  
  -- Validate year if provided
  IF NEW.ano IS NOT NULL THEN
    IF NEW.ano < 1900 OR NEW.ano > EXTRACT(YEAR FROM CURRENT_DATE) + 1 THEN
      RAISE EXCEPTION 'Ano do veículo inválido';
    END IF;
  END IF;
  
  -- Ensure empresa_id is set
  IF NEW.empresa_id IS NULL THEN
    NEW.empresa_id = get_user_empresa_id();
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create validation triggers
CREATE TRIGGER validate_cliente_trigger
  BEFORE INSERT OR UPDATE ON public.clientes
  FOR EACH ROW EXECUTE FUNCTION public.validate_cliente_data();

CREATE TRIGGER validate_veiculo_trigger
  BEFORE INSERT OR UPDATE ON public.veiculos
  FOR EACH ROW EXECUTE FUNCTION public.validate_veiculo_data();