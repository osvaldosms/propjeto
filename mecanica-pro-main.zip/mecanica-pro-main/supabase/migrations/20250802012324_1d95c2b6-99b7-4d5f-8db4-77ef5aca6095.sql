-- Fix security warnings - Function search paths

-- Update validation functions with proper search_path
CREATE OR REPLACE FUNCTION public.validate_cliente_data()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Ensure nome is not empty after trimming
  IF trim(NEW.nome) = '' THEN
    RAISE EXCEPTION 'Nome do cliente não pode estar vazio';
  END IF;
  
  -- Validate email format if provided
  IF NEW.email IS NOT NULL AND NEW.email != '' THEN
    IF NEW.email !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
      RAISE EXCEPTION 'Formato de email inválido';
    END IF;
  END IF;
  
  -- Ensure empresa_id is set
  IF NEW.empresa_id IS NULL THEN
    NEW.empresa_id = public.get_user_empresa_id();
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.validate_veiculo_data()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Ensure required fields are not empty
  IF trim(COALESCE(NEW.marca, '')) = '' THEN
    RAISE EXCEPTION 'Marca do veículo é obrigatória';
  END IF;
  
  IF trim(COALESCE(NEW.modelo, '')) = '' THEN
    RAISE EXCEPTION 'Modelo do veículo é obrigatório';
  END IF;
  
  -- Validate year if provided
  IF NEW.ano IS NOT NULL THEN
    IF NEW.ano < 1900 OR NEW.ano > EXTRACT(YEAR FROM CURRENT_DATE) + 1 THEN
      RAISE EXCEPTION 'Ano do veículo inválido';
    END IF;
  END IF;
  
  -- Ensure empresa_id is set
  IF NEW.empresa_id IS NULL THEN
    NEW.empresa_id = public.get_user_empresa_id();
  END IF;
  
  RETURN NEW;
END;
$$;