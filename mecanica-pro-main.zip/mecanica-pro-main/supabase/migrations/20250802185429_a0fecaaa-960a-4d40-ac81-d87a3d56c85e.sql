-- Adicionar campos para controle de acesso e trial na tabela subscribers
ALTER TABLE public.subscribers 
ADD COLUMN IF NOT EXISTS trial_start TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS trial_end TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS is_trial BOOLEAN DEFAULT true;

-- Adicionar tabela de configurações da empresa
CREATE TABLE IF NOT EXISTS public.empresa_configuracoes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id UUID NOT NULL REFERENCES public.empresas(id) ON DELETE CASCADE,
  nome_oficina TEXT,
  logomarca_url TEXT,
  cnpj_cpf TEXT,
  endereco_completo TEXT,
  telefone TEXT,
  email TEXT,
  whatsapp TEXT,
  instagram TEXT,
  facebook TEXT,
  responsavel_tecnico TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(empresa_id)
);

-- Enable RLS na tabela empresa_configuracoes
ALTER TABLE public.empresa_configuracoes ENABLE ROW LEVEL SECURITY;

-- Policy para empresa_configuracoes
CREATE POLICY "Company settings access" ON public.empresa_configuracoes
FOR ALL
USING (empresa_id = get_user_empresa_id())
WITH CHECK (empresa_id = get_user_empresa_id());

-- Trigger para updated_at
CREATE TRIGGER update_empresa_configuracoes_updated_at
  BEFORE UPDATE ON public.empresa_configuracoes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Função para verificar se usuário tem acesso a um recurso baseado no plano
CREATE OR REPLACE FUNCTION public.check_plan_access(required_plan TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
DECLARE
  user_subscription RECORD;
  current_plan TEXT;
  is_trial_expired BOOLEAN DEFAULT FALSE;
BEGIN
  -- Buscar informações de assinatura do usuário
  SELECT s.*, p.email
  INTO user_subscription
  FROM public.subscribers s
  JOIN public.profiles p ON p.id = auth.uid()
  WHERE s.email = p.email OR s.user_id = auth.uid()
  LIMIT 1;
  
  -- Se não encontrou assinatura, criar trial
  IF user_subscription IS NULL THEN
    INSERT INTO public.subscribers (
      user_id,
      email,
      subscribed,
      subscription_tier,
      is_trial,
      trial_start,
      trial_end
    )
    SELECT 
      auth.uid(),
      p.email,
      false,
      'trial',
      true,
      now(),
      now() + INTERVAL '14 days'
    FROM public.profiles p
    WHERE p.id = auth.uid()
    ON CONFLICT (email) DO NOTHING;
    
    current_plan := 'trial';
    is_trial_expired := FALSE;
  ELSE
    current_plan := COALESCE(user_subscription.subscription_tier, 'trial');
    
    -- Verificar se trial expirou
    IF user_subscription.is_trial = true AND user_subscription.trial_end < now() THEN
      is_trial_expired := TRUE;
      current_plan := 'expired';
    END IF;
  END IF;
  
  -- Verificar acesso baseado no plano
  CASE required_plan
    WHEN 'trial' THEN
      RETURN current_plan IN ('trial', 'essencial', 'profissional', 'premium') AND NOT is_trial_expired;
    WHEN 'essencial' THEN
      RETURN current_plan IN ('essencial', 'profissional', 'premium');
    WHEN 'profissional' THEN
      RETURN current_plan IN ('profissional', 'premium');
    WHEN 'premium' THEN
      RETURN current_plan = 'premium';
    ELSE
      RETURN FALSE;
  END CASE;
END;
$$;

-- Função para obter informações do plano do usuário
CREATE OR REPLACE FUNCTION public.get_user_plan_info()
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
DECLARE
  user_subscription RECORD;
  result JSON;
BEGIN
  -- Buscar informações de assinatura do usuário
  SELECT s.*, p.email
  INTO user_subscription
  FROM public.subscribers s
  JOIN public.profiles p ON p.id = auth.uid()
  WHERE s.email = p.email OR s.user_id = auth.uid()
  LIMIT 1;
  
  -- Se não encontrou assinatura, é trial
  IF user_subscription IS NULL THEN
    result := json_build_object(
      'plan', 'trial',
      'is_trial', true,
      'trial_expired', false,
      'trial_days_left', 14,
      'subscribed', false
    );
  ELSE
    result := json_build_object(
      'plan', COALESCE(user_subscription.subscription_tier, 'trial'),
      'is_trial', COALESCE(user_subscription.is_trial, true),
      'trial_expired', user_subscription.is_trial = true AND user_subscription.trial_end < now(),
      'trial_days_left', 
        CASE 
          WHEN user_subscription.is_trial = true AND user_subscription.trial_end > now() THEN
            EXTRACT(days FROM user_subscription.trial_end - now())::integer
          ELSE 0
        END,
      'subscribed', COALESCE(user_subscription.subscribed, false),
      'subscription_end', user_subscription.subscription_end
    );
  END IF;
  
  RETURN result;
END;
$$;

-- Atualizar subscribers existentes para incluir trial para usuários sem assinatura
UPDATE public.subscribers 
SET 
  is_trial = true,
  trial_start = COALESCE(trial_start, created_at),
  trial_end = COALESCE(trial_end, created_at + INTERVAL '14 days'),
  subscription_tier = COALESCE(subscription_tier, 'trial')
WHERE subscription_tier IS NULL OR subscription_tier = '';

-- RLS policies com restrições baseadas em planos

-- Restringir transações financeiras para plano essencial ou superior
DROP POLICY IF EXISTS "Company financial transactions access" ON public.transacoes_financeiras;
CREATE POLICY "Company financial transactions access" ON public.transacoes_financeiras
FOR ALL
USING (empresa_id = get_user_empresa_id() AND check_plan_access('profissional'))
WITH CHECK (empresa_id = get_user_empresa_id() AND check_plan_access('profissional'));

-- Restringir estoque para plano profissional ou superior  
DROP POLICY IF EXISTS "Company inventory access" ON public.itens_estoque;
CREATE POLICY "Company inventory access" ON public.itens_estoque
FOR ALL
USING (empresa_id = get_user_empresa_id() AND check_plan_access('profissional'))
WITH CHECK (empresa_id = get_user_empresa_id() AND check_plan_access('profissional'));

-- Limitar criação de ordens de serviço no trial (máximo 5)
CREATE OR REPLACE FUNCTION public.check_trial_os_limit()
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  plan_info JSON;
  os_count INTEGER;
BEGIN
  plan_info := get_user_plan_info();
  
  -- Se não é trial, libera
  IF (plan_info->>'is_trial')::boolean = false THEN
    RETURN true;
  END IF;
  
  -- Se trial expirou, bloqueia
  IF (plan_info->>'trial_expired')::boolean = true THEN
    RETURN false;
  END IF;
  
  -- Contar ordens de serviço da empresa
  SELECT COUNT(*)
  INTO os_count
  FROM public.ordens_servico
  WHERE empresa_id = get_user_empresa_id();
  
  -- Limitar a 5 OS no trial
  RETURN os_count < 5;
END;
$$;

-- Policy para ordens de serviço com limite no trial
DROP POLICY IF EXISTS "Company service orders access" ON public.ordens_servico;
CREATE POLICY "Company service orders access" ON public.ordens_servico
FOR SELECT
USING (empresa_id = get_user_empresa_id() AND check_plan_access('trial'));

CREATE POLICY "Company service orders insert" ON public.ordens_servico
FOR INSERT
WITH CHECK (empresa_id = get_user_empresa_id() AND check_plan_access('trial') AND check_trial_os_limit());

CREATE POLICY "Company service orders update" ON public.ordens_servico
FOR UPDATE
USING (empresa_id = get_user_empresa_id() AND check_plan_access('trial'));

CREATE POLICY "Company service orders delete" ON public.ordens_servico
FOR DELETE
USING (empresa_id = get_user_empresa_id() AND check_plan_access('essencial'));