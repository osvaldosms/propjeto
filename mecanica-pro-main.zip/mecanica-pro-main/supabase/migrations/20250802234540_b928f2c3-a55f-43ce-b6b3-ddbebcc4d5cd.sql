-- Create subscribers table for plan management
CREATE TABLE public.subscribers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  subscribed BOOLEAN NOT NULL DEFAULT false,
  subscription_tier TEXT DEFAULT 'trial',
  subscription_id TEXT,
  customer_id TEXT,
  subscription_end TIMESTAMP WITH TIME ZONE,
  is_trial BOOLEAN DEFAULT true,
  trial_start TIMESTAMP WITH TIME ZONE DEFAULT now(),
  trial_end TIMESTAMP WITH TIME ZONE DEFAULT now() + INTERVAL '14 days',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.subscribers ENABLE ROW LEVEL SECURITY;

-- Create proper RLS policies
CREATE POLICY "Users can view their own subscription" 
ON public.subscribers 
FOR SELECT 
USING (user_id = auth.uid() OR email = (SELECT email FROM auth.users WHERE id = auth.uid()));

CREATE POLICY "Users can update their own subscription" 
ON public.subscribers 
FOR UPDATE 
USING (user_id = auth.uid() OR email = (SELECT email FROM auth.users WHERE id = auth.uid()));

CREATE POLICY "Users can insert their own subscription" 
ON public.subscribers 
FOR INSERT 
WITH CHECK (user_id = auth.uid() OR email = (SELECT email FROM auth.users WHERE id = auth.uid()));

-- Fix database functions with proper search_path
CREATE OR REPLACE FUNCTION public.get_user_plan_info()
RETURNS json
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  user_subscription RECORD;
  result JSON;
BEGIN
  -- Buscar informações de assinatura do usuário
  SELECT s.*, p.email
  INTO user_subscription
  FROM public.subscribers s
  JOIN public.profiles p ON p.id = auth.uid()
  WHERE s.email = p.email OR s.user_id = auth.uid()
  LIMIT 1;
  
  -- Se não encontrou assinatura, é trial
  IF user_subscription IS NULL THEN
    result := json_build_object(
      'plan', 'trial',
      'is_trial', true,
      'trial_expired', false,
      'trial_days_left', 14,
      'subscribed', false
    );
  ELSE
    result := json_build_object(
      'plan', COALESCE(user_subscription.subscription_tier, 'trial'),
      'is_trial', COALESCE(user_subscription.is_trial, true),
      'trial_expired', user_subscription.is_trial = true AND user_subscription.trial_end < now(),
      'trial_days_left', 
        CASE 
          WHEN user_subscription.is_trial = true AND user_subscription.trial_end > now() THEN
            EXTRACT(days FROM user_subscription.trial_end - now())::integer
          ELSE 0
        END,
      'subscribed', COALESCE(user_subscription.subscribed, false),
      'subscription_end', user_subscription.subscription_end
    );
  END IF;
  
  RETURN result;
END;
$function$;

CREATE OR REPLACE FUNCTION public.check_plan_access(required_plan text)
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  user_subscription RECORD;
  current_plan TEXT;
  is_trial_expired BOOLEAN DEFAULT FALSE;
BEGIN
  -- Buscar informações de assinatura do usuário
  SELECT s.*, p.email
  INTO user_subscription
  FROM public.subscribers s
  JOIN public.profiles p ON p.id = auth.uid()
  WHERE s.email = p.email OR s.user_id = auth.uid()
  LIMIT 1;
  
  -- Se não encontrou assinatura, criar trial
  IF user_subscription IS NULL THEN
    INSERT INTO public.subscribers (
      user_id,
      email,
      subscribed,
      subscription_tier,
      is_trial,
      trial_start,
      trial_end
    )
    SELECT 
      auth.uid(),
      p.email,
      false,
      'trial',
      true,
      now(),
      now() + INTERVAL '14 days'
    FROM public.profiles p
    WHERE p.id = auth.uid()
    ON CONFLICT (email) DO NOTHING;
    
    current_plan := 'trial';
    is_trial_expired := FALSE;
  ELSE
    current_plan := COALESCE(user_subscription.subscription_tier, 'trial');
    
    -- Verificar se trial expirou
    IF user_subscription.is_trial = true AND user_subscription.trial_end < now() THEN
      is_trial_expired := TRUE;
      current_plan := 'expired';
    END IF;
  END IF;
  
  -- Verificar acesso baseado no plano
  CASE required_plan
    WHEN 'trial' THEN
      RETURN current_plan IN ('trial', 'essencial', 'profissional', 'premium') AND NOT is_trial_expired;
    WHEN 'essencial' THEN
      RETURN current_plan IN ('essencial', 'profissional', 'premium');
    WHEN 'profissional' THEN
      RETURN current_plan IN ('profissional', 'premium');
    WHEN 'premium' THEN
      RETURN current_plan = 'premium';
    ELSE
      RETURN FALSE;
  END CASE;
END;
$function$;

CREATE OR REPLACE FUNCTION public.check_trial_os_limit()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  plan_info JSON;
  os_count INTEGER;
BEGIN
  plan_info := public.get_user_plan_info();
  
  -- Se não é trial, libera
  IF (plan_info->>'is_trial')::boolean = false THEN
    RETURN true;
  END IF;
  
  -- Se trial expirou, bloqueia
  IF (plan_info->>'trial_expired')::boolean = true THEN
    RETURN false;
  END IF;
  
  -- Contar ordens de serviço da empresa
  SELECT COUNT(*)
  INTO os_count
  FROM public.ordens_servico
  WHERE empresa_id = public.get_user_empresa_id();
  
  -- Limitar a 5 OS no trial
  RETURN os_count < 5;
END;
$function$;

-- Add updated_at trigger for subscribers
CREATE TRIGGER update_subscribers_updated_at
BEFORE UPDATE ON public.subscribers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create empresa_configuracoes table for company settings
CREATE TABLE public.empresa_configuracoes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  empresa_id UUID NOT NULL REFERENCES public.empresas(id) ON DELETE CASCADE,
  configuracao JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(empresa_id)
);

-- Enable RLS for empresa_configuracoes
ALTER TABLE public.empresa_configuracoes ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for empresa_configuracoes
CREATE POLICY "Só vê/edita configurações da própria empresa" 
ON public.empresa_configuracoes 
FOR ALL 
USING (empresa_id = (SELECT profiles.empresa_id FROM profiles WHERE profiles.id = auth.uid()));

-- Add updated_at trigger for empresa_configuracoes
CREATE TRIGGER update_empresa_configuracoes_updated_at
BEFORE UPDATE ON public.empresa_configuracoes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();