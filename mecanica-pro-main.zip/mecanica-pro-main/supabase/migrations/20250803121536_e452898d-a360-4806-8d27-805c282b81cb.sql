-- Fix existing database functions with proper search_path
CREATE OR REPLACE FUNCTION public.get_user_plan_info()
RETURNS json
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  user_subscription RECORD;
  result JSON;
BEGIN
  -- Buscar informações de assinatura do usuário
  SELECT s.*, p.email
  INTO user_subscription
  FROM public.subscribers s
  JOIN public.profiles p ON p.id = auth.uid()
  WHERE s.email = p.email OR s.user_id = auth.uid()
  LIMIT 1;
  
  -- Se não encontrou assinatura, é trial
  IF user_subscription IS NULL THEN
    result := json_build_object(
      'plan', 'trial',
      'is_trial', true,
      'trial_expired', false,
      'trial_days_left', 14,
      'subscribed', false
    );
  ELSE
    result := json_build_object(
      'plan', COALESCE(user_subscription.subscription_tier, 'trial'),
      'is_trial', COALESCE(user_subscription.is_trial, true),
      'trial_expired', user_subscription.is_trial = true AND user_subscription.trial_end < now(),
      'trial_days_left', 
        CASE 
          WHEN user_subscription.is_trial = true AND user_subscription.trial_end > now() THEN
            EXTRACT(days FROM user_subscription.trial_end - now())::integer
          ELSE 0
        END,
      'subscribed', COALESCE(user_subscription.subscribed, false),
      'subscription_end', user_subscription.subscription_end
    );
  END IF;
  
  RETURN result;
END;
$function$;

CREATE OR REPLACE FUNCTION public.check_plan_access(required_plan text)
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  user_subscription RECORD;
  current_plan TEXT;
  is_trial_expired BOOLEAN DEFAULT FALSE;
BEGIN
  -- Buscar informações de assinatura do usuário
  SELECT s.*, p.email
  INTO user_subscription
  FROM public.subscribers s
  JOIN public.profiles p ON p.id = auth.uid()
  WHERE s.email = p.email OR s.user_id = auth.uid()
  LIMIT 1;
  
  -- Se não encontrou assinatura, criar trial
  IF user_subscription IS NULL THEN
    INSERT INTO public.subscribers (
      user_id,
      email,
      subscribed,
      subscription_tier,
      is_trial,
      trial_start,
      trial_end
    )
    SELECT 
      auth.uid(),
      p.email,
      false,
      'trial',
      true,
      now(),
      now() + INTERVAL '14 days'
    FROM public.profiles p
    WHERE p.id = auth.uid()
    ON CONFLICT (email) DO NOTHING;
    
    current_plan := 'trial';
    is_trial_expired := FALSE;
  ELSE
    current_plan := COALESCE(user_subscription.subscription_tier, 'trial');
    
    -- Verificar se trial expirou
    IF user_subscription.is_trial = true AND user_subscription.trial_end < now() THEN
      is_trial_expired := TRUE;
      current_plan := 'expired';
    END IF;
  END IF;
  
  -- Verificar acesso baseado no plano
  CASE required_plan
    WHEN 'trial' THEN
      RETURN current_plan IN ('trial', 'essencial', 'profissional', 'premium') AND NOT is_trial_expired;
    WHEN 'essencial' THEN
      RETURN current_plan IN ('essencial', 'profissional', 'premium');
    WHEN 'profissional' THEN
      RETURN current_plan IN ('profissional', 'premium');
    WHEN 'premium' THEN
      RETURN current_plan = 'premium';
    ELSE
      RETURN FALSE;
  END CASE;
END;
$function$;

CREATE OR REPLACE FUNCTION public.check_trial_os_limit()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  plan_info JSON;
  os_count INTEGER;
BEGIN
  plan_info := public.get_user_plan_info();
  
  -- Se não é trial, libera
  IF (plan_info->>'is_trial')::boolean = false THEN
    RETURN true;
  END IF;
  
  -- Se trial expirou, bloqueia
  IF (plan_info->>'trial_expired')::boolean = true THEN
    RETURN false;
  END IF;
  
  -- Contar ordens de serviço da empresa
  SELECT COUNT(*)
  INTO os_count
  FROM public.ordens_servico
  WHERE empresa_id = public.get_user_empresa_id();
  
  -- Limitar a 5 OS no trial
  RETURN os_count < 5;
END;
$function$;

-- Add missing search_path to existing functions
CREATE OR REPLACE FUNCTION public.calcular_subtotal_servico()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  NEW.subtotal = NEW.valor * NEW.quantidade;
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.calcular_subtotal_peca()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  NEW.subtotal = NEW.valor * NEW.quantidade;
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.calcular_totais_os()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  -- Calcular total de serviços
  UPDATE public.ordens_servico 
  SET total_servicos = (
    SELECT COALESCE(SUM(valor * quantidade), 0) 
    FROM public.servicos_os 
    WHERE ordem_servico_id = NEW.ordem_servico_id
  )
  WHERE id = NEW.ordem_servico_id;
  
  -- Calcular total de peças
  UPDATE public.ordens_servico 
  SET total_pecas = (
    SELECT COALESCE(SUM(valor * quantidade), 0) 
    FROM public.pecas_os 
    WHERE ordem_servico_id = NEW.ordem_servico_id
  )
  WHERE id = NEW.ordem_servico_id;
  
  -- Calcular total geral considerando descontos e taxas
  UPDATE public.ordens_servico 
  SET total_geral = (
    (total_servicos + total_pecas) - 
    CASE 
      WHEN COALESCE(desconto_percentual, 0) > 0 THEN 
        (total_servicos + total_pecas) * (COALESCE(desconto_percentual, 0) / 100)
      ELSE 
        COALESCE(desconto_valor, 0)
    END + 
    COALESCE(taxa_entrega, 0) + 
    COALESCE(outras_taxas, 0)
  )
  WHERE id = NEW.ordem_servico_id;
  
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.get_user_empresa_id()
RETURNS uuid
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = 'public'
AS $function$
  SELECT empresa_id FROM public.profiles WHERE id = auth.uid();
$function$;

CREATE OR REPLACE FUNCTION public.audit_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  INSERT INTO public.audit_logs (
    user_id,
    empresa_id, 
    action,
    table_name,
    record_id,
    old_values,
    new_values
  ) VALUES (
    auth.uid(),
    public.get_user_empresa_id(),
    TG_OP,
    TG_TABLE_NAME,
    CASE WHEN TG_OP = 'DELETE' THEN OLD.id ELSE NEW.id END,
    CASE WHEN TG_OP IN ('UPDATE', 'DELETE') THEN row_to_json(OLD) ELSE NULL END,
    CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN row_to_json(NEW) ELSE NULL END
  );
  
  RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$function$;

CREATE OR REPLACE FUNCTION public.validate_cliente_data()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  -- Ensure nome is not empty after trimming
  IF trim(NEW.nome) = '' THEN
    RAISE EXCEPTION 'Nome do cliente não pode estar vazio';
  END IF;
  
  -- Validate email format if provided
  IF NEW.email IS NOT NULL AND NEW.email != '' THEN
    IF NEW.email !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
      RAISE EXCEPTION 'Formato de email inválido';
    END IF;
  END IF;
  
  -- Ensure empresa_id is set
  IF NEW.empresa_id IS NULL THEN
    NEW.empresa_id = public.get_user_empresa_id();
  END IF;
  
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.validate_veiculo_data()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  -- Ensure required fields are not empty
  IF trim(COALESCE(NEW.marca, '')) = '' THEN
    RAISE EXCEPTION 'Marca do veículo é obrigatória';
  END IF;
  
  IF trim(COALESCE(NEW.modelo, '')) = '' THEN
    RAISE EXCEPTION 'Modelo do veículo é obrigatório';
  END IF;
  
  -- Validate year if provided
  IF NEW.ano IS NOT NULL THEN
    IF NEW.ano < 1900 OR NEW.ano > EXTRACT(YEAR FROM CURRENT_DATE) + 1 THEN
      RAISE EXCEPTION 'Ano do veículo inválido';
    END IF;
  END IF;
  
  -- Ensure empresa_id is set
  IF NEW.empresa_id IS NULL THEN
    NEW.empresa_id = public.get_user_empresa_id();
  END IF;
  
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  -- Primeiro criar/obter empresa
  INSERT INTO public.empresas (id, nome, cnpj, created_at)
  VALUES (
    gen_random_uuid(),
    COALESCE(NEW.raw_user_meta_data ->> 'workshop_name', COALESCE(NEW.raw_user_meta_data ->> 'full_name', 'Oficina')),
    COALESCE(NEW.raw_user_meta_data ->> 'cnpj', ''),
    now()
  )
  ON CONFLICT DO NOTHING;
  
  -- Inserir profile ligado à empresa
  INSERT INTO public.profiles (id, nome, empresa_id, perfil, created_at, updated_at)
  SELECT 
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email),
    e.id,
    'admin',
    now(),
    now()
  FROM public.empresas e 
  WHERE e.nome = COALESCE(NEW.raw_user_meta_data ->> 'workshop_name', COALESCE(NEW.raw_user_meta_data ->> 'full_name', 'Oficina'))
  LIMIT 1
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$function$;