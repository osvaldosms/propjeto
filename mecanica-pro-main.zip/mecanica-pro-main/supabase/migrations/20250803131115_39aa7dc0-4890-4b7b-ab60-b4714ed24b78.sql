-- Create the missing trigger to automatically create profiles and empresas when users sign up
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Fix existing users who don't have profiles entries
-- This will create missing empresas and profiles for any existing auth users
INSERT INTO public.empresas (id, nome, cnpj, created_at)
SELECT 
  gen_random_uuid(),
  COALESCE(au.raw_user_meta_data ->> 'workshop_name', COALESCE(au.raw_user_meta_data ->> 'full_name', 'Oficina')),
  COALESCE(au.raw_user_meta_data ->> 'cnpj', ''),
  now()
FROM auth.users au
LEFT JOIN public.profiles p ON p.id = au.id
WHERE p.id IS NULL
ON CONFLICT DO NOTHING;

-- Create missing profiles for existing users
INSERT INTO public.profiles (id, nome, empresa_id, perfil, created_at, updated_at)
SELECT DISTINCT
  au.id,
  COALESCE(au.raw_user_meta_data ->> 'full_name', au.email),
  e.id,
  'admin',
  now(),
  now()
FROM auth.users au
LEFT JOIN public.profiles p ON p.id = au.id
JOIN public.empresas e ON e.nome = COALESCE(au.raw_user_meta_data ->> 'workshop_name', COALESCE(au.raw_user_meta_data ->> 'full_name', 'Oficina'))
WHERE p.id IS NULL
ON CONFLICT (id) DO NOTHING;