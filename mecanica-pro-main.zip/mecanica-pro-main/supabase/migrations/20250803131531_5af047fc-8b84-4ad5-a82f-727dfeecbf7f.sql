-- Primeiro, criar empresas para usuários que não têm profiles
INSERT INTO public.empresas (id, nome, cnpj, created_at)
SELECT 
  gen_random_uuid(),
  COALESCE(au.raw_user_meta_data ->> 'workshop_name', COALESCE(au.raw_user_meta_data ->> 'full_name', 'Oficina')),
  COALESCE(au.raw_user_meta_data ->> 'cnpj', ''),
  au.created_at
FROM auth.users au
LEFT JOIN public.profiles p ON p.id = au.id
WHERE p.id IS NULL;

-- Depois, criar profiles para todos os usuários que não têm
INSERT INTO public.profiles (id, nome, empresa_id, perfil, created_at, updated_at)
SELECT DISTINCT
  au.id,
  COALESCE(au.raw_user_meta_data ->> 'full_name', au.email),
  e.id,
  'admin',
  au.created_at,
  au.created_at
FROM auth.users au
LEFT JOIN public.profiles p ON p.id = au.id
JOIN public.empresas e ON e.nome = COALESCE(au.raw_user_meta_data ->> 'workshop_name', COALESCE(au.raw_user_meta_data ->> 'full_name', 'Oficina'))
WHERE p.id IS NULL
ON CONFLICT (id) DO NOTHING;