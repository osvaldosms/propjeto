-- Corrigir função handle_new_user para incluir email no profile
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  empresa_uuid UUID;
  workshop_name TEXT;
  email_address TEXT;
BEGIN
  -- Extrair dados dos metadados
  workshop_name := COALESCE(
    NEW.raw_user_meta_data ->> 'workshop_name',
    NEW.raw_user_meta_data ->> 'full_name',
    'Oficina'
  );
  
  -- Extrair email corretamente
  email_address := COALESCE(
    NEW.raw_user_meta_data ->> 'email',
    NEW.email
  );
  
  -- Log para debug
  RAISE LOG 'Creating user: email=%, workshop=%', email_address, workshop_name;
  
  -- Primeiro criar/obter empresa
  INSERT INTO public.empresas (
    id, 
    nome, 
    cnpj, 
    email,
    telefone,
    endereco,
    created_at
  )
  VALUES (
    gen_random_uuid(),
    workshop_name,
    COALESCE(NEW.raw_user_meta_data ->> 'cnpj', ''),
    email_address,
    COALESCE(NEW.raw_user_meta_data ->> 'phone', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'address', ''),
    now()
  )
  ON CONFLICT (nome) DO UPDATE SET
    email = EXCLUDED.email,
    telefone = EXCLUDED.telefone,
    endereco = EXCLUDED.endereco
  RETURNING id INTO empresa_uuid;
  
  -- Se não conseguiu inserir, buscar existente
  IF empresa_uuid IS NULL THEN
    SELECT id INTO empresa_uuid 
    FROM public.empresas 
    WHERE nome = workshop_name 
    LIMIT 1;
  END IF;
  
  -- Inserir profile com email
  INSERT INTO public.profiles (
    id, 
    nome, 
    email,
    empresa_id, 
    perfil, 
    created_at, 
    updated_at
  )
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', email_address),
    email_address,
    empresa_uuid,
    'admin',
    now(),
    now()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    nome = EXCLUDED.nome,
    updated_at = now();
  
  RAISE LOG 'User created successfully: id=%, empresa_id=%', NEW.id, empresa_uuid;
  
  RETURN NEW;
END;
$$;

-- Atualizar profiles existentes com email NULL
UPDATE public.profiles 
SET email = auth_users.email 
FROM (
  SELECT id, email 
  FROM auth.users 
  WHERE email IS NOT NULL
) AS auth_users 
WHERE profiles.id = auth_users.id 
AND profiles.email IS NULL;