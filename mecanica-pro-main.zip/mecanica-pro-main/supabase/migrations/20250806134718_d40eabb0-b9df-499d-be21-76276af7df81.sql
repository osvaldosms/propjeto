-- Corrigir função handle_new_user para resolver erro de ON CONFLICT
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  empresa_uuid UUID;
  workshop_name TEXT;
  email_address TEXT;
BEGIN
  -- Extrair dados dos metadados
  workshop_name := COALESCE(
    NEW.raw_user_meta_data ->> 'workshop_name',
    NEW.raw_user_meta_data ->> 'full_name',
    'Oficina'
  );
  
  -- Extrair email corretamente
  email_address := COALESCE(
    NEW.raw_user_meta_data ->> 'email',
    NEW.email
  );
  
  -- Log para debug
  RAISE LOG 'Creating user: email=%, workshop=%', email_address, workshop_name;
  
  -- Primeiro criar/obter empresa
  INSERT INTO public.empresas (
    id, 
    nome, 
    cnpj, 
    email,
    telefone,
    endereco,
    created_at
  )
  VALUES (
    gen_random_uuid(),
    workshop_name,
    COALESCE(NEW.raw_user_meta_data ->> 'cnpj', ''),
    email_address,
    COALESCE(NEW.raw_user_meta_data ->> 'phone', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'address', ''),
    now()
  )
  ON CONFLICT (email) DO UPDATE SET
    nome = EXCLUDED.nome,
    telefone = EXCLUDED.telefone,
    endereco = EXCLUDED.endereco,
    updated_at = now()
  RETURNING id INTO empresa_uuid;
  
  -- Se não conseguiu inserir, buscar existente por email
  IF empresa_uuid IS NULL THEN
    SELECT id INTO empresa_uuid 
    FROM public.empresas 
    WHERE email = email_address 
    LIMIT 1;
  END IF;
  
  -- Se ainda não encontrou, criar sem conflito
  IF empresa_uuid IS NULL THEN
    INSERT INTO public.empresas (
      id, 
      nome, 
      cnpj, 
      email,
      telefone,
      endereco,
      created_at
    )
    VALUES (
      gen_random_uuid(),
      workshop_name || '_' || substring(NEW.id::text, 1, 8),
      COALESCE(NEW.raw_user_meta_data ->> 'cnpj', ''),
      email_address,
      COALESCE(NEW.raw_user_meta_data ->> 'phone', ''),
      COALESCE(NEW.raw_user_meta_data ->> 'address', ''),
      now()
    )
    RETURNING id INTO empresa_uuid;
  END IF;
  
  -- Inserir profile
  INSERT INTO public.profiles (
    id, 
    nome, 
    email,
    empresa_id, 
    perfil, 
    created_at, 
    updated_at
  )
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', email_address),
    email_address,
    empresa_uuid,
    'admin',
    now(),
    now()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    nome = EXCLUDED.nome,
    empresa_id = EXCLUDED.empresa_id,
    updated_at = now();
  
  RAISE LOG 'User created successfully: id=%, empresa_id=%', NEW.id, empresa_uuid;
  
  RETURN NEW;
END;
$function$;

-- Verificar se trigger existe e recriar se necessário
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Adicionar constraint única necessária para empresas
ALTER TABLE public.empresas 
ADD CONSTRAINT IF NOT EXISTS empresas_email_unique UNIQUE (email);