-- Create triggers to calculate subtotals and totals for OS items
-- Subtotal for servicos_os
DROP TRIGGER IF EXISTS trg_servicos_os_subtotal_biu ON public.servicos_os;
CREATE TRIGGER trg_servicos_os_subtotal_biu
BEFORE INSERT OR UPDATE ON public.servicos_os
FOR EACH ROW
EXECUTE FUNCTION public.calcular_subtotal_servico();

-- Totals after changes in servicos_os
DROP TRIGGER IF EXISTS trg_servicos_os_totais_aiud ON public.servicos_os;
CREATE TRIGGER trg_servicos_os_totais_aiud
AFTER INSERT OR UPDATE OR DELETE ON public.servicos_os
FOR EACH ROW
EXECUTE FUNCTION public.calcular_totais_os();

-- Subtotal for pecas_os
DROP TRIGGER IF EXISTS trg_pecas_os_subtotal_biu ON public.pecas_os;
CREATE TRIGGER trg_pecas_os_subtotal_biu
BEFORE INSERT OR UPDATE ON public.pecas_os
FOR EACH ROW
EXECUTE FUNCTION public.calcular_subtotal_peca();

-- Totals after changes in pecas_os
DROP TRIGGER IF EXISTS trg_pecas_os_totais_aiud ON public.pecas_os;
CREATE TRIGGER trg_pecas_os_totais_aiud
AFTER INSERT OR UPDATE OR DELETE ON public.pecas_os
FOR EACH ROW
EXECUTE FUNCTION public.calcular_totais_os();
