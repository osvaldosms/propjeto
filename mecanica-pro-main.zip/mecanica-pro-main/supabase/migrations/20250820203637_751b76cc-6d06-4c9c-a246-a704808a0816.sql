-- Corrigir problemas de segurança: definir search_path em funções que não têm

-- Função calcular_subtotal_servico - adicionar search_path 
CREATE OR REPLACE FUNCTION public.calcular_subtotal_servico()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  NEW.subtotal = NEW.valor * NEW.quantidade;
  RETURN NEW;
END;
$function$;

-- Função calcular_subtotal_peca - adicionar search_path
CREATE OR REPLACE FUNCTION public.calcular_subtotal_peca()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  NEW.subtotal = NEW.valor * NEW.quantidade;
  RETURN NEW;
END;
$function$;