-- Veículo pertence a um único cliente (1-N)
ALTER TABLE public.veiculos
  ALTER COLUMN cliente_id SET NOT NULL,
  ADD CONSTRAINT fk_veiculo_cliente
    FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON DELETE RESTRICT;

-- Placa única por empresa (evita o mesmo veículo em clientes diferentes)
CREATE UNIQUE INDEX IF NOT EXISTS ux_veiculo_placa_empresa
ON public.veiculos (empresa_id, lower(placa));

-- (Opcional) Chassi único por empresa, se usarem
-- CREATE UNIQUE INDEX IF NOT EXISTS ux_veiculo_chassi_empresa
-- ON public.veiculos (empresa_id, lower(chassi)) WHERE chassi IS NOT NULL;

-- Garantir integridade na OS (cliente e veículo obrigatórios e coerentes)
ALTER TABLE public.ordens_servico
  ALTER COLUMN cliente_id SET NOT NULL,
  ALTER COLUMN veiculo_id SET NOT NULL,
  ADD CONSTRAINT fk_os_cliente FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON DELETE RESTRICT,
  ADD CONSTRAINT fk_os_veiculo FOREIGN KEY (veiculo_id) REFERENCES public.veiculos(id) ON DELETE RESTRICT;