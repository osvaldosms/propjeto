-- Verificar se constraint fk_veiculo_cliente existe e criar apenas se não existir
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_veiculo_cliente' 
    AND table_name = 'veiculos'
  ) THEN
    ALTER TABLE public.veiculos
      ADD CONSTRAINT fk_veiculo_cliente
        FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON DELETE RESTRICT;
  END IF;
END $$;

-- Garantir que cliente_id não seja nulo em veículos
ALTER TABLE public.veiculos
  ALTER COLUMN cliente_id SET NOT NULL;

-- Placa única por empresa (evita o mesmo veículo em clientes diferentes)
CREATE UNIQUE INDEX IF NOT EXISTS ux_veiculo_placa_empresa
ON public.veiculos (empresa_id, lower(placa));

-- Garantir integridade na OS (cliente e veículo obrigatórios e coerentes)
ALTER TABLE public.ordens_servico
  ALTER COLUMN cliente_id SET NOT NULL,
  ALTER COLUMN veiculo_id SET NOT NULL;

-- Verificar se constraints de OS existem e criar apenas se não existirem
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_os_cliente' 
    AND table_name = 'ordens_servico'
  ) THEN
    ALTER TABLE public.ordens_servico
      ADD CONSTRAINT fk_os_cliente 
        FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON DELETE RESTRICT;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_os_veiculo' 
    AND table_name = 'ordens_servico'
  ) THEN
    ALTER TABLE public.ordens_servico
      ADD CONSTRAINT fk_os_veiculo 
        FOREIGN KEY (veiculo_id) REFERENCES public.veiculos(id) ON DELETE RESTRICT;
  END IF;
END $$;