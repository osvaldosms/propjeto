-- CORREÇÃO CRÍTICA DE SEGURANÇA: Habilitar RLS na tabela audit_logs
-- A tabela audit_logs contém dados sensíveis de auditoria e deve ter RLS habilitado

-- 1. Habilitar Row Level Security na tabela audit_logs
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- 2. Criar política para que usuários vejam apenas logs da própria empresa
-- Usando função de segurança já existente para obter empresa_id do usuário
CREATE POLICY "Usuários veem apenas logs da própria empresa" 
ON public.audit_logs 
FOR SELECT 
USING (
  empresa_id = public.get_user_empresa_id()
);

-- 3. Política para inserção - logs são criados automaticamente pelo trigger
-- Permitir inserção apenas pelo sistema (através do trigger audit_trigger)
CREATE POLICY "Sistema pode inserir logs de auditoria" 
ON public.audit_logs 
FOR INSERT 
WITH CHECK (
  empresa_id = public.get_user_empresa_id()
);

-- 4. Bloquear atualizações e exclusões - logs de auditoria são imutáveis
-- Não criar políticas para UPDATE/DELETE para manter integridade dos logs

-- 5. Garantir que a função get_user_empresa_id() está segura
-- (Esta função já existe e está configurada como SECURITY DEFINER)

-- Comentário: Esta correção garante que:
-- - RLS está habilitado em todas as tabelas públicas
-- - Logs de auditoria são isolados por empresa
-- - Logs são imutáveis (não podem ser alterados/excluídos por usuários)
-- - Apenas o sistema pode inserir logs através do trigger