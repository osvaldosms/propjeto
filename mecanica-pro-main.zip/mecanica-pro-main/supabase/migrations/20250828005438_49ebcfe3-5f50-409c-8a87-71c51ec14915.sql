-- CORREÇÃO CRÍTICA: Resolver erro "updated_at" nas tabelas de Ordem de Serviço

-- Problema identificado: Triggers tentando acessar campo "updated_at" inexistente
-- Solução: Adicionar campo updated_at nas tabelas que precisam ou remover triggers desnecessários

-- 1. Adicionar campo updated_at na tabela ordens_servico
ALTER TABLE public.ordens_servico ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT now();

-- 2. Adicionar campo updated_at na tabela servicos_os  
ALTER TABLE public.servicos_os ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT now();

-- 3. Adicionar campo updated_at na tabela pecas_os
ALTER TABLE public.pecas_os ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT now();

-- 4. Criar triggers para atualizar updated_at automaticamente
CREATE OR REPLACE TRIGGER update_ordens_servico_updated_at
    BEFORE UPDATE ON public.ordens_servico
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE TRIGGER update_servicos_os_updated_at
    BEFORE UPDATE ON public.servicos_os
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE TRIGGER update_pecas_os_updated_at
    BEFORE UPDATE ON public.pecas_os
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- 5. Atualizar registros existentes com timestamp atual
UPDATE public.ordens_servico SET updated_at = now() WHERE updated_at IS NULL;
UPDATE public.servicos_os SET updated_at = now() WHERE updated_at IS NULL;
UPDATE public.pecas_os SET updated_at = now() WHERE updated_at IS NULL;