-- Adicionar coluna updated_at na tabela empresas
ALTER TABLE public.empresas 
ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE DEFAULT now();

-- Atualizar registros existentes com a data atual
UPDATE public.empresas 
SET updated_at = now() 
WHERE updated_at IS NULL;

-- Tornar a coluna NOT NULL após atualizar os dados existentes
ALTER TABLE public.empresas 
ALTER COLUMN updated_at SET NOT NULL;

-- Criar trigger para atualizar automaticamente o updated_at
CREATE TRIGGER update_empresas_updated_at
    BEFORE UPDATE ON public.empresas
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();