-- Adicionar campo updated_at à tabela veiculos
ALTER TABLE public.veiculos 
ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now();

-- Criar índice para performance
CREATE INDEX idx_veiculos_updated_at ON public.veiculos(updated_at);