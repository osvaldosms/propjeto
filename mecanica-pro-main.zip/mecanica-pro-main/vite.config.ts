import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    // Remove restrictive headers during development to prevent connection issues
    ...(mode === 'production' && {
      headers: {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY", 
        "X-XSS-Protection": "1; mode=block",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
      }
    })
  },
  plugins: [
    react(),
    mode === 'development' &&
    componentTagger(),
  ].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  build: {
    // Security-focused build options
    sourcemap: mode === 'development', // Only generate source maps in development
    minify: mode === 'production' ? 'terser' : false, // Only minify in production
    terserOptions: mode === 'production' ? {
      compress: {
        drop_console: true, // Remove console logs in production
        drop_debugger: true,
      },
    } : {},
    // CSS optimization
    cssCodeSplit: true, // Enable CSS code splitting
    rollupOptions: {
      output: {
        // Split vendor CSS separately
        manualChunks: (id) => {
          if (id.includes('node_modules')) {
            return 'vendor';
          }
          // Split by route-specific components
          if (id.includes('/pages/')) {
            const pageName = id.split('/pages/')[1]?.split('/')[0] || 'page';
            return `page-${pageName}`;
          }
        },
      },
    },
  },
  // Prevent information disclosure
  define: {
    __DEV__: mode === 'development',
  }
}));
